

#!/usr/bin/env python3
"""
Prereqs:
    pip install paramiko
"""

import paramiko
import getpass
import time
import re
from datetime import datetime
from typing import Tuple, Optional

# --- Platform IDs ---
PLAT_OS_SWITCH = "aruba_os_switch"  # ProCurve / ArubaOS-Switch (AOS-S)
PLAT_ARUBAOS   = "arubaos"          # Controllers/gateways (AOS 6/8)
PLAT_AOS_CX    = "aos_cx"           # ArubaOS-CX switches
PLAT_UNKNOWN   = "unknown"

def prompt_targets() -> Tuple[list, str, str]:
    hosts_raw = input("Hostnames/IPs (comma-separated): ").strip()
    hosts = [h.strip() for h in hosts_raw.split(",") if h.strip()]
    username = input("Username: ").strip()
    password = getpass.getpass("Password: ")
    return hosts, username, password

def connect_ssh(host: str, username: str, password: str, timeout: int = 20) -> Optional[Tuple[paramiko.SSHClient, paramiko.Channel]]:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=host,
            username=username,
            password=password,
            look_for_keys=False,
            allow_agent=False,
            timeout=timeout,
        )
        chan = client.invoke_shell()
        chan.settimeout(timeout)
        time.sleep(0.5)  # settle
        return client, chan
    except Exception as e:
        print(f"[{host}] SSH connection failed: {e}")
        return None

def _read_all(chan: paramiko.Channel, idle_threshold: float = 0.7, max_wait: float = 40.0) -> str:
    """
    Read from channel until there's no new data for idle_threshold seconds,
    or max_wait is reached. Suitable for long 'show running-config' outputs.
    """
    output = []
    start = time.time()
    last_data_time = start
    while True:
        if chan.recv_ready():
            data = chan.recv(65535).decode(errors="ignore")
            output.append(data)
            last_data_time = time.time()
        else:
            time.sleep(0.1)

        if (time.time() - last_data_time) >= idle_threshold:
            break
        if (time.time() - start) >= max_wait:
            break
    return "".join(output)

def send_cmd(chan: paramiko.Channel, cmd: str, settle: float = 0.25) -> str:
    chan.send(cmd + "\n")
    time.sleep(settle)
    return _read_all(chan)

def detect_platform(chan: paramiko.Channel) -> str:
    """
    Use 'show version' output to identify platform family.
    Returns one of PLAT_* constants.
    """
    try:
        out = send_cmd(chan, "show version")
        text = out.lower()

        # ArubaOS-CX markers
        if ("arubaos-cx" in text) or ("aos-cx" in text):
            return PLAT_AOS_CX
        # CX often shows 'Software Version 10.x' with Aruba branding
        if ("software version" in text and "10." in text and "aruba" in text):
            return PLAT_AOS_CX

        # ArubaOS controllers/gateways (Mobility Conductor/Controller)
        if ("mobility conductor" in text) or ("mobility controller" in text) or ("arubaos" in text and "version" in text and ("6." in text or "8." in text)):
            return PLAT_ARUBAOS

        # Aruba OS-Switch / ProCurve (AOS-S)
        if ("arubaos-switch" in text) or ("procurve" in text) or ("hp procurve" in text) or ("wb." in text) or ("ya." in text) or ("yb." in text) or ("wc." in text) or ("kb." in text):
            return PLAT_OS_SWITCH

        if "procurve" in text:
            return PLAT_OS_SWITCH

        return PLAT_UNKNOWN
    except Exception:
        return PLAT_UNKNOWN

def disable_paging_by_platform(chan: paramiko.Channel, platform: str) -> None:
    """
    Send the correct no-paging command based on platform,
    then attempt fallbacks to be safe.
    """
    primary = None
    if platform == PLAT_OS_SWITCH:
        primary = "no page"
    elif platform == PLAT_ARUBAOS:
        primary = "no paging"
    elif platform == PLAT_AOS_CX:
        primary = "terminal length 0"

    if primary:
        try:
            send_cmd(chan, primary)
            time.sleep(0.2)
        except Exception:
            pass

    fallbacks = ["no page", "no paging", "terminal length 0"]
    for cmd in fallbacks:
        if cmd == primary:
            continue
        try:
            send_cmd(chan, cmd)
            time.sleep(0.2)
        except Exception:
            pass

def sanitize_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)

def collect_cx_context_config(chan: paramiko.Channel) -> Optional[str]:
    """
    Enter Aruba Central config context on AOS-CX and get 'show running-config current-context'.
    Returns the output string or None on failure.
    """
    try:
        # Enter config mode, then Aruba Central context
        send_cmd(chan, "configure terminal")
        resp = send_cmd(chan, "aruba-central")  # creates/enters config-aruba-central
        # If the command is invalid on this CX version (unlikely), bail out gracefully
        if any(err in resp.lower() for err in ["invalid", "unknown", "incomplete", "error"]):
            # exit config mode to be clean
            send_cmd(chan, "end")
            return None

        # Now we are in (config-aruba-central); show current-context
        cx_ctx = send_cmd(chan, "show running-config current-context")
        # Exit back to manager/operator
        send_cmd(chan, "end")
        return cx_ctx
    except Exception:
        try:
            send_cmd(chan, "end")
        except Exception:
            pass
        return None

def collect_device(host: str, username: str, password: str) -> None:
    conn = connect_ssh(host, username, password)
    if not conn:
        return
    client, chan = conn
    try:
        # Optional 'enable' — many Aruba platforms accept this; ignored if not needed.
        send_cmd(chan, "enable")

        platform = detect_platform(chan)
        print(f"[{host}] Detected platform: {platform}")

        disable_paging_by_platform(chan, platform)

        # Global running-config
        run_out = send_cmd(chan, "show running-config")

        # If CX, also collect the Aruba Central context's running config
        cx_ctx_out = None
        if platform == PLAT_AOS_CX:
            cx_ctx_out = collect_cx_context_config(chan)

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_host = sanitize_filename(host)
        fname = f"{safe_host}_{ts}.txt"

        sections = [
            f"# Host: {host}",
            f"# Detected platform: {platform}",
            f"# Collected (local): {datetime.now().isoformat(timespec='seconds')}",
            "",
            "# === show running-config (global) ===",
            run_out,
        ]
        if cx_ctx_out:
            sections += [
                "",
                "# === AOS-CX (config-aruba-central) -> show running-config current-context ===",
                cx_ctx_out
            ]
        else:
            if platform == PLAT_AOS_CX:
                sections += [
                    "",
                    "# [INFO] AOS-CX: Aruba Central context not available or command failed; no current-context output."
                ]

        content = "\n".join(sections)

        with open(fname, "w", encoding="utf-8") as f:
            f.write(content)

        print(f"[{host}] Output saved to {fname}")
    except Exception as e:
        print(f"[{host}] Collection failed: {e}")
    finally:
        try:
            chan.close()
        except Exception:
            pass
        try:
            client.close()
        except Exception:
            pass

def main():
    hosts, username, password = prompt_targets()
    if not hosts:
        print("No hosts provided. Exiting.")
        return
    for host in hosts:
        collect_device(host, username, password)

if __name__ == "__main__":
   main()

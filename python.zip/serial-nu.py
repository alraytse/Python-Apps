#!/usr/bin/env python3

"""
serial_inventory.py

Prompts for:
1. Username
2. Password
3. Comma-delimited switch list

Connects to Cisco Nexus / IOS switches via SSH,
collects serial numbers, and writes results to CSV.

Requirements:
    pip install netmiko
"""

import csv
import re
import getpass
from datetime import datetime

from netmiko import ConnectHandler
from netmiko.exceptions import (
    NetmikoAuthenticationException,
    NetmikoTimeoutException,
)

OUTPUT_FILE = (
    f"switch_serials_"
    f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
)


def detect_platform(host, username, password):
    """
    Try NX-OS first, then IOS.
    """

    platforms = [
        "cisco_nxos",
        "cisco_ios",
    ]

    for platform in platforms:
        try:
            device = {
                "device_type": platform,
                "host": host,
                "username": username,
                "password": password,
                "fast_cli": False,
            }

            conn = ConnectHandler(**device)
            return conn, platform

        except Exception:
            continue

    return None, None


def get_serial_number(conn):
    """
    Retrieve serial number from Cisco device.
    """

    commands = [
        "show inventory",
        "show version",
    ]

    for cmd in commands:

        try:
            output = conn.send_command(cmd)

            #
            # Nexus/IOS inventory
            #
            match = re.search(
                r"SN:\s*([A-Z0-9]+)",
                output,
                re.IGNORECASE,
            )

            if match:
                return match.group(1)

            #
            # IOS show version
            #
            match = re.search(
                r"Processor board ID\s+(\S+)",
                output,
                re.IGNORECASE,
            )

            if match:
                return match.group(1)

        except Exception:
            pass

    return "NOT FOUND"


def get_hostname(conn):

    try:
        prompt = conn.find_prompt()
        return prompt.rstrip("#>").strip()
    except Exception:
        return "UNKNOWN"


def main():

    print("\nCisco Serial Number Inventory\n")

    username = input("Username: ").strip()
    password = getpass.getpass("Password: ")

    switches = input(
        "\nSwitches (comma delimited): "
    ).strip()

    switch_list = [
        x.strip()
        for x in switches.split(",")
        if x.strip()
    ]

    results = []

    for switch in switch_list:

        print(f"\nConnecting to {switch}")

        try:

            conn, platform = detect_platform(
                switch,
                username,
                password,
            )

            if conn is None:

                results.append([
                    switch,
                    "",
                    "",
                    "CONNECTION FAILED"
                ])

                continue

            hostname = get_hostname(conn)

            serial = get_serial_number(conn)

            results.append([
                hostname,
                switch,
                serial,
                platform,
            ])

            print(
                f"SUCCESS - {hostname} "
                f"Serial: {serial}"
            )

            conn.disconnect()

        except NetmikoAuthenticationException:

            results.append([
                switch,
                "",
                "",
                "AUTH FAILED"
            ])

        except NetmikoTimeoutException:

            results.append([
                switch,
                "",
                "",
                "TIMEOUT"
            ])

        except Exception as e:

            results.append([
                switch,
                "",
                "",
                f"ERROR: {e}"
            ])

    #
    # Write CSV
    #
    with open(
        OUTPUT_FILE,
        "w",
        newline="",
        encoding="utf-8",
    ) as csvfile:

        writer = csv.writer(csvfile)

        writer.writerow(
            [
                "Hostname",
                "IP_or_Name",
                "Serial_Number",
                "Platform",
            ]
        )

        writer.writerows(results)

    print("\nCompleted")
    print(f"CSV Report: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
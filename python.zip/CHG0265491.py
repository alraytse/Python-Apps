
import os
import time
import json
import csv
import logging
import getpass
import shutil
import difflib
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import paramiko

# ========= RUN MODE =========
RUN_MODE = input("Run mode (pre/post): ").strip().lower()
if RUN_MODE not in {"pre", "post"}:
    raise ValueError("Run mode must be 'pre' or 'post'")

RUN_TS = datetime.now().strftime("%Y%m%d_%H%M%S")
# ========= DIRECTORIES =========
LOG_DIR = "logs"
BASE_ARTIFACTS_DIR = "artifacts"
ARTIFACTS_DIR = os.path.join(BASE_ARTIFACTS_DIR, RUN_MODE)

os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(ARTIFACTS_DIR, exist_ok=True)

# ========= GLOBAL LOGGING =========
log_path = os.path.join(LOG_DIR, f"validation_{RUN_MODE}_{RUN_TS}.log")


root_logger = logging.getLogger()
root_logger.setLevel(logging.DEBUG)


file_handler = logging.FileHandler(log_path)
file_handler.setLevel(logging.DEBUG)


console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)


formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)


if not root_logger.handlers:
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)


logging.info("Logging initialized")


# ========= PER-DEVICE LOGGER =========
def get_device_logger(device):
    name = f"device_{device}"
    logger = logging.getLogger(name)


    if logger.handlers:
        return logger


    logger.setLevel(logging.DEBUG)


    device_log = os.path.join(
        LOG_DIR,
        f"device_{device}_{RUN_MODE}_{RUN_TS}.log"
    )


    fh = logging.FileHandler(device_log)
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)


    logger.addHandler(fh)
    logger.propagate = False  # prevent duplicate logs


    return logger


# ========= CREDENTIALS =========
DEVICE_USERNAME = input("Enter device username: ").strip()
DEVICE_PASSWORD = getpass.getpass("Enter device password: ").strip()


if not DEVICE_USERNAME or not DEVICE_PASSWORD:
    raise ValueError("Username and password must not be empty.")


# ========= DEVICES =========
raw_devices = input("Enter device hostnames (comma-separated): ").strip()
if not raw_devices:
    raise ValueError("At least one device hostname must be provided.")


device_list = [d.strip() for d in raw_devices.split(",") if d.strip()]
devices = {d: {"host": d} for d in device_list}
logging.info(f"Devices total: {len(devices)}")
print(">>> Script is running. Outputs are being logged. Do NOT interrupt.")

# ========= COMMANDS =========
commands = {
    d: [
        "terminal length 0",
        "show clock",
        "show version",
        "show ip route summary",
        "show ip route summary vrf all",
        "show ip bgp summary",
        "show interface status",
        "show ip interface brief",
        "show ip interface brief vrf all",
        "show interface description",
        "show route-map",
        "show ip prefix-list",
        "show logging last 50",
        "show ip route vrf all",
        "show ip bgp vrf all"
    ] for d in devices
}

# ========= HELPERS =========
def safe_str(s: str) -> str:
    return (s or "").replace("\r", "").replace("\x1b", "")



def connect_ssh(host, timeout=15):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=host,
        username=DEVICE_USERNAME,
        password=DEVICE_PASSWORD,
        timeout=timeout,
        allow_agent=False,
        look_for_keys=False
    )
    return client



def run_exec(client, cmd, read_timeout=60):
    start = time.time()
    _, stdout, stderr = client.exec_command(cmd, timeout=read_timeout)
    stdout.channel.settimeout(read_timeout)

    out = stdout.read().decode(errors="replace")
    err = stderr.read().decode(errors="replace")

    try:
        status = stdout.channel.recv_exit_status()
    except Exception:
        status = -1

    return status, safe_str(out), safe_str(err), time.time() - start

# ========= PRE → POST COPY =========
def copy_pre_artifacts_if_post():
    if RUN_MODE != "post":
        return

    pre_dir = os.path.join(BASE_ARTIFACTS_DIR, "pre")
    if not os.path.isdir(pre_dir):
        raise FileNotFoundError("PRE artifacts not found — run PRE first.")

    logging.info("POST run detected — copying PRE artifacts")
    for f in os.listdir(pre_dir):
        if f.endswith(".txt"):
            shutil.copy2(
                os.path.join(pre_dir, f),
                os.path.join(ARTIFACTS_DIR, f"PRE_COPY_{f}")
            )

# ========= DEVICE EXECUTION =========
def execute_device(device, info, cmd_list, idx, total):
    dev_log = get_device_logger(device)
    start = time.time()
    host = info["host"]

    logging.info(f"[{idx}/{total}] Connecting to {device}")
    dev_log.info("SSH connection starting")


    client = connect_ssh(host)

    txt_path = os.path.join(ARTIFACTS_DIR, f"{device}_{RUN_TS}.txt")
    csv_path = os.path.join(ARTIFACTS_DIR, f"{device}_{RUN_TS}.csv")


    rows = []

    try:
        with open(txt_path, "w", encoding="utf-8") as out:
            out.write(f"==== {RUN_MODE.upper()} | {device} | {RUN_TS} ====")

            for i, cmd in enumerate(cmd_list, 1):
                ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                logging.info(f"[{device}] ({i}/{len(cmd_list)}) {cmd}")
                dev_log.info(f"Running command {i}/{len(cmd_list)}: {cmd}")
                status, stdout, stderr, elapsed = run_exec(client, cmd)
                out.write(f"--- {ts} :: {cmd} ---{stdout}")

                dev_log.debug(f"Exit status: {status}")
                dev_log.debug(f"Execution time: {elapsed:.2f}s")
                if stderr:
                    dev_log.warning(f"STDERR: {stderr}")
                rows.append({
                    "timestamp": ts,
                    "device": device,
                    "command": cmd,
                    "exit_status": status,
                    "duration_ms": int(elapsed * 1000)
                })
    finally:
        client.close()
        dev_log.info("SSH connection closed")
    if rows:
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)

    elapsed = time.time() - start
    logging.info(f"[{device}] Completed in {elapsed:.1f}s")
    dev_log.info(f"Device completed in {elapsed:.1f}s")
    return {"device": device, "status": "ok", "duration_sec": round(elapsed, 1)}

# ========= RUN ALL =========
def run_all():
    results = []
    total = len(devices)

    with ThreadPoolExecutor(max_workers=total) as pool:
        futures = {
            pool.submit(execute_device, d, devices[d], commands[d], i + 1, total): d
            for i, d in enumerate(devices)
        }

        for f in as_completed(futures):
            results.append(f.result())
    summary = os.path.join(ARTIFACTS_DIR, f"run_summary_{RUN_TS}.json")
    with open(summary, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    logging.info(f"Summary written: {summary}")
    return results

# ========= PRE vs POST DIFF =========
def diff_pre_post_artifacts():
    if RUN_MODE != "post":
        return

    logging.info("Generating PRE vs POST diffs")
    pre_files = {
        f.replace("PRE_COPY_", ""): os.path.join(ARTIFACTS_DIR, f)
        for f in os.listdir(ARTIFACTS_DIR)
        if f.startswith("PRE_COPY_") and f.endswith(".txt")
    }

    post_files = {
        f: os.path.join(ARTIFACTS_DIR, f)
        for f in os.listdir(ARTIFACTS_DIR)
        if f.endswith(".txt") and not f.startswith("PRE_COPY_")
    }

    for fname, pre_path in pre_files.items():
        post_path = post_files.get(fname)
        if not post_path:
            continue

        with open(pre_path, encoding="utf-8", errors="ignore") as f:
            pre_lines = f.readlines()
        with open(post_path, encoding="utf-8", errors="ignore") as f:
            post_lines = f.readlines()

        diff = list(difflib.unified_diff(
            pre_lines,
            post_lines,
            fromfile=f"PRE/{fname}",
            tofile=f"POST/{fname}",
            lineterm=""
        ))

        diff_file = os.path.join(
            ARTIFACTS_DIR,
            f"DIFF_{fname.replace('.txt', '')}_pre_vs_post.txt"
        )

        with open(diff_file, "w", encoding="utf-8") as f:
            f.write("".join(diff) if diff else "NO DIFFERENCES FOUND")

        logging.info(f"Diff written: {diff_file}")


# ========= MAIN =========
if __name__ == "__main__":
    copy_pre_artifacts_if_post()
    summary = run_all()
    diff_pre_post_artifacts()

    ok = len([r for r in summary if r["status"] == "ok"])

    logging.info("=" * 72)
    logging.info("SCRIPT COMPLETED")
    logging.info(f"Devices OK : {ok}/{len(devices)}")
    logging.info(f"Artifacts  : {ARTIFACTS_DIR}")
    logging.info("=" * 72)

    print(">>> Script completed successfully.")
    DEVICE_PASSWORD = None

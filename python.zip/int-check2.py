#!/usr/bin/env python3
"""
Check interfaces in UP state using 'show interface brief | inc up'
- Prompts for comma-separated hostnames
- Prompts for username and hidden password
- Writes all UP interfaces and summary count to a per-device TXT file
"""

from netmiko import ConnectHandler
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import getpass

# Prompt for hostnames
switch_input = input("Enter switch IPs or hostnames separated by commas: ").strip()
switch_hosts = [host.strip() for host in switch_input.split(",") if host.strip()]

# Prompt for credentials
username = input("Enter username: ").strip()
password = getpass.getpass("Enter password: ")

# Build device list
devices = [
    {
        "device_type": "cisco_ios",  # Change to cisco_nxos if needed
        "host": host,
        "username": username,
        "password": password,
    }
    for host in switch_hosts
]

def check_device(device):
    host_for_log = device["host"]
    try:
        net_connect = ConnectHandler(**device)
        hostname = net_connect.find_prompt().strip("#>").strip()

        # Run command to get UP interfaces
        output = net_connect.send_command("show interface brief | inc up")

        # Count UP interfaces (lines in output)
        up_interfaces = [line.split()[0] for line in output.splitlines() if line.strip()]
        up_count = len(up_interfaces)

        # Prepare filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{hostname}_{timestamp}.txt"

        # Write results to file
        with open(filename, "w") as f:
            f.write(f"Device: {hostname} ({host_for_log})\n")
            f.write(f"Checked at: {timestamp}\n\n")
            f.write(f"Summary: {up_count} interfaces are UP\n\n")
            f.write("Interfaces in UP state:\n")
            for intf in up_interfaces:
                f.write(f"  {intf}\n")
            f.write("\n--- Raw Output ---\n")
            f.write(output + "\n")

        net_connect.disconnect()
        return f"[{hostname}] Results saved to {filename}"

    except Exception as e:
        return f"[{host_for_log}] Error: {e}"

# Run checks in parallel
max_workers = max(1, min(10, len(devices)))
with ThreadPoolExecutor(max_workers=max_workers) as executor:
    futures = [executor.submit(check_device, d) for d in devices]
    for future in as_completed(futures):
        print(future.result())

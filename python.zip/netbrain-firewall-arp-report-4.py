"""
NetBrain Firewall ARP Report
=============================

Prompts for a firewall name and prints all ARP table entries retrieved
live from that device via the NetBrain REST API (CMDB/Devices/DeviceRawData
CLI passthrough) -- same underlying mechanism used for NAT policy lookups
in netbrain-interface-report.py.

Inputs (interactive prompts):
    NetBrain Username - str, required.
    NetBrain Password - str, required (hidden input).
    Firewall Name      - str, required. Hostname of the firewall to query
                          (exact match preferred; falls back to a
                          case-insensitive substring match).

Behavior:
    - Authenticates to NetBrain.
    - Looks up the device by hostname against the CMDB device list.
    - Tries a list of vendor-specific "show ARP table" CLI commands
      against the device (PAN-OS "show arp all", Cisco IOS "show ip arp",
      Cisco ASA "show arp", FortiOS "get system arp" /
      "diagnose ip arp list"), stopping at the first one that returns
      real data.
    - Parses IP / MAC / interface columns out of the raw CLI output,
      prints them as a table to the console, and writes them to a CSV
      file with IP address and MAC address in separate columns:
        ~/Downloads/{hostname}.arp.report.{TIMESTAMP}.csv

Requires network access to the NetBrain API host and valid NetBrain
credentials. SSL certificate verification is disabled for API requests,
matching the rest of this toolset.

Usage:
    python netbrain-firewall-arp-report.py
"""

import csv
import getpass
import os
import re
import sys
from datetime import datetime

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"

# ---------------------------------------------------------------------------
# Interactive Inputs
# ---------------------------------------------------------------------------
USERNAME = input("Enter NetBrain Username: ").strip()
PASSWORD = getpass.getpass("Enter NetBrain Password: ").strip()
FIREWALL_NAME = input("Enter Firewall Name: ").strip()

if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")
if not FIREWALL_NAME:
    sys.exit("Error: Firewall name cannot be empty.")

session = requests.Session()
session.verify = False


def authenticate() -> None:
    login_url = f"{BASE_URL}/Session"
    try:
        res = session.post(
            login_url,
            json={"username": USERNAME, "password": PASSWORD},
            timeout=60,
        )
        res.raise_for_status()
    except requests.exceptions.RequestException as e:
        sys.exit(f"Auth error: {e}")

    data = res.json()
    token = data.get("token") or data.get("tokenID")
    if not token:
        sys.exit("Error: Token missing in response payload.")

    session.headers.update({
        "Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json",
    })
    if "tenantId" in data and "domainId" in data:
        session.headers.update({
            "tenantId": str(data["tenantId"]),
            "domainId": str(data["domainId"]),
        })


def _device_name(device: dict) -> str:
    return device.get("hostName") or device.get("hostname") or device.get("name") or ""


def find_device(name: str) -> dict:
    """Looks up a device by hostname. Tries an optimistic server-side
    hostname filter first (harmless if the API ignores the param); falls
    back to paginating the full CMDB device list and matching
    client-side (exact match preferred, else the first case-insensitive
    substring match) if the filtered query doesn't resolve to a single
    match.
    """
    name_lower = name.lower()

    try:
        res = session.get(
            f"{BASE_URL}/CMDB/Devices", params={"hostname": name}, timeout=30
        )
        if res.status_code == 200:
            devices = res.json().get("devices", [])
            exact = [d for d in devices if _device_name(d).lower() == name_lower]
            if len(exact) == 1:
                return exact[0]
    except requests.RequestException:
        pass

    matches = []
    skip = 0
    page_limit = 100
    while True:
        try:
            res = session.get(
                f"{BASE_URL}/CMDB/Devices",
                params={"skip": skip, "limit": page_limit},
                timeout=30,
            )
            if res.status_code != 200:
                break
            devices = res.json().get("devices", [])
        except requests.RequestException:
            break
        if not devices:
            break

        for d in devices:
            dn = _device_name(d).lower()
            if dn == name_lower:
                return d
            if name_lower in dn:
                matches.append(d)

        skip += page_limit
        if len(devices) < page_limit:
            break

    if not matches:
        sys.exit(f"Error: No device matching '{name}' found in NetBrain CMDB.")

    if len(matches) > 1:
        print(f"Warning: {len(matches)} devices matched '{name}'; using the first match. Others:")
        for d in matches[1:]:
            print(f"  - {_device_name(d)}")

    return matches[0]


# ---------------------------------------------------------------------------
# Raw CLI passthrough (same DeviceRawData mechanism used elsewhere in this
# toolset for NAT policy / running-config lookups)
# ---------------------------------------------------------------------------
DATATYPE_CANDIDATES = [2, 0, 1]


def fetch_device_raw_data(hostname: str, cmd: str, echo_indicators: list) -> str:
    """Runs `cmd` on `hostname` via NetBrain's DeviceRawData CLI
    passthrough, trying each dataType candidate until one returns HTTP 200
    with content matching one of `echo_indicators` (case-insensitive).
    Returns "" if nothing usable came back.
    """
    url = f"{BASE_URL}/CMDB/Devices/DeviceRawData"
    for data_type in DATATYPE_CANDIDATES:
        params = {"hostname": hostname, "dataType": data_type, "cmd": cmd}
        try:
            res = session.get(url, params=params, timeout=30)
        except requests.RequestException:
            continue
        if res.status_code != 200:
            continue
        try:
            content = res.json().get("content", "") or ""
        except ValueError:
            continue
        content_lower = content.lower()
        if any(ind.lower() in content_lower for ind in echo_indicators):
            return content
    return ""


# Vendor-specific ARP commands to try, in order, with permissive echo
# indicators (the literal command OR a distinctive output header).
# "sh ip arp all" is tried first per this environment's preferred syntax;
# the rest remain as fallbacks -- extend this list if this firewall's
# vendor isn't covered.
ARP_COMMAND_CANDIDATES = [
    ("sh ip arp all", ["ip arp", "interface", "status", "ttl", "mac"]),  # preferred
    ("show arp all", ["show arp", "interface", "status", "ttl"]),      # PAN-OS
    ("show ip arp", ["show ip arp", "protocol", "hardware addr"]),      # Cisco IOS
    ("show arp", ["show arp", "age", "interface"]),                    # Cisco ASA / generic
    ("get system arp", ["get system arp", "age", "mac"]),               # FortiOS
    ("diagnose ip arp list", ["diagnose ip arp list", "index", "ip"]),  # FortiOS alt
]

_IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
# Real MAC formats only: colon- or hyphen-separated hex octets (consistent
# separator throughout, via backreference), or Cisco's dot-grouped
# "xxxx.xxxx.xxxx" form. Deliberately does NOT allow mixed "." and "-"
# separators in one match -- that laxer version was matching IP-range
# strings like "10.17.44.16-10.17.44.21" as if they were MAC addresses.
_MAC_RE = re.compile(
    r"\b[0-9a-fA-F]{2}([:-])[0-9a-fA-F]{2}(?:\1[0-9a-fA-F]{2}){4}\b"
    r"|\b[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\b"
)


def fetch_arp_raw(hostname: str) -> tuple:
    """Returns (raw_text, command_used) for the first ARP command whose
    response contains at least one real, strictly-formatted MAC address
    (see _MAC_RE) -- not just a loose keyword match. This matters because
    some devices return HTTP 200 with unrelated content (e.g. a Panorama
    management appliance returning address-object/address-range config
    instead of an ARP table) that happens to contain generic words like
    "ip" or "interface" without containing any actual ARP entries.
    Returns ("", "") if nothing usable came back.
    """
    for cmd, indicators in ARP_COMMAND_CANDIDATES:
        raw = fetch_device_raw_data(hostname, cmd, indicators)
        if raw.strip() and _MAC_RE.search(raw):
            return raw, cmd
    return "", ""


def parse_arp_table(raw_text: str) -> list:
    """Best-effort generic parser: for each line containing both an IP
    address and a MAC address, extracts those plus whatever other tokens
    remain on the line (treated as interface name + extra detail), since
    exact column layouts vary by vendor.
    """
    entries = []
    for line in raw_text.splitlines():
        ip_match = _IP_RE.search(line)
        mac_match = _MAC_RE.search(line)
        if not ip_match or not mac_match:
            continue

        ip = ip_match.group(0)
        mac = mac_match.group(0)

        remainder = line.replace(ip, "").replace(mac, "")
        extra_tokens = [t for t in remainder.split() if t not in ("-", "|")]
        interface = extra_tokens[0] if extra_tokens else ""
        extra = " ".join(extra_tokens[1:])

        entries.append({
            "ip": ip,
            "mac": mac,
            "interface": interface,
            "extra": extra,
        })
    return entries


def print_arp_table(entries: list, hostname: str, command: str) -> None:
    if not entries:
        print(f"No ARP entries found for '{hostname}'.")
        return

    print(f"\nARP table for {hostname} (via '{command}'), {len(entries)} entries:\n")

    headers = ["IP Address", "MAC Address", "Interface", "Extra"]
    rows = [[e["ip"], e["mac"], e["interface"], e["extra"]] for e in entries]

    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    def fmt_row(cells):
        return "  ".join(c.ljust(widths[i]) for i, c in enumerate(cells))

    print(fmt_row(headers))
    print("  ".join("-" * w for w in widths))
    for row in rows:
        print(fmt_row(row))
    print()


def write_arp_csv(entries: list, hostname: str) -> str:
    """Writes ARP entries to a CSV file with IP address and MAC address
    in separate columns. Returns the output file path."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.expanduser(
        f"~/Downloads/{hostname}.arp.report.{timestamp}.csv"
    )
    output_dir = os.path.dirname(output_file)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    headers = ["hostname", "ipAddress", "macAddress", "interface", "extra"]
    with open(output_file, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=headers)
        writer.writeheader()
        for e in entries:
            writer.writerow({
                "hostname": hostname,
                "ipAddress": e["ip"],
                "macAddress": e["mac"],
                "interface": e["interface"],
                "extra": e["extra"],
            })

    return output_file


def main():
    authenticate()

    print(f"Looking up device '{FIREWALL_NAME}' in NetBrain CMDB...")
    device = find_device(FIREWALL_NAME)
    hostname = _device_name(device)
    print(f"Found device: {hostname}")

    if "panorama" in hostname.lower():
        print(
            f"Warning: '{hostname}' looks like a Panorama management appliance, "
            f"not a firewall. Panorama doesn't pass traffic and has no dataplane "
            f"ARP table -- point this at one of the actual firewalls Panorama "
            f"manages instead for real ARP data."
        )

    print(f"Fetching ARP table for {hostname}...")
    raw, command = fetch_arp_raw(hostname)
    if not raw:
        sys.exit(
            f"Error: Could not retrieve ARP data for '{hostname}' -- none of the "
            f"attempted commands ({', '.join(c for c, _ in ARP_COMMAND_CANDIDATES)}) "
            f"returned usable output. The device may not support live CLI "
            f"passthrough for ARP, or NetBrain's cached command set for this "
            f"device type may not include it."
        )

    entries = parse_arp_table(raw)
    print_arp_table(entries, hostname, command)

    if entries:
        output_file = write_arp_csv(entries, hostname)
        print(f"CSV export successful: {output_file}")
    else:
        print("No entries to export -- skipping CSV file.")


if __name__ == "__main__":
    main()

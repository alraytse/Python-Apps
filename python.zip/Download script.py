#!/usr/bin/env python3
import logging
import time
import ipaddress
from netmiko import ConnectHandler

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def is_f5(device_type):
    return 'f5' in device_type.lower()


def f5_ping(conn, ip):
    try:
        output = conn.send_command_timing(
            f'run util ping {ip} count 3',
            read_timeout=60
        )
        time.sleep(1)
        conn.clear_buffer()
        return 'bytes from' in output.lower() and '0 packets received' not in output
    except Exception:
        logging.exception('F5 ping failed')
        return False


def f5_route_lookup(conn, target):
    try:
        output = conn.send_command_timing(
            f'show net route {target}',
            read_timeout=60
        )
        time.sleep(1)
        conn.clear_buffer()
        return output
    except Exception:
        logging.exception('F5 route lookup failed')
        return ''


def f5_is_null_route(output):
    output = output.lower()
    return any(x in output for x in ['blackhole', 'reject', 'null', 'prohibit'])


def ping_ip(conn, ip, device_type):
    try:
        if is_f5(device_type):
            return f5_ping(conn, ip)

        output = conn.send_command(
            f'ping {ip}',
            expect_string=r'[#>]',
            read_timeout=60
        )

        return ('success rate is 100 percent' in output.lower() or '!!!!!' in output)
    except Exception:
        logging.exception('Ping failed')
        return False


def check_subnet(conn, subnet, device_type):
    network = ipaddress.ip_network(subnet, strict=False)

    result = {
        'subnet': subnet,
        'subnet_found': False,
        'destination_reachable': False,
        'null_route': False,
    }

    if is_f5(device_type):
        route_target = str(network.network_address) if network.prefixlen == 32 else subnet

        route_output = f5_route_lookup(conn, route_target)

        result['subnet_found'] = bool(route_output.strip())
        result['destination_reachable'] = f5_ping(conn, str(network.network_address))
        result['null_route'] = f5_is_null_route(route_output)

        return result

    cmds = [
        f'show ip route {subnet}',
        f'show ip route {network.network_address}'
    ]

    for cmd in cmds:
        try:
            output = conn.send_command(
                cmd,
                expect_string=r'[#>]',
                read_timeout=60
            )

            if output.strip():
                result['subnet_found'] = True

            if 'Null0' in output:
                result['null_route'] = True

        except Exception:
            logging.exception(f'Failed: {cmd}')

    result['destination_reachable'] = ping_ip(
        conn,
        str(network.network_address),
        device_type
    )

    return result


if __name__ == '__main__':
    print('Combined subnet validation script with F5 support.')

#!/usr/bin/env python3
import csv, re, sys, logging, getpass, ipaddress
from datetime import datetime
from netmiko import ConnectHandler

LOG_FILE=f"subnet_audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(level=logging.INFO,format='%(asctime)s | %(levelname)s | %(message)s',handlers=[logging.FileHandler(LOG_FILE),logging.StreamHandler(sys.stdout)])
logger=logging.getLogger(__name__)

def generate_subnets(start_subnet,end_subnet):
    start=ipaddress.ip_network(start_subnet,strict=False)
    end=ipaddress.ip_network(end_subnet,strict=False)
    cur=start.network_address
    subs=[]
    while int(cur)<=int(end.network_address):
        subs.append(str(ipaddress.ip_network(f"{cur}/{start.prefixlen}",strict=False)))
        cur=ipaddress.ip_address(int(cur)+start.num_addresses)
    return subs

def ping_ip(conn,ip):
    try:
        out=conn.send_command(f'ping {ip}',read_timeout=30)
        m=re.search(r'Success rate is\s+(\d+)\s+percent',out,re.I)
        if m:
            pct=int(m.group(1)); return ('Yes' if pct>0 else 'No',pct)
        return ('No',0)
    except Exception:
        logger.exception('Ping failed %s',ip)
        return ('Error',0)

def check_recursive_route(conn,next_hop,vrf=''):
    try:
        cmd=f'show ip route vrf {vrf} {next_hop}' if vrf else f'show ip route {next_hop}'
        out=conn.send_command(cmd,read_timeout=20)
        return 'Fail' if 'not in table' in out.lower() else 'OK'
    except Exception:
        return 'Error'

def check_arp(conn,ip):
    try:
        out=conn.send_command(f'show ip arp {ip}',read_timeout=20)
        if 'Incomplete' in out: return 'No'
        return 'Yes' if ip in out else 'Unknown'
    except Exception:
        return 'Unknown'

def determine_status(r):
    if r['null0_route']=='Yes': return ('BLACKHOLED','Route points to Null0')
    if r['reachable']=='No': return ('NO_ROUTE','Subnet not found in routing table')
    if r['recursive_route']=='Fail': return ('BROKEN_NEXT_HOP','Unable to resolve next-hop route')
    if r['icmp_reachable']=='No': return ('NEXT_HOP_DOWN','Next-hop ping failed')
    if r['destination_ping']=='No': return ('DESTINATION_UNREACHABLE','Route exists but destination ping failed')
    if r['destination_ping']=='Error': return ('VALIDATION_INCOMPLETE','Destination validation error')
    return ('REACHABLE','All validation checks passed')

def check_subnet(conn,subnet,vrf=''):
    r={'reachable':'No','route_type':'','next_hop':'','null0_route':'No','icmp_reachable':'','recursive_route':'','arp_present':'','destination_ping':'','longer_prefixes_found':'No','status':'','partial_reason':'','route_info':''}
    try:
        cmd=f'show ip route vrf {vrf} {subnet}' if vrf else f'show ip route {subnet}'
        out=conn.send_command(cmd,read_timeout=30)
        r['route_info']=out.replace('
',' ')
        if 'not in table' in out.lower():
            r['status']='NO_ROUTE'; r['partial_reason']='Subnet not found in routing table'; return r
        r['reachable']='Yes'
        m=re.search(r'Known via "([^"]+)"',out)
        if m: r['route_type']=m.group(1)
        if re.search(r'Null0',out,re.I): r['null0_route']='Yes'
        try:
            lpcmd=f'show ip route vrf {vrf} longer-prefixes {subnet.split("/")[0]}' if vrf else f'show ip route longer-prefixes {subnet.split("/")[0]}'
            lp=conn.send_command(lpcmd,read_timeout=20)
            if lp.strip(): r['longer_prefixes_found']='Yes'
        except Exception:
            pass
        nh=re.search(r'via\s+(\d+\.\d+\.\d+\.\d+)',out)
        if nh:
            r['next_hop']=nh.group(1)
            r['recursive_route']=check_recursive_route(conn,r['next_hop'],vrf)
            r['arp_present']=check_arp(conn,r['next_hop'])
            if r['null0_route']=='No':
                r['icmp_reachable'],_=ping_ip(conn,r['next_hop'])
        hosts=list(ipaddress.ip_network(subnet,strict=False).hosts())
        if hosts:
            r['destination_ping'],_=ping_ip(conn,str(hosts[0]))
        r['status'],r['partial_reason']=determine_status(r)
        logger.info('%s %s %s',subnet,r['status'],r['partial_reason'])
        return r
    except Exception as e:
        logger.exception('Subnet check failed')
        r['status']='ERROR'; r['partial_reason']=str(e); r['route_info']=str(e)
        return r

def main():
    start=input('Beginning subnet/mask: ')
    end=input('Ending subnet/mask: ')
    hosts=[h.strip() for h in input('Hosts (comma delimited): ').split(',') if h.strip()]
    vrf=input('VRF (blank=default): ').strip()
    user=input('Username: ')
    pwd=getpass.getpass('Password: ')
    results=[]
    for host in hosts:
        try:
            logger.info('Connecting %s',host)
            conn=ConnectHandler(device_type='cisco_ios',host=host,username=user,password=pwd,fast_cli=False)
            hostname=conn.find_prompt().rstrip('#>')
            for subnet in generate_subnets(start,end):
                row=check_subnet(conn,subnet,vrf)
                row.update({'device':host,'hostname':hostname,'vrf':vrf or 'default','subnet':subnet})
                results.append(row)
            conn.disconnect()
        except Exception:
            logger.exception('Connection failed %s',host)
    fn=f"subnet_audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    fields=['device','hostname','vrf','subnet','status','partial_reason','reachable','route_type','next_hop','recursive_route','arp_present','null0_route','icmp_reachable','destination_ping','longer_prefixes_found','route_info']
    with open(fn,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(results)
    logger.info('CSV saved %s',fn)
    logger.info('Log saved %s',LOG_FILE)

if __name__=='__main__':
    main()

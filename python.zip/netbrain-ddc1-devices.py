import requests
import csv
import sys
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Suppress SSL certificate verification warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# --- Configuration Section ---
BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
USERNAME = "skk30ws"
PASSWORD = "m'A)=(nR0k{D#r0q6uEQy"
OUTPUT_FILE = "/Users/alex.raytselsky/Downloads/ddc1_network_inventory.csv"


import json

requests.packages.urllib3.disable_warnings()

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"


# Login
r = requests.post(
    f"{BASE_URL}/Session",
    json={
        "username": USERNAME,
        "password": PASSWORD
    },
    verify=False
)

login = r.json()

headers = {
    "Token": login["token"],
    "Content-Type": "application/json"
}

# Get first device
r = requests.get(
    f"{BASE_URL}/CMDB/Devices",
    headers=headers,
    params={
        "skip": 0,
        "limit": 1
    },
    verify=False
)

data = r.json()

with open("device_sample.json", "w") as f:
    json.dump(data, f, indent=2)

print("Created: device_sample.json")





# Concurrency tuning parameters
MAX_WORKERS = 35    
PAGE_LIMIT = 100    
MAX_ESTIMATED_PAGES = 100  # Sweeps up to 10,000 inventory assets globally

# List of default system VRF names to exclude from the report
DEFAULT_VRFS = {"default", "mgmt", "management", "global", "none", "null", ""}

# Ensure local downloads folder directory exists safely on your Mac
os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

# 1. Authenticate with NetBrain
login_url = f"{BASE_URL}/Session"
login_payload = {"username": USERNAME, "password": PASSWORD}

print("Logging into NetBrain (Production Multi-Threaded Model)...")
response = requests.post(login_url, json=login_payload, verify=False)

if response.status_code != 200:
    print(f"❌ Login HTTP error {response.status_code}: {response.text}")
    sys.exit(1)

login_data = response.json()
token = login_data.get("token")

if not token:
    print("❌ Critical Error: Token missing from authentication response payload.")
    sys.exit(1)

headers = {
    "Token": token,
    "Content-Type": "application/json",
    "Accept": "application/json"
}

# --- CRITICAL R12 MULTI-TENANT ARRAY INDEX POSITION LOOKUPS RESTORED ---
user_tenant_id = login_data.get("tenantId")
user_domain_id = login_data.get("domainId")
user_profile = login_data.get("userProfile") or {}

try:
    # Drills into index 0 of the plural R12 list schemas safely
    if not user_tenant_id and "tenants" in user_profile and isinstance(user_profile["tenants"], list) and user_profile["tenants"]:
        user_tenant_id = user_profile["tenants"][0].get("tenantId")
    if not user_domain_id and "domains" in user_profile and isinstance(user_profile["domains"], list) and user_profile["domains"]:
        user_domain_id = user_profile["domains"][0].get("domainId")
        
    # Fallback drill into index 0 of singular R12 list variants safely
    if not user_tenant_id and "tenant" in user_profile and isinstance(user_profile["tenant"], list) and user_profile["tenant"]:
        user_tenant_id = user_profile["tenant"][0].get("tenantId")
    if not user_domain_id and "domain" in user_profile and isinstance(user_profile["domain"], list) and user_profile["domain"]:
        user_domain_id = user_profile["domain"][0].get("domainId")
except Exception as parse_err:
    print(f"-> Notice: System scope fallback map update skipped: {parse_err}")

if user_tenant_id and user_domain_id:
    print(f"-> Scope Context Bound Successfully: Tenant ({user_tenant_id}) | Domain ({user_domain_id})")
    headers["tenantId"] = str(user_tenant_id)
    headers["domainId"] = str(user_domain_id)
else:
    print("⚠️ Warning: Scope GUIDs missing from response. Sub-resource querying may remain locked.")


# 2. Worker task to pull basic device records
def fetch_device_page(skip_value):
    url = f"{BASE_URL}/CMDB/Devices"
    query_params = {"skip": skip_value, "limit": PAGE_LIMIT}
    try:
        res = requests.get(url, headers=headers, params=query_params, verify=False, timeout=30)
        if res.status_code == 200:
            return res.json().get("devices", [])
        return []
    except Exception:
        return []


# 3. Worker task to enrich devices with Interface, Production VRF, and Routing Protocols
def enrich_device_metadata(device_id, hostname):
    types = set()
    vrfs = set()
    protocols = set()
    
    query_params_id = {"deviceId": device_id} if device_id else {"hostname": str(hostname)}
    query_params_fallback = {"hostname": str(hostname)}
    
    # Task A: Fetch Interfaces and VRFs
    try:
        intf_url = f"{BASE_URL}/CMDB/Devices/Interfaces"
        res_intf = requests.get(intf_url, headers=headers, params=query_params_id, verify=False, timeout=15)
        
        if res_intf.status_code != 200 or not res_intf.json().get("interfaces"):
            res_intf = requests.get(intf_url, headers=headers, params=query_params_fallback, verify=False, timeout=15)
            
        if res_intf.status_code == 200:
            interfaces = res_intf.json().get("interfaces", [])
            for intf in interfaces:
                if_type = intf.get("interfaceType") or intf.get("type") or intf.get("intfType")
                if if_type:
                    types.add(str(if_type))
                    
                vrf_name = intf.get("vrf") or intf.get("vrfName") or intf.get("vrf_name")
                if vrf_name and str(vrf_name).strip().lower() not in DEFAULT_VRFS:
                    vrfs.add(str(vrf_name).strip())
    except Exception:
        pass

    # Task B: Fetch Active Routing Protocols
    try:
        rt_url = f"{BASE_URL}/CMDB/Devices/Routing/Protocols"
        res_rt = requests.get(rt_url, headers=headers, params=query_params_id, verify=False, timeout=15)
        
        if res_rt.status_code != 200 or not res_rt.json().get("protocols"):
            res_rt = requests.get(rt_url, headers=headers, params=query_params_fallback, verify=False, timeout=15)
            
        if res_rt.status_code == 200:
            proto_list = res_rt.json().get("protocols", [])
            for proto in proto_list:
                p_name = proto.get("protocolName") or proto.get("name") or proto.get("type")
                if p_name:
                    protocols.add(str(p_name).upper())
    except Exception:
        pass
                    
    return list(types), list(vrfs), list(protocols)


# 4. Thread Orchestration Pool - Phase 1: Global Device Collection
all_ddc1_devices = []
seen_hostnames = set()
all_discovered_columns = set()

all_discovered_columns.update(["interfaceTypes", "vrfNames", "routingProtocols"])
skip_offsets = [i * PAGE_LIMIT for i in range(MAX_ESTIMATED_PAGES)]

print(f"\nInitializing ThreadPoolExecutor with {MAX_WORKERS} workers...")
print("Pulling inventory globally and compiling DDC1 device profiles...")

with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    future_to_skip = {executor.submit(fetch_device_page, skip): skip for skip in skip_offsets}
    
    for future in as_completed(future_to_skip):
        try:
            devices_batch = future.result()
            if devices_batch:
                for device in devices_batch:
                    hostname = device.get("name") or device.get("hostName") or device.get("hostname")
                    
                    if hostname and hostname not in seen_hostnames:
                        device_str = str(device).upper()
                        if "DDC1" in device_str:
                            seen_hostnames.add(hostname)
                            flat_device = {}
                            flat_device["_internal_processing_id"] = device.get("id") or device.get("deviceId")
                            
                            flat_device["hostname"] = hostname
                            
                            def is_excluded(field_name):
                                name_lower = field_name.lower()
                                return (name_lower in ["id", "deviceid", "hostname", "name", "mgmtip", "managementip", "ip"]) or "discovery" in name_lower or "time" in name_lower

                            for key, value in device.items():
                                if key == "attributes" and isinstance(value, dict):
                                    for sub_key, sub_value in value.items():
                                        if is_excluded(sub_key):
                                            continue
                                        flat_device[f"attr_{sub_key}"] = sub_value
                                else:
                                    if is_excluded(key):
                                        continue
                                    flat_device[key] = value
                                    
                            for flat_key in flat_device.keys():
                                if flat_key != "_internal_processing_id":
                                    all_discovered_columns.add(flat_key)
                                
                            all_ddc1_devices.append(flat_device)
        except Exception as e:
            print(f"[Phase 1 Worker Exception Error]: {e}")

print(f"\n[DEBUG LOG] Phase 1 finished. Found a total of {len(all_ddc1_devices)} unique DDC1 devices.")

# 5. Thread Orchestration Pool - Phase 2: Complete Data Enrichment Loop
if all_ddc1_devices:
    print(f"Gathering interface types, production VRFs, and routing protocols for {len(all_ddc1_devices)} devices...")
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as enrichment_executor:
        future_to_device = {
            enrichment_executor.submit(enrich_device_metadata, dev.get("_internal_processing_id"), dev.get("hostname")): dev 
            for dev in all_ddc1_devices if dev.get("hostname")
        }
        for future in as_completed(future_to_device):
            device_ref = future_to_device[future]
            try:
                unique_types, unique_vrfs, unique_protocols = future.result()
                device_ref["interfaceTypes"] = ", ".join(sorted(unique_types)) if unique_types else "N/A"
                device_ref["vrfNames"] = ", ".join(sorted(unique_vrfs)) if unique_vrfs else "None"
                device_ref["routingProtocols"] = ", ".join(sorted(unique_protocols)) if unique_protocols else "None"
            except Exception:
                device_ref["interfaceTypes"] = "Error"
                device_ref["vrfNames"] = "Error"

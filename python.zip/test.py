import csv
import getpass
import os
import re
import socket
import sys
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

USERNAME = input("Enter NetBrain Username: ").strip()
PASSWORD = getpass.getpass("Enter NetBrain Password: ").strip()

if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")

BASE_URL = os.getenv("NETBRAIN_URL", "https://netbrain.mckesson.com/ServicesAPI/API/V1")
DEFAULT_OUTPUT_DIR = os.path.expanduser("~/Downloads")
BASE_FILENAME = "ddc1_network_inventory.csv"


def get_unique_filepath(directory: str, filename: str) -> str:
    """Returns original path if it doesn't exist; otherwise appends date and time."""
    filepath = os.path.join(directory, filename)
    if os.path.exists(filepath):
        name, ext = os.path.splitext(filename)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{name}_{timestamp}{ext}"
        filepath = os.path.join(directory, filename)
    return filepath


OUTPUT_FILE = get_unique_filepath(DEFAULT_OUTPUT_DIR, BASE_FILENAME)

MAX_WORKERS = 10
INTF_WORKERS = 5
PAGE_LIMIT = 100

session = requests.Session()
session.verify = False
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


def authenticate() -> dict:
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    res = session.post(login_url, json=login_payload, timeout=15)
    if res.status_code != 200:
        raise RuntimeError(f"Auth failed ({res.status_code}): {res.text}")

    data = res.json()
    token = data.get("token")
    if not token:
        raise RuntimeError("Token missing in response payload.")

    session.headers.update(
        {
            "Token": token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
    )

    if data.get("tenantId") and data.get("domainId"):
        session.headers.update(
            {"tenantId": data.get("tenantId"), "domainId": data.get("domainId")}
        )

    return data


def fetch_all_devices() -> list:
    devices = []
    skip = 0
    while True:
        url = f"{BASE_URL}/CMDB/Devices"
        try:
            res = session.get(url, params={"skip": skip, "limit": PAGE_LIMIT}, timeout=30)
            if res.status_code != 200:
                break
            batch = res.json().get("devices", [])
            if not batch:
                break
            devices.extend(batch)
            skip += PAGE_LIMIT
        except requests.RequestException as err:
            print(f"Error fetching page at skip {skip}: {err}")
            break
    return devices


def extract_interface_type(intf_name: str) -> str:
    if not intf_name:
        return ""
    match = re.match(r"^([a-zA-Z-]+)", str(intf_name).strip())
    if match:
        prefix = match.group(1).rstrip("-")
        if len(prefix) >= 2:
            return prefix
    return ""


def extract_site_from_device(device: dict) -> str:
    for key in ["siteName", "site", "sitePath", "location", "site_name"]:
        val = device.get(key)
        if val and isinstance(val, str) and val.strip():
            return val.strip()

    hostname = device.get("name") or device.get("hostName") or device.get("hostname") or ""
    if hostname:
        parts = hostname.split("-")
        if parts:
            return parts[0].strip()

    return "DDC1"


def resolve_dns_info(hostname: str, mgmt_ip: str) -> str:
    """Performs forward or reverse DNS lookups to gather resolution details."""
    results = []

    # Forward lookup on Hostname
    if hostname:
        try:
            resolved_ip = socket.gethostbyname(hostname)
            results.append(f"A: {hostname} -> {resolved_ip}")
        except socket.gaierror:
            pass

    # Reverse lookup on Management IP
    if mgmt_ip:
        try:
            ptr_name, _, _ = socket.gethostbyaddr(mgmt_ip)
            results.append(f"PTR: {mgmt_ip} -> {ptr_name}")
        except (socket.herror, socket.gaierror):
            pass

    return "\n".join(results) if results else "N/A"


def fetch_single_interface_attr(hostname: str, intf_name: str) -> tuple:
    url = f"{BASE_URL}/CMDB/Interfaces/Attributes"
    try:
        r = session.get(url, params={"hostname": hostname, "interfaceName": intf_name}, timeout=10)
        if r.status_code == 200:
            attrs = r.json().get("attributes", {}).get(intf_name, {})

            vrf = attrs.get("mplsVrf", "").strip()
            nat_val = attrs.get("isNatIntf") or attrs.get("natType") or attrs.get("nat") or attrs.get("natMode")
            pat_val = attrs.get("isPatIntf") or attrs.get("patType") or attrs.get("pat") or attrs.get("patMode")

            found_ips = []
            ips_raw = attrs.get("ips")
            if isinstance(ips_raw, list):
                for item in ips_raw:
                    if isinstance(item, dict) and item.get("ipLoc"):
                        found_ips.append(item["ipLoc"])
                    elif isinstance(item, str) and item.strip():
                        found_ips.append(item.strip())
            elif isinstance(ips_raw, str) and ips_raw.strip():
                found_ips.append(ips_raw.strip())

            has_nat = bool(nat_val and str(nat_val).lower() not in ["false", "0", "disabled", "no", ""])
            has_pat = bool(pat_val and str(pat_val).lower() not in ["false", "0", "disabled", "no", ""])

            return intf_name, vrf, found_ips, has_nat, has_pat
    except requests.RequestException as e:
        print(f"Failed pulling attributes for {hostname} {intf_name}: {e}")
    return intf_name, "", [], False, False


def enrich_device_metadata(device: dict) -> tuple:
    hostname = device.get("name") or device.get("hostName") or device.get("hostname") or ""
    mgmt_ip = device.get("mgmtIP", "")

    dns_info = resolve_dns_info(hostname, mgmt_ip)

    types, vrfs, ip_addrs = set(), set(), set()
    nat_interfaces, pat_interfaces = set(), set()

    if not hostname:
        return dns_info, ["N/A"], ["default"], ["N/A"], "No", "No"

    url = f"{BASE_URL}/CMDB/Interfaces"
    try:
        r = session.get(url, params={"hostname": hostname}, timeout=15)
        if r.status_code == 200:
            intf_names = r.json().get("interfaces", [])

            for intf in intf_names:
                if_type = extract_interface_type(intf)
                if if_type:
                    types.add(if_type)

            with ThreadPoolExecutor(max_workers=INTF_WORKERS) as intf_executor:
                futures = [
                    intf_executor.submit(fetch_single_interface_attr, hostname, intf)
                    for intf in intf_names
                ]
                for future in as_completed(futures):
                    intf_name, vrf, ips, has_nat, has_pat = future.result()
                    if vrf and vrf.lower() not in ["none", "null", "undefined", "n/a", "0"]:
                        vrfs.add(vrf)
                    for ip in ips:
                        ip_addrs.add(ip)
                    if has_nat:
                        nat_interfaces.add(intf_name)
                    if has_pat:
                        pat_interfaces.add(intf_name)

    except requests.RequestException as e:
        print(f"Interface lookup failed for {hostname}: {e}")

    valid_vrfs = sorted(list(vrfs)) if vrfs else ["default"]
    nat_summary = "\n".join(sorted(nat_interfaces)) if nat_interfaces else "No"
    pat_summary = "\n".join(sorted(pat_interfaces)) if pat_interfaces else "No"

    return dns_info, list(types), valid_vrfs, list(ip_addrs), nat_summary, pat_summary


def main():
    authenticate()

    all_ddc1_devices = []
    seen_hostnames = set()
    all_discovered_columns = {
        "requestedSite",
        "dnsInformation",
        "interfaceTypes",
        "vrfNames",
        "interfaceIPs",
        "hasNAT",
        "hasPAT",
    }
    EXCLUDED_FIELDS = {"hostName", "hostname", "mgmtIP"}

    print("Fetching global CMDB devices...")
    devices_batch = fetch_all_devices()

    for device in devices_batch:
        hostname = device.get("hostName") or device.get("hostname") or device.get("name")

        if hostname and hostname not in seen_hostnames:
            searchable_fields = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()

            if "DDC1" in searchable_fields:
                seen_hostnames.add(hostname)
                flat_device = {"_raw_device": device}
                flat_device["requestedSite"] = extract_site_from_device(device)

                for k, v in device.items():
                    if k in EXCLUDED_FIELDS or any(
                        ex in k.lower() for ex in ["id", "discovery", "time"]
                    ):
                        continue
                    if k == "attributes" and isinstance(v, dict):
                        for sub_k, sub_v in v.items():
                            if sub_k not in EXCLUDED_FIELDS and not any(
                                ex in sub_k.lower() for ex in ["id", "discovery", "time"]
                            ):
                                flat_device[f"attr_{sub_k}"] = sub_v
                    else:
                        flat_device[k] = v

                all_discovered_columns.update(
                    k for k in flat_device if not k.startswith("_")
                )
                all_ddc1_devices.append(flat_device)

    print(f"Found {len(all_ddc1_devices)} DDC1 assets. Enriching metadata ({MAX_WORKERS} device workers)...")

    if all_ddc1_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(enrich_device_metadata, dev): dev
                for dev in all_ddc1_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    dns_info, types, vrfs, ips, nat_res, pat_res = future.result()
                    dev["dnsInformation"] = dns_info
                    dev["interfaceTypes"] = "\n".join(sorted(types)) if types else "N/A"
                    dev["vrfNames"] = "\n".join(vrfs)
                    dev["interfaceIPs"] = "\n".join(sorted(ips)) if ips else "N/A"
                    dev["hasNAT"] = nat_res
                    dev["hasPAT"] = pat_res
                except Exception as e:
                    print(f"Error enriching {dev.get('name')}: {e}")
                    dev["dnsInformation"] = "N/A"
                    dev["interfaceTypes"] = "N/A"
                    dev["vrfNames"] = "default"
                    dev["interfaceIPs"] = "N/A"
                    dev["hasNAT"] = "No"
                    dev["hasPAT"] = "No"
                finally:
                    dev.pop("_raw_device", None)

    primary_headers = ["name", "requestedSite", "dnsInformation", "interfaceIPs", "interfaceTypes", "vrfNames", "hasNAT", "hasPAT"]
    extra_headers = sorted(
        [
            col
            for col in all_discovered_columns
            if col not in primary_headers and col not in EXCLUDED_FIELDS
        ]
    )
    ordered_headers = primary_headers + extra_headers

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=ordered_headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(all_ddc1_devices)

    print(f"Export successful: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
# STP VLAN Report Script
# Includes conservative shutdown recommendation logic.

# NOTE: This is a template assembled from the conversation.
# Replace/extend with your environment-specific logic as needed.

import sys

def get_shutdown_recommendation(mac_count, arp_count, traffic_check, is_root, svi_ip=""):
    reasons = []

    if is_root:
        reasons.append("STP Root")

    if svi_ip:
        reasons.append("SVI Configured")

    if mac_count:
        reasons.append(f"{mac_count} MAC(s)")

    if arp_count:
        reasons.append(f"{arp_count} ARP(s)")

    if traffic_check == "TRAFFIC_DETECTED":
        reasons.append("Traffic Detected")

    if not reasons:
        reasons.append("No dependencies found - manual review required")

    return ("NONE", "; ".join(reasons))

if __name__ == "__main__":
    print("Use the shutdown recommendation function in your full script.")

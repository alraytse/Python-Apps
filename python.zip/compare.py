#!/usr/bin/env python3

import os
import hashlib


def sha256_file(filename):
    """Calculate SHA256 hash."""
    h = hashlib.sha256()

    with open(filename, "rb") as f:
        while chunk := f.read(8192):
            h.update(chunk)

    return h.hexdigest()


def find_first_difference(file1, file2):
    """Find first byte position of difference."""
    with open(file1, "rb") as f1, open(file2, "rb") as f2:

        position = 0

        while True:
            b1 = f1.read(1)
            b2 = f2.read(1)

            if not b1 and not b2:
                return None

            if b1 != b2:
                return position

            position += 1


def compare_files(file1, file2):

    if not os.path.isfile(file1):
        print(f"ERROR: File not found: {file1}")
        return

    if not os.path.isfile(file2):
        print(f"ERROR: File not found: {file2}")
        return

    size1 = os.path.getsize(file1)
    size2 = os.path.getsize(file2)

    hash1 = sha256_file(file1)
    hash2 = sha256_file(file2)

    print("\nComparison Results")
    print("=" * 60)

    print(f"File 1 : {file1}")
    print(f"Size   : {size1:,} bytes")
    print(f"SHA256 : {hash1}")

    print()

    print(f"File 2 : {file2}")
    print(f"Size   : {size2:,} bytes")
    print(f"SHA256 : {hash2}")

    print("\nResult")
    print("=" * 60)

    if hash1 == hash2:
        print("PASS - Files are binary identical.")
    else:
        print("FAIL - Files are different.")

        diff_pos = find_first_difference(file1, file2)

        if diff_pos is not None:
            print(
                f"First difference found at byte position: "
                f"{diff_pos:,}"
            )


def main():

    print("\nCSV Binary Compare Tool\n")

    file1 = input(
        "Enter first CSV filename: "
    ).strip()

    file2 = input(
        "Enter second CSV filename: "
    ).strip()

    compare_files(file1, file2)


if __name__ == "__main__":
    main()
#!/usr/bin/env python3

import pandas as pd
import re
import os
import sys

IP_REGEX = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'


def extract_ips(value):
    """
    Extract all IPv4 addresses from a field.
    Handles HTML breaks, line breaks, and extra text.
    """
    if pd.isna(value):
        return []

    text = str(value)

    # Cleanup common delimiters
    text = text.replace("<br>", " ")
    text = text.replace("<br/>", " ")
    text = text.replace("<br />", " ")
    text = text.replace('<br aria-hidden="true">', " ")
    text = text.replace("\n", " ")
    text = text.replace("\r", " ")

    return re.findall(IP_REGEX, text)


def read_csv_with_fallback(file_name):
    """
    Attempt multiple encodings since the inventory file
    contains non-UTF8 characters.
    """
    encodings = [
        "utf-8",
        "utf-8-sig",
        "cp1252",
        "latin1"
    ]

    for encoding in encodings:
        try:
            print(f"Trying encoding: {encoding}")
            return pd.read_csv(
                file_name,
                dtype=str,
                encoding=encoding,
                low_memory=False,
                on_bad_lines="skip"
            )
        except UnicodeDecodeError:
            continue

    raise Exception("Unable to determine file encoding.")


def main():

    file_name = input("Enter CSV file name: ").strip()

    if not os.path.isfile(file_name):
        print(f"ERROR: File not found: {file_name}")
        sys.exit(1)

    try:
        df = read_csv_with_fallback(file_name)

        print(f"\nSuccessfully loaded {len(df)} rows.\n")

        cormant_col = None
        ip_col = None

        for col in df.columns:

            col_name = str(col).strip().lower()

            if col_name == "cormant name":
                cormant_col = col

            elif col_name == "ip address":
                ip_col = col

        if not cormant_col:
            print("ERROR: Could not locate 'Cormant Name' column.")
            print("\nColumns found:")
            for col in df.columns:
                print(f"  {col}")
            sys.exit(1)

        if not ip_col:
            print("ERROR: Could not locate 'IP Address' column.")
            print("\nColumns found:")
            for col in df.columns:
                print(f"  {col}")
            sys.exit(1)

        rows = []

        for _, row in df.iterrows():

            device = str(row.get(cormant_col, "")).strip()

            if not device.upper().startswith("DDC1"):
                continue

            ips = extract_ips(row.get(ip_col, ""))

            for ip in ips:
                rows.append({
                    "Device Name": device,
                    "IP Address": ip
                })

        if not rows:
            print("No DDC1 IP addresses found.")
            sys.exit(0)

        output_df = pd.DataFrame(rows)

        # Remove duplicate device/IP pairs
        output_df = output_df.drop_duplicates()

        output_file = "ddc1_device_ips.csv"

        output_df.to_csv(
            output_file,
            index=False
        )

        print(f"Total records: {len(output_df)}")
        print(f"Results saved to: {output_file}")

        print("\nFirst 10 records:\n")
        print(output_df.head(10).to_string(index=False))

    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
#!/usr/bin/env python3

import csv
import ipaddress
import socket
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed

INFOBLOX_FILE = "infoblox_networks.csv"
OUTPUT_FILE = "azure_endpoint_validation.csv"

ENDPOINTS = [
    ("aka.ms", 443),
    ("azurestackreleases.download.prss.microsoft.com", 443),
    ("login.microsoftonline.com", 443),
    ("management.azure.com", 443),
    ("gbl.his.arc.azure.com", 443),
    ("ocsp.digicert.com", 80),
    ("s.symcd.com", 80),
    ("ts-ocsp.ws.symantec.com", 80),
    ("ocsp.globalsign.com", 80),
    ("ocsp2.globalsign.com", 80),
    ("oneocsp.microsoft.com", 80),
    ("crl.microsoft.com", 80),
    ("dl.delivery.mp.microsoft.com", 443),
    ("agentserviceapi.guestconfiguration.azure.com", 443),
    ("azgn-eastus-public-1p-cusdm-vazr0001.servicebus.windows.net", 443),
    ("azgn-eastus-public-2p-cusdm-vazr0002.servicebus.windows.net", 443),
    ("dp.stackhci.azure.com", 443),
    ("eastus-gas.guestconfiguration.azure.com", 443),
    ("eastus-mdm.prod.hot.ingest.monitor.core.windows.net", 443),
    ("eastus-shared.prod.warm.ingest.monitor.core.windows.net", 443),
    ("gcs.prod.monitoring.core.windows.net", 443),
    ("global.prod.microsoftmetrics.com", 443),
    ("guestnotificationservice.azure.com", 443),
    ("login.microsoft.com", 443),
    ("packages.microsoft.com", 443),
    ("pas.windows.net", 443),
    ("prod6.prod.microsoftmetrics.com", 443),
]

def load_networks(csv_file):
    """
    Reads Infoblox exported CSV.
    Looks for a column containing CIDR networks.
    """
    df = pd.read_csv(csv_file)

    network_column = None

    for col in df.columns:
        lcol = col.lower()
        if lcol in ["network", "cidr", "subnet"]:
            network_column = col
            break

    if not network_column:
        raise ValueError(
            f"Could not find network column. Found columns: {list(df.columns)}"
        )

    networks = []

    for value in df[network_column].dropna():
        try:
            networks.append(ipaddress.ip_network(str(value).strip(), strict=False))
        except Exception:
            pass

    return networks


def find_matching_network(ip_addr, networks):
    try:
        ip = ipaddress.ip_address(ip_addr)

        for net in networks:
            if ip in net:
                return str(net)

    except Exception:
        pass

    return ""


def tcp_test(hostname, port, timeout=5):
    try:
        sock = socket.create_connection((hostname, port), timeout=timeout)
        sock.close()
        return True
    except Exception:
        return False


def process_endpoint(endpoint_info, networks):

    hostname, port = endpoint_info

    result = {
        "hostname": hostname,
        "port": port,
        "dns_status": "FAILED",
        "resolved_ips": "",
        "tcp_status": "FAILED",
        "matching_infoblox_networks": ""
    }

    try:

        ips = sorted(
            list(
                {
                    item[4][0]
                    for item in socket.getaddrinfo(hostname, None)
                }
            )
        )

        result["dns_status"] = "SUCCESS"
        result["resolved_ips"] = ",".join(ips)

        matching = []

        for ip in ips:
            network = find_matching_network(ip, networks)

            if network:
                matching.append(network)

        result["matching_infoblox_networks"] = ",".join(sorted(set(matching)))

    except Exception as e:
        result["dns_status"] = f"FAILED ({str(e)})"

    result["tcp_status"] = (
        "SUCCESS" if tcp_test(hostname, port) else "FAILED"
    )

    return result


def main():

    print("\nLoading Infoblox networks...")

    networks = load_networks(INFOBLOX_FILE)

    print(f"Loaded {len(networks)} networks\n")

    results = []

    with ThreadPoolExecutor(max_workers=20) as executor:

        futures = {
            executor.submit(process_endpoint, ep, networks): ep
            for ep in ENDPOINTS
        }

        for future in as_completed(futures):

            result = future.result()

            print(
                f"{result['hostname']:<70} "
                f"DNS:{result['dns_status']:<15} "
                f"TCP:{result['tcp_status']}"
            )

            results.append(result)

    pd.DataFrame(results).to_csv(
        OUTPUT_FILE,
        index=False
    )

    print("\nReport written to:")
    print(f"  {OUTPUT_FILE}")

    dns_success = sum(
        1 for r in results
        if str(r["dns_status"]).startswith("SUCCESS")
    )

    tcp_success = sum(
        1 for r in results
        if r["tcp_status"] == "SUCCESS"
    )

    print("\nSummary")
    print("-------")
    print(f"Endpoints Tested : {len(results)}")
    print(f"DNS Success      : {dns_success}")
    print(f"TCP Success      : {tcp_success}")


if __name__ == "__main__":
    main()
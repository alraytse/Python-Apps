#!/usr/bin/env python3

import csv
import getpass
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

from netmiko import ConnectHandler
from netmiko.exceptions import (
    NetmikoAuthenticationException,
    NetmikoTimeoutException,
)

TARGET_VLANS = [
    "10",
    "30",
    "40",
    "50",
    "129",
    "200",
    "418",
    "859",
    "1606",
    "1700",
    "1710",
]

CSV_FILE = "uson_vlan_extension_report.csv"


def detect_device(host, username, password):

    for device_type in ["cisco_nxos", "cisco_ios"]:

        try:
            conn = ConnectHandler(
                device_type=device_type,
                host=host,
                username=username,
                password=password,
                fast_cli=False,
            )

            hostname = conn.find_prompt().rstrip("#>")
            return conn, hostname, device_type

        except Exception:
            continue

    return None, None, None


def vlan_exists(conn, vlan):

    output = conn.send_command(
        f"show vlan id {vlan}",
        read_timeout=30,
    )

    if (
        "not found" in output.lower()
        or "invalid vlan" in output.lower()
    ):
        return False, ""

    vlan_name = ""

    for line in output.splitlines():

        match = re.search(
            rf"^{vlan}\s+(\S+)",
            line.strip(),
        )

        if match:
            vlan_name = match.group(1)

    return True, vlan_name


def get_svi_info(conn, vlan):

    svi = f"Vlan{vlan}"

    try:

        output = conn.send_command(
            f"show interface {svi}",
            read_timeout=30,
        )

        if "Invalid" in output:
            return False, "", ""

        status_match = re.search(
            r"is\s+(\w+),\s+line protocol is\s+(\w+)",
            output,
            re.IGNORECASE,
        )

        if status_match:
            status = (
                f"{status_match.group(1)}/"
                f"{status_match.group(2)}"
            )
        else:
            status = ""

    except Exception:
        return False, "", ""

    ip = ""

    try:

        ip_output = conn.send_command(
            f"show run interface {svi}",
            read_timeout=30,
        )

        ip_match = re.search(
            r"ip address\s+(\S+)",
            ip_output,
            re.IGNORECASE,
        )

        if ip_match:
            ip = ip_match.group(1)

    except Exception:
        pass

    return True, ip, status


def check_stp_root(conn, vlan):

    try:

        output = conn.send_command(
            f"show spanning-tree vlan {vlan}",
            read_timeout=30,
        )

        if "This bridge is the root" in output:
            return "Yes"

        if "Root ID" in output:
            return "No"

    except Exception:
        pass

    return "Unknown"


def collect_switch(host, username, password):

    rows = []

    conn, hostname, platform = detect_device(
        host,
        username,
        password,
    )

    if not conn:

        return [{
            "Switch": host,
            "Management_IP": host,
            "Platform": "",
            "VLAN": "",
            "VLAN_Name": "",
            "Exists": "Connection Failed",
            "SVI_Present": "",
            "SVI_IP": "",
            "SVI_Status": "",
            "STP_Root": "",
        }]

    print(f"Connected to {hostname}")

    for vlan in TARGET_VLANS:

        try:

            exists, vlan_name = vlan_exists(
                conn,
                vlan,
            )

            if exists:

                svi_present, svi_ip, svi_status = (
                    get_svi_info(
                        conn,
                        vlan,
                    )
                )

                stp_root = check_stp_root(
                    conn,
                    vlan,
                )

            else:

                svi_present = False
                svi_ip = ""
                svi_status = ""
                stp_root = ""

            rows.append({
                "Switch": hostname,
                "Management_IP": host,
                "Platform": platform,
                "VLAN": vlan,
                "VLAN_Name": vlan_name,
                "Exists": "Yes" if exists else "No",
                "SVI_Present": (
                    "Yes"
                    if svi_present
                    else "No"
                ),
                "SVI_IP": svi_ip,
                "SVI_Status": svi_status,
                "STP_Root": stp_root,
            })

        except Exception as e:

            rows.append({
                "Switch": hostname,
                "Management_IP": host,
                "Platform": platform,
                "VLAN": vlan,
                "VLAN_Name": "",
                "Exists": f"Error: {str(e)}",
                "SVI_Present": "",
                "SVI_IP": "",
                "SVI_Status": "",
                "STP_Root": "",
            })

    conn.disconnect()

    return rows


def main():

    print("\nUSON VLAN Extension Discovery Tool\n")

    hosts = input(
        "Enter switch hostnames/IPs (comma delimited): "
    )

    username = input("Username: ")
    password = getpass.getpass("Password: ")

    host_list = [
        h.strip()
        for h in hosts.split(",")
        if h.strip()
    ]

    all_rows = []

    workers = min(
        10,
        max(1, len(host_list))
    )

    with ThreadPoolExecutor(
        max_workers=workers
    ) as executor:

        futures = {
            executor.submit(
                collect_switch,
                host,
                username,
                password,
            ): host
            for host in host_list
        }

        for future in as_completed(futures):

            host = futures[future]

            try:
                rows = future.result()
                all_rows.extend(rows)

            except Exception as exc:

                print(
                    f"{host} failed: {exc}"
                )

    with open(
        CSV_FILE,
        "w",
        newline="",
        encoding="utf-8",
    ) as csvfile:

        fields = [
            "Switch",
            "Management_IP",
            "Platform",
            "VLAN",
            "VLAN_Name",
            "Exists",
            "SVI_Present",
            "SVI_IP",
            "SVI_Status",
            "STP_Root",
        ]

        writer = csv.DictWriter(
            csvfile,
            fieldnames=fields,
        )

        writer.writeheader()
        writer.writerows(all_rows)

    print(
        f"\nReport written to {CSV_FILE}"
    )

    print(
        f"Total records: {len(all_rows)}"
    )


if __name__ == "__main__":
    main()
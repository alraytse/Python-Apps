#!/usr/bin/env python3

import getpass
import csv
import re
from netmiko import ConnectHandler

CSV_FILE = "stp_vlan_report.csv"


def parse_vlans(output):
    vlans = []
    for line in output.splitlines():
        match = re.match(r"^(\d+)\s+([^\s]+)", line.strip())
        if match:
            vlans.append({"vlan": match.group(1), "name": match.group(2)})
    return vlans


def check_root(connection, vlan):
    try:
        output = connection.send_command(
            f"show spanning-tree vlan {vlan}",
            read_timeout=30
        )
        return "This bridge is the root" in output
    except Exception:
        return False


def get_svi_info(connection, vlan):
    try:
        output = connection.send_command(
            f"show run interface vlan {vlan}",
            read_timeout=30
        )

        description = ""
        ip_address = ""

        for line in output.splitlines():
            line = line.strip()

            if line.startswith("description "):
                description = line.replace("description ", "")
            elif line.startswith("ip address "):
                ip_address = line.replace("ip address ", "")

        return description, ip_address

    except Exception:
        return "", ""


def get_dynamic_mac_count(connection, vlan):
    try:
        output = connection.send_command(
            f"show mac address-table vlan {vlan}",
            read_timeout=60
        )

        count = 0
        for line in output.splitlines():
            if "dynamic" in line.lower():
                count += 1

        return count

    except Exception:
        return 0


def get_arp_count(connection, vlan):

    commands = [
        f"show ip arp vlan {vlan}",
        f"show arp vlan {vlan}"
    ]

    for cmd in commands:
        try:
            output = connection.send_command(
                cmd,
                read_timeout=60
            )

            count = 0
            for line in output.splitlines():
                if re.match(r"^\d+\.\d+\.\d+\.\d+", line.strip()):
                    count += 1

            return count

        except Exception:
            pass

    return 0


def get_hostname(connection):
    prompt = connection.find_prompt()
    return prompt.replace("#", "").replace(">", "")


def process_switch(device):

    results = []

    try:
        print(f"\nConnecting to {device['host']}...")

        conn = ConnectHandler(**device)

        hostname = get_hostname(conn)

        vlan_output = conn.send_command(
            "show vlan brief",
            read_timeout=60
        )

        vlans = parse_vlans(vlan_output)

        print(f"{hostname}: Found {len(vlans)} VLANs")

        for vlan_info in vlans:
            vlan_id = vlan_info['vlan']
            vlan_name = vlan_info['name']

            is_root = check_root(conn, vlan_id)
            svi_description, svi_ip = get_svi_info(conn, vlan_id)
            dynamic_mac_count = get_dynamic_mac_count(conn, vlan_id)
            arp_count = get_arp_count(conn, vlan_id)

            results.append({
                'Device': hostname,
                'VLAN': vlan_id,
                'VLAN_Name': vlan_name,
                'SVI_IP': svi_ip,
                'SVI_Description': svi_description,
                'Dynamic_MACs': dynamic_mac_count,
                'ARP_Count': arp_count,
                'Root_Bridge': 'YES' if is_root else 'NO'
            })

        conn.disconnect()

    except Exception as e:
        print(f"Failed to connect to {device['host']} : {e}")

    return results


def write_csv(results):

    fields = [
        'Device',
        'VLAN',
        'VLAN_Name',
        'SVI_IP',
        'SVI_Description',
        'Dynamic_MACs',
        'ARP_Count',
        'Root_Bridge'
    ]

    with open(CSV_FILE, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fields)
        writer.writeheader()
        for row in results:
            writer.writerow(row)


def display_results(results):

    print('
' + '=' * 180)
    print('VLAN / SVI / STP ROOT / DYNAMIC MAC / ARP REPORT')
    print('=' * 180)

    current_device = ''

    for row in results:

        if row['Device'] != current_device:
            current_device = row['Device']

            print(f"
Switch: {current_device}")
            print('-' * 180)
            print(
                f"{'VLAN':<8}"
                f"{'VLAN Name':<30}"
                f"{'SVI IP':<25}"
                f"{'MACs':<10}"
                f"{'ARPs':<10}"
                f"{'SVI Description':<70}"
                f"{'Root':<10}"
            )
            print('-' * 180)

        print(
            f"{row['VLAN']:<8}"
            f"{row['VLAN_Name']:<30}"
            f"{row['SVI_IP']:<25}"
            f"{str(row['Dynamic_MACs']):<10}"
            f"{str(row['ARP_Count']):<10}"
            f"{row['SVI_Description']:<70}"
            f"{row['Root_Bridge']:<10}"
        )

    root_count = sum(1 for row in results if row['Root_Bridge'] == 'YES')
    total_macs = sum(int(row['Dynamic_MACs']) for row in results)
    total_arps = sum(int(row['ARP_Count']) for row in results)

    print('
' + '=' * 180)
    print(f'Total VLANs Processed : {len(results)}')
    print(f'Total Root VLANs      : {root_count}')
    print(f'Total Dynamic MACs    : {total_macs}')
    print(f'Total ARP Entries     : {total_arps}')
    print('=' * 180)


def main():

    hosts = input('Enter switch hostnames/IPs (comma separated): ').strip()
    host_list = [h.strip() for h in hosts.split(',') if h.strip()]

    platform = input('Platform (nxos/iosxe): ').strip().lower()
    device_type = 'cisco_ios' if platform == 'iosxe' else 'cisco_nxos'

    username = input('Username: ')
    password = getpass.getpass('Password: ')

    all_results = []

    for host in host_list:
        device = {
            'device_type': device_type,
            'host': host,
            'username': username,
            'password': password,
            'fast_cli': False
        }

        all_results.extend(process_switch(device))

    all_results = sorted(
        all_results,
        key=lambda x: (x['Device'], int(x['VLAN']))
    )

    display_results(all_results)
    write_csv(all_results)

    print(f'
CSV report saved to: {CSV_FILE}')


if __name__ == '__main__':
    main()

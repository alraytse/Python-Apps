#!/usr/bin/env python3

import os

def main():
    filename = input("Enter input filename: ").strip()

    if not os.path.isfile(filename):
        print(f"File not found: {filename}")
        return

    with open(filename, "r") as f:
        values = [line.strip() for line in f if line.strip()]

    output_file = (
        os.path.splitext(filename)[0]
        + "_horizontal.txt"
    )

    with open(output_file, "w") as f:
        f.write(",".join(values))

    print(f"\nProcessed {len(values)} records")
    print(f"Output file: {output_file}")

if __name__ == "__main__":
    main()

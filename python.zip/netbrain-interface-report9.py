"""
NetBrain Interface Report
==========================

Generates a per-interface CSV audit report for devices at a given NetBrain
site, using the NetBrain REST API (CMDB/Devices and CMDB/Interfaces
endpoints).

Interface
---------
Inputs (interactive prompts):
    NetBrain Username   - str, required. NetBrain login username.
    NetBrain Password   - str, required (hidden input). NetBrain login password.
    Target Site         - str, optional. Site code to filter devices by
                           (matched against hostname, mgmt IP, and subtype).
                           Defaults to "DDC1" if left blank.

Device type scope:
    Only devices whose type/family/vendor/model metadata matches one of the
    categories in TARGET_DEVICE_TYPES (constant, edit in source) are included.
    Currently scoped to: Firewalls only.
    See DEVICE_TYPE_KEYWORDS for the keyword lists used for each category.

Configuration (constants, edit in source to change):
    BASE_URL       - NetBrain Services API base URL.
    MAX_WORKERS    - Thread pool size for concurrent device enrichment (default 10).
    PAGE_LIMIT     - Page size when paginating the CMDB Devices endpoint (default 100).
    LIMIT_DEVICES  - Max number of matching devices to process (default 375).

Output:
    A CSV file written to:
        ~/Downloads/{TARGET_SITE}.netbrain.interface.report.{TIMESTAMP}.csv
    One row per device interface, with columns including:
        name, requestedSite, serialNumber, hardwareModel,
        interfaceName, interfaceDescription, interfaceSpeed, resolvedIP,
        vrfNames, securityZone, natInterface, patInterface,
        natInterfaceDetail, patInterfaceDetail, plus any additional device
        attributes discovered from the API response.
        securityZone is populated only for devices detected as firewalls
        (see FIREWALL_KEYWORDS / is_firewall_device); it is "N/A" for
        all other device types.
        natInterfaceDetail / patInterfaceDetail give the actual NAT/PAT
        rule detail (rule name + translated IP/port info) parsed from the
        firewall's live NAT rulebase, when available -- "N/A" when there's
        no rulebase to check, or "No NAT rules"/"No PAT rules" when the
        rulebase was retrieved but the interface's zone has none.

    When NETBRAIN_DEBUG=1 is set, a separate debug log file is written to:
        ~/Downloads/{TARGET_SITE}.netbrain.debug.{TIMESTAMP}.log
    containing per-device/per-interface diagnostics (firewall detection,
    NAT/PAT rulebase fetch HTTP status + response previews, raw interface
    attribute dumps). Console output stays limited to progress messages
    (fetching/enriching/export status) -- all [DEBUG]-level detail goes to
    this file instead of the terminal.

Usage:
    python netbrain-interface-report.py

Requires network access to the NetBrain API host and valid NetBrain
credentials. SSL certificate verification is disabled for API requests.
"""

import csv
import getpass
import logging
import os
import re
import socket
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import requests
import urllib3

# Disable insecure HTTPS warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Set NETBRAIN_DEBUG=1 in the environment to write diagnostic info about
# firewall detection, NAT/PAT rulebase fetches, and raw interface attribute
# keys/values as returned by the NetBrain API to a dedicated debug log file
# (see DEBUG_LOG_FILE below), rather than the console. Use this to confirm
# the real field names for security zone data if securityZone is coming
# back as "N/A" unexpectedly, or to diagnose why NAT/PAT lookups are failing.
DEBUG_ZONES = os.environ.get("NETBRAIN_DEBUG", "").strip().lower() in ("1", "true", "yes")

# ---------------------------------------------------------------------------
# Interactive Inputs & Configuration
# ---------------------------------------------------------------------------
USERNAME = input("Enter NetBrain Username: ").strip()
PASSWORD = getpass.getpass("Enter NetBrain Password: ").strip()

site_input = input("Enter Target Site [default: DDC1]: ").strip().upper()
TARGET_SITE = site_input if site_input else "DDC1"

if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
OUTPUT_FILE = os.path.expanduser(
    f"~/Downloads/{TARGET_SITE}.netbrain.interface.report.{TIMESTAMP}.csv"
)
DEBUG_LOG_FILE = os.path.expanduser(
    f"~/Downloads/{TARGET_SITE}.netbrain.debug.{TIMESTAMP}.log"
)

# Dedicated logger for [DEBUG] diagnostics -- kept separate from the console
# progress messages (print statements) so debug output goes to its own file
# instead of cluttering the terminal. logging.FileHandler is thread-safe
# (it acquires an internal lock per emit), which matters here since debug
# calls happen concurrently across the ThreadPoolExecutor workers.
debug_logger = logging.getLogger("netbrain_debug")
debug_logger.setLevel(logging.DEBUG if DEBUG_ZONES else logging.CRITICAL + 1)
debug_logger.propagate = False
if DEBUG_ZONES:
    _debug_handler = logging.FileHandler(DEBUG_LOG_FILE, mode="w", encoding="utf-8")
    _debug_handler.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
    debug_logger.addHandler(_debug_handler)
    print(f"Debug logging enabled -> {DEBUG_LOG_FILE}")

MAX_WORKERS = 10
PAGE_LIMIT = 100
LIMIT_DEVICES = 10 # Cap processing to 3 devices

# NAT rulebase fetch (fetch_nat_policy_raw) configuration -- overridable via
# environment variables so alternate NetBrain DeviceRawData parameters can be
# tried without editing source.
#
# CONFIRMED (via NETBRAIN_DEBUG testing against this NetBrain instance):
#   - dataType is only valid in the range 0-2 (dataType=4 -> NetBrain error
#     792005 "'dataType' should be between 0 and 2 inclusive").
#   - dataType=1 expects a 'tableName' parameter instead of 'cmd' -- it's a
#     structured table lookup, not a CLI passthrough, so it's not usable
#     for arbitrary commands like this (NetBrain error 791001).
#   - dataType=2 (the default, and the type this docstring originally
#     assumed was "CLI command") returns HTTP 200 but "Device Data Not
#     Found" (NetBrain error 791006) for "show running nat-policy" on every
#     device tested -- the command likely isn't in NetBrain's cached Live
#     Access command set for this device type in this environment.
#   - dataType=0 returns HTTP 200 but silently ignores 'cmd' and returns an
#     unrelated canned raw-data dump instead (observed: a "show system
#     info" transcript, not the requested command) -- see the cmd-echo
#     validation in fetch_nat_policy_raw, which now catches and rejects
#     this rather than misreporting it as real NAT data.
#   None of 0/1/2/4 actually retrieved the NAT rulebase in testing. This
#   looks like it needs a NetBrain-side fix (adding "show running
#   nat-policy" to the cached Live Access command set for Palo Alto
#   devices) rather than a different dataType value -- but the knobs below
#   are kept in case a different command string or a newly-added dataType
#   ends up working.
#
#   NETBRAIN_NAT_CMD                 - CLI command string sent as 'cmd'.
#                                       Default: "show running nat-policy"
#   NETBRAIN_NAT_DATATYPE_CANDIDATES - comma-separated list of 'dataType'
#                                       values to try, in order, per device
#                                       (valid range: 0-2). The first one
#                                       that returns HTTP 200 AND echoes
#                                       NAT_CMD in its content is used for
#                                       that device; others are skipped as
#                                       mismatches/failures. Default: "2"
#                                       (preserves original single-attempt
#                                       behavior). Example:
#                                       NETBRAIN_NAT_DATATYPE_CANDIDATES="2,1,0"
NAT_CMD = os.environ.get("NETBRAIN_NAT_CMD", "show running nat-policy")
_nat_datatype_raw = os.environ.get("NETBRAIN_NAT_DATATYPE_CANDIDATES", "2")
NAT_DATATYPE_CANDIDATES = [
    int(v.strip()) for v in _nat_datatype_raw.split(",") if v.strip().lstrip("-").isdigit()
] or [2]


if DEBUG_ZONES and len(NAT_DATATYPE_CANDIDATES) > 1:
    print(
        f"Testing {len(NAT_DATATYPE_CANDIDATES)} dataType candidates for NAT rulebase "
        f"fetch: {NAT_DATATYPE_CANDIDATES} (cmd={NAT_CMD!r}) -- see debug log for per-attempt results."
    )

session = requests.Session()
session.verify = False

# Optimize HTTP connection pool
adapter = requests.adapters.HTTPAdapter(
    pool_connections=50, 
    pool_maxsize=50, 
    max_retries=2
)
session.mount("https://", adapter)
session.mount("http://", adapter)

DNS_CACHE = {}


def authenticate() -> dict:
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    try:
        res = session.post(login_url, json=login_payload, timeout=60)
        res.raise_for_status()
    except requests.exceptions.RequestException as e:
        sys.exit(f"Auth error: {e}")

    data = res.json()
    token = data.get("token") or data.get("tokenID")
    if not token:
        sys.exit("Error: Token missing in response payload.")

    session.headers.update({
        "Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json"
    })

    if "tenantId" in data and "domainId" in data:
        session.headers.update({
            "tenantId": str(data["tenantId"]),
            "domainId": str(data["domainId"])
        })
    return data


def fetch_all_devices() -> list:
    """Dynamically paginates through NetBrain CMDB devices until limit or end is reached."""
    all_devices = []
    skip = 0

    while True:
        url = f"{BASE_URL}/CMDB/Devices"
        try:
            res = session.get(url, params={"skip": skip, "limit": PAGE_LIMIT}, timeout=30)
            if res.status_code != 200:
                break
            
            devices = res.json().get("devices", [])
            if not devices:
                break

            all_devices.extend(devices)
            skip += PAGE_LIMIT
            
            if len(devices) < PAGE_LIMIT:
                break
        except requests.RequestException:
            break

    return all_devices


def fetch_device_attributes(hostname: str) -> dict:
    """Queries CMDB Device Attributes passing attributeNames=sn,model."""
    url = f"{BASE_URL}/CMDB/Devices/Attributes"
    params = {
        "hostname": hostname,
        "attributeNames": "sn,serialNumber,model"
    }
    try:
        res = session.get(url, params=params, timeout=15)
        if res.status_code == 200:
            return res.json().get("attributes", {})
    except requests.RequestException:
        pass
    return {}


def fetch_all_interface_attrs(hostname: str) -> dict:
    """Retrieves all interface attributes for a given hostname in a single API call."""
    url = f"{BASE_URL}/CMDB/Interfaces/Attributes"
    try:
        r = session.get(url, params={"hostname": hostname}, timeout=15)
        if r.status_code == 200:
            return r.json().get("attributes", {})
    except requests.RequestException:
        pass
    return {}


def fetch_nat_policy_raw(hostname: str) -> str:
    """Fetches the live NAT rulebase for a firewall via NetBrain's DeviceRawData
    passthrough (CMDB/Devices/DeviceRawData).

    Tries each dataType value in NAT_DATATYPE_CANDIDATES (in order) with the
    command NAT_CMD, stopping at the first HTTP 200 response whose content
    actually appears to correspond to the requested command (see the
    cmd-echo check below) -- regardless of whether the resulting content is
    otherwise empty, since a matched 200 means NetBrain accepted and
    executed that dataType/cmd combination for this device (an empty
    rulebase is a valid real-world result). Non-200 responses (e.g.
    "Device Data Not Found") are treated as "this dataType didn't work for
    this device" and the next candidate is tried.

    IMPORTANT -- cmd-echo validation: some dataType values (observed:
    dataType=0 on this NetBrain instance) return HTTP 200 but silently
    ignore the 'cmd' parameter, instead returning an unrelated canned raw
    data dump (e.g. a "show system info" transcript bundled with a bulk
    device-info blob) rather than actually running NAT_CMD. Trusting that
    response would misreport "No NAT rules" for zones that were never
    actually checked -- a false negative, not a confirmed fact. To guard
    against this, a 200 response is only accepted if NAT_CMD's text
    actually appears (case-insensitively) somewhere in the returned
    content; otherwise it's logged as a mismatch and the next candidate
    (if any) is tried, exactly like a non-200 response.

    NOTE: "show running nat-policy" (the default NAT_CMD) is Palo
    Alto-specific. On other firewall vendors (ASA, Fortinet, Check Point)
    this command will simply fail/return no usable content across all
    candidates, and callers correctly fall back to N/A rather than
    reporting "No" -- see the empty-string return contract below.

    Returns "" if every candidate fails or mismatches (unreachable,
    unsupported command, bad response, cmd not echoed). Callers MUST treat
    "" as "lookup unavailable" and must NOT interpret it as "no NAT
    configured" -- those are different facts.

    With NETBRAIN_DEBUG=1 set, logs the HTTP status code, a preview of the
    response body, and any exception encountered, per hostname and per
    dataType candidate tried -- so a 100%-N/A NAT/PAT result across a run
    can be diagnosed (permissions vs. unsupported command/dataType vs.
    API/timeout issue vs. cmd-echo mismatch) without guessing.
    """
    url = f"{BASE_URL}/CMDB/Devices/DeviceRawData"

    for data_type in NAT_DATATYPE_CANDIDATES:
        params = {"hostname": hostname, "dataType": data_type, "cmd": NAT_CMD}
        try:
            res = session.get(url, params=params, timeout=30)

            if DEBUG_ZONES:
                body_preview = res.text[:300].replace("\n", " ") if res.text else "(empty body)"
                debug_logger.debug(
                    f"[DEBUG] fetch_nat_policy_raw({hostname}, dataType={data_type}): "
                    f"HTTP {res.status_code} | body_preview={body_preview!r}"
                )

            if res.status_code == 200:
                content = res.json().get("content", "") or ""

                if NAT_CMD.lower() not in content.lower():
                    if DEBUG_ZONES:
                        content_preview = content[:300].replace("\n", " ") if content else "(empty content field)"
                        debug_logger.debug(
                            f"[DEBUG] fetch_nat_policy_raw({hostname}, dataType={data_type}): "
                            f"HTTP 200 but requested cmd {NAT_CMD!r} not found/echoed in "
                            f"content (content_length={len(content)}) -- NetBrain likely "
                            f"ignored 'cmd' and returned unrelated data for this dataType; "
                            f"discarding and trying next candidate if any "
                            f"| content_preview={content_preview!r}"
                        )
                    continue

                if DEBUG_ZONES:
                    content_preview = content[:300].replace("\n", " ") if content else "(empty content field)"
                    debug_logger.debug(
                        f"[DEBUG] fetch_nat_policy_raw({hostname}, dataType={data_type}): "
                        f"SUCCEEDED (cmd echoed, stopping candidate search) | "
                        f"content_length={len(content)} | content_preview={content_preview!r}"
                    )
                return content

            if DEBUG_ZONES:
                debug_logger.debug(
                    f"[DEBUG] fetch_nat_policy_raw({hostname}, dataType={data_type}): "
                    f"non-200 status ({res.status_code}) -- trying next candidate if any"
                )
        except (requests.RequestException, ValueError) as e:
            if DEBUG_ZONES:
                debug_logger.debug(
                    f"[DEBUG] fetch_nat_policy_raw({hostname}, dataType={data_type}): "
                    f"EXCEPTION {type(e).__name__}: {e} -- trying next candidate if any"
                )

    if DEBUG_ZONES:
        debug_logger.debug(
            f"[DEBUG] fetch_nat_policy_raw({hostname}): ALL {len(NAT_DATATYPE_CANDIDATES)} "
            f"dataType candidate(s) failed or mismatched -- treating as lookup unavailable"
        )
    return ""


# Matches one PAN-OS NAT rule block, e.g.:
#   "Meraki_Public-to-intraf-34-1; index: 1" {
#           nat-type ipv4;
#           from buINTRAFUSION;
#           ...
#           translate-to "src: 143.112.197.34 (static-ip) (pool idx: 1)";
#           terminal no;
#   }
_NAT_RULE_BLOCK_RE = re.compile(r'"([^"]+);\s*index:\s*(\d+)"\s*\{(.*?)\n\}', re.DOTALL)
_NAT_FIELD_RE = re.compile(r'^\s*([\w-]+)\s+(.*?);\s*$', re.MULTILINE)


def _split_zone_list(raw: str) -> list:
    """Parses a PAN-OS 'from'/'to' field value, which may be a single zone
    name, an 'any', or a bracketed list like '[ zoneA zoneB ]'."""
    raw = raw.strip()
    if raw.startswith("[") and raw.endswith("]"):
        return [z for z in raw[1:-1].split() if z]
    if raw and raw.lower() != "any":
        return [raw]
    return []


# NetBrain's dataType=0 raw-data dump returns one giant transcript
# containing the concatenated output of MANY "show ..." commands (system
# info, security-policy, nat-policy, etc.), not just the one command we
# asked for via 'cmd'. PAN-OS uses the identical '"RuleName; index: N" { }'
# block syntax for every policy type (security, NAT, QoS, ...), so running
# _NAT_RULE_BLOCK_RE against the *entire* transcript indiscriminately picks
# up rule blocks from unrelated sections (observed: real security-policy
# rules with source/destination/application/action fields, misidentified
# as empty/malformed NAT rules because they have no translate-to field).
#
# This regex matches a command's echoed prompt line, e.g.:
#   dm9q0yx@DDC1-B2B-FW5 vsys1(active)> show running nat-policy
# capturing the command text that follows '>' on that line, so the
# transcript can be split into per-command sections at each prompt.
_PROMPT_CMD_RE = re.compile(r'\S+@\S+[^\r\n>]*>\s*(show[^\r\n]*)', re.IGNORECASE)


def _extract_command_section(content: str, cmd: str):
    """Isolates the output belonging to `cmd` from a raw multi-command CLI
    transcript, using the prompt-echo boundaries matched by _PROMPT_CMD_RE.

    Returns:
      - the isolated section text, if `cmd`'s prompt echo was found.
      - the full `content` unchanged, if NO prompt echoes were found at all
        (i.e. this doesn't look like a multi-command transcript -- treat it
        as if it were already just this command's own output, preserving
        compatibility with a dataType that returns a single command's
        output directly rather than a bundled transcript).
      - None, if prompt echoes WERE found but none of them match `cmd` --
        meaning the requested command was never actually run in this
        transcript, so there's nothing legitimate to parse.
    """
    if not content:
        return content

    matches = list(_PROMPT_CMD_RE.finditer(content))
    if not matches:
        return content

    cmd_norm = cmd.strip().lower()
    for i, m in enumerate(matches):
        echoed_cmd = m.group(1).strip().lower()
        if echoed_cmd == cmd_norm or echoed_cmd.startswith(cmd_norm + " "):
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(content)
            return content[start:end]

    return None


def parse_nat_policy(raw_text: str, hostname: str = "") -> list:
    """Parses PAN-OS 'show running nat-policy' CLI output into rule dicts:
    {name, index, from_zones, to_zones, translate_to, is_nat, is_pat}.

    is_nat: True if the rule performs any source/destination translation
            (a non-empty translate-to field).
    is_pat: True specifically when translate-to indicates port-overloaded
            translation ("dynamic-ip-and-port") -- i.e. true PAT, as
            opposed to a static 1:1 NAT or a non-overloaded dynamic-ip pool.
    """
    rules = []

    section_text = _extract_command_section(raw_text, NAT_CMD)
    if section_text is None:
        # Prompt echoes were found in the transcript, but none of them
        # matched NAT_CMD -- the requested command was never actually run
        # here, so there's nothing legitimate to parse. Returning zero
        # rules (rather than falling back to the whole transcript) avoids
        # re-introducing the original bug: matching rule blocks from an
        # unrelated command's section (e.g. security-policy) and
        # misreporting them as NAT data.
        if DEBUG_ZONES:
            debug_logger.debug(
                f"[DEBUG] parse_nat_policy({hostname}): transcript contains other "
                f"command prompts but not {NAT_CMD!r} -- can't isolate a nat-policy "
                f"section, returning zero rules rather than risk parsing an "
                f"unrelated command's output"
            )
        return rules

    # PAN-OS's own built-in default rules ("intrazone-default",
    # "interzone-default") genuinely have no from/to zones and no
    # translation by design -- that's not a parsing gap. Any other rule
    # name that comes back fully empty (no from/to/translate-to matched
    # at all) is suspicious: real, deliberately-named rules almost never
    # have zero zones and zero translation. Log a sample of the raw block
    # text for a couple of those (capped, so a rulebase with hundreds of
    # suspiciously-empty rules doesn't flood the debug log) so the actual
    # formatting can be inspected and the field regex fixed if needed.
    _KNOWN_ZONELESS_DEFAULTS = {"intrazone-default", "interzone-default"}
    _unexplained_empty_logged = 0

    for match in _NAT_RULE_BLOCK_RE.finditer(section_text or ""):
        name, index, body = match.group(1), match.group(2), match.group(3)
        fields = dict(_NAT_FIELD_RE.findall(body))

        from_zones = _split_zone_list(fields.get("from", ""))
        to_zones = _split_zone_list(fields.get("to", ""))
        translate_to = fields.get("translate-to", "").strip().strip('"')

        if (
            DEBUG_ZONES
            and not translate_to
            and not from_zones
            and not to_zones
            and name not in _KNOWN_ZONELESS_DEFAULTS
            and _unexplained_empty_logged < 2
        ):
            _unexplained_empty_logged += 1
            debug_logger.debug(
                f"[DEBUG] parse_nat_policy({hostname}): rule '{name}' (index {index}) parsed "
                f"as fully empty (no from/to/translate-to matched) but isn't a known "
                f"zoneless default rule -- likely a field-regex/formatting mismatch for "
                f"this rule's actual raw text, not a genuinely empty rule. "
                f"Raw block body (first 800 chars): {body[:800]!r}"
            )

        rules.append({
            "name": name,
            "index": index,
            "from_zones": from_zones,
            "to_zones": to_zones,
            "translate_to": translate_to,
            "is_nat": bool(translate_to),
            "is_pat": "dynamic-ip-and-port" in translate_to.lower(),
        })
    return rules


def build_zone_nat_map(rules: list) -> dict:
    """Aggregates parsed NAT rules into {zone_name_lower: {'nat': bool, 'pat': bool}}.

    A zone appearing as either the 'from' or 'to' side of a translating rule
    is considered NAT/PAT-associated. Zones that never appear (or appear
    only in non-translating rules) map to {'nat': False, 'pat': False},
    which callers can confidently report as "No" -- since this map is only
    built from a rulebase we successfully retrieved in full.
    """
    zone_map = {}
    for rule in rules:
        for zone in rule["from_zones"] + rule["to_zones"]:
            key = zone.strip().lower()
            if not key:
                continue
            entry = zone_map.setdefault(key, {"nat": False, "pat": False})
            entry["nat"] = entry["nat"] or rule["is_nat"]
            entry["pat"] = entry["pat"] or rule["is_pat"]
    return zone_map


def build_zone_nat_details(rules: list) -> dict:
    """Aggregates parsed NAT rules into
    {zone_name_lower: {'nat_details': [str, ...], 'pat_details': [str, ...]}}.

    Each detail string is "<rule name>: <translate-to value>" for every
    translating rule touching that zone (as either the 'from' or 'to' side).
    This gives the actual NAT/PAT translation info (e.g. the static IP or
    dynamic-ip-and-port pool), rather than just a Yes/No flag. Zones with no
    translating rules map to empty lists.
    """
    zone_details = {}
    for rule in rules:
        for zone in rule["from_zones"] + rule["to_zones"]:
            key = zone.strip().lower()
            if not key:
                continue
            entry = zone_details.setdefault(key, {"nat_details": [], "pat_details": []})
            if rule["is_nat"]:
                detail = f"{rule['name']}: {rule['translate_to']}"
                entry["nat_details"].append(detail)
                if rule["is_pat"]:
                    entry["pat_details"].append(detail)
    return zone_details


FIREWALL_KEYWORDS = [
    "firewall", "asa", "fortigate", "fortinet", "palo alto", "paloalto",
    "panorama", "checkpoint", "check point", "srx firewall", "ngfw",
]

SWITCH_KEYWORDS = [
    "switch", "catalyst", "nexus", "l2 switch", "l3 switch", "access switch",
    "distribution switch", "core switch", "ex series", "qfx", "arista switch",
]

ROUTER_KEYWORDS = [
    "router", "asr", "isr", "mx series", "juniper mx", "cisco router",
    "edge router", "core router", "csr1000v", "cat8000v",
]

LOAD_BALANCER_KEYWORDS = [
    "load balancer", "loadbalancer", "load-balancer", "f5", "big-ip", "bigip",
    "netscaler", "adc", "ltm", "gtm", "avi vantage", "a10 thunder",
]

# Category name -> keyword list, used both for filtering the run to specific
# device types and (for firewalls) for the existing NAT/zone enrichment logic.
DEVICE_TYPE_KEYWORDS = {
    "firewall": FIREWALL_KEYWORDS,
    "switch": SWITCH_KEYWORDS,
    "router": ROUTER_KEYWORDS,
    "load_balancer": LOAD_BALANCER_KEYWORDS,
}

# Device categories this run should include. Edit this set to change scope.
TARGET_DEVICE_TYPES = {"firewall"}


def _device_candidate_values(device: dict) -> list:
    """Collects lowercased type/family/vendor/model strings from a device
    payload (top-level and nested 'attributes'), used for keyword matching."""
    candidate_values = []
    for key in ["subType", "sub_type", "subTypeName", "sub_type_name", "family", "type", "deviceType", "vendor", "model"]:
        val = device.get(key)
        if val and isinstance(val, str):
            candidate_values.append(val.lower())

    attrs = device.get("attributes")
    if isinstance(attrs, dict):
        for key in ["subType", "subTypeName", "family", "type", "deviceType", "vendor", "model"]:
            val = attrs.get(key)
            if val and isinstance(val, str):
                candidate_values.append(val.lower())

    return candidate_values


def is_firewall_device(device: dict) -> bool:
    """Best-effort detection of firewall devices based on type/family/vendor metadata."""
    candidate_values = _device_candidate_values(device)
    combined = " ".join(candidate_values)
    result = any(kw in combined for kw in FIREWALL_KEYWORDS)

    if DEBUG_ZONES:
        hostname_dbg = device.get("hostName") or device.get("hostname") or device.get("name") or "?"
        debug_logger.debug(
            f"[DEBUG] is_firewall_device({hostname_dbg}) -> {result} "
            f"| candidate_values={candidate_values}"
        )

    return result


def matches_target_device_type(device: dict) -> bool:
    """Returns True if the device's type/family/vendor/model metadata matches
    any of the categories in TARGET_DEVICE_TYPES (firewall/switch/router/
    load_balancer), based on the keyword lists above."""
    candidate_values = _device_candidate_values(device)
    combined = " ".join(candidate_values)

    result = any(
        kw in combined
        for category in TARGET_DEVICE_TYPES
        for kw in DEVICE_TYPE_KEYWORDS.get(category, [])
    )

    if DEBUG_ZONES:
        hostname_dbg = device.get("hostName") or device.get("hostname") or device.get("name") or "?"
        debug_logger.debug(
            f"[DEBUG] matches_target_device_type({hostname_dbg}) -> {result} "
            f"| candidate_values={candidate_values}"
        )

    return result


def extract_site_from_device(device: dict) -> str:
    """Extracts site location metadata from device payload, falling back to TARGET_SITE."""
    for key in ["siteName", "site", "sitePath", "location", "site_name"]:
        val = device.get(key)
        if val and isinstance(val, str) and val.strip():
            return val.strip()

    return TARGET_SITE


def clean_ip(val) -> str:
    """Strips subnet masks, CIDR notation, and whitespace to isolate raw IP for DNS queries."""
    if not val or not isinstance(val, str):
        return ""
    ip_only = val.split("/")[0].strip()
    return ip_only if ip_only.upper() != "N/A" else ""


def resolve_ptr(ip_str: str, hostname_fallback: str = "") -> tuple:
    """Performs reverse DNS lookup returning (ip_with_mask, dns_name) separately."""
    clean_ip_addr = clean_ip(ip_str)
    raw_ip_entry = str(ip_str).strip() if ip_str else "N/A"
    if not clean_ip_addr:
        return ("N/A", "N/A")

    if clean_ip_addr in DNS_CACHE:
        _, cached_dns = DNS_CACHE[clean_ip_addr]
        return (raw_ip_entry, cached_dns)

    try:
        dns_name, _, _ = socket.gethostbyaddr(clean_ip_addr)
        result = (raw_ip_entry, dns_name)
    except Exception:
        fallback_dns = hostname_fallback if hostname_fallback and hostname_fallback.upper() != "N/A" else "N/A"
        result = (raw_ip_entry, fallback_dns)

    DNS_CACHE[clean_ip_addr] = result
    return result


def enrich_device_metadata(hostname: str, raw_device: dict) -> tuple:
    """Enriches device metadata, returning a per-interface row list plus device-level attributes."""
    intf_data = {}

    site_name = extract_site_from_device(raw_device)

    device_is_firewall = is_firewall_device(raw_device)

    if not hostname:
        placeholder_intf = [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "natInterface": "N/A", "patInterface": "N/A",
            "natInterfaceDetail": "N/A", "patInterfaceDetail": "N/A",
            "securityZone": "N/A"
        }]
        return placeholder_intf, "N/A", "N/A", site_name

    # Fetch device attributes, interface attributes, and (for firewalls) the
    # live NAT rulebase concurrently.
    with ThreadPoolExecutor(max_workers=3) as inner_executor:
        future_attrs = inner_executor.submit(fetch_device_attributes, hostname)
        future_intf_attrs = inner_executor.submit(fetch_all_interface_attrs, hostname)
        future_nat_policy = (
            inner_executor.submit(fetch_nat_policy_raw, hostname)
            if device_is_firewall else None
        )

        dev_attrs = future_attrs.result()
        all_intf_attrs = future_intf_attrs.result()
        nat_policy_raw = future_nat_policy.result() if future_nat_policy else ""

    # zone_nat_map is None when the NAT rulebase couldn't be retrieved (wrong
    # vendor, no permissions, API error) -- callers must fall back to the
    # interface-attribute-based guess (and ultimately N/A) in that case,
    # rather than assume "no NAT". It's {} (falsy-but-not-None) when we did
    # retrieve a rulebase and it genuinely has zero rules touching a zone.
    parsed_nat_rules = parse_nat_policy(nat_policy_raw, hostname) if nat_policy_raw else None
    zone_nat_map = build_zone_nat_map(parsed_nat_rules) if parsed_nat_rules is not None else None
    zone_nat_details = build_zone_nat_details(parsed_nat_rules) if parsed_nat_rules is not None else None

    if DEBUG_ZONES and device_is_firewall:
        rule_count = len(parsed_nat_rules) if parsed_nat_rules is not None else "N/A (no content returned)"
        debug_logger.debug(
            f"[DEBUG] {hostname}: NAT policy fetch {'succeeded' if nat_policy_raw else 'FAILED/empty'} "
            f"| raw_content_length={len(nat_policy_raw) if nat_policy_raw else 0} "
            f"| parsed_rule_count={rule_count} "
            f"| zone_nat_map={zone_nat_map}"
        )

        # When rules were parsed (rule_count > 0) but zone_nat_map came back
        # empty, that's ambiguous from the summary line alone: it could mean
        # every parsed rule is genuinely zone-less (default/boilerplate
        # rules, or rules using "any" for both from/to -- _split_zone_list
        # intentionally excludes "any" since it isn't a specific zone), or
        # it could mean the from/to field regex isn't matching this device's
        # actual output formatting. Log a sample of the raw parsed
        # from_zones/to_zones/translate_to for the first few rules so this
        # can be told apart without guessing.
        if parsed_nat_rules and not zone_nat_map:
            sample_rules = [
                {
                    "name": r["name"],
                    "from_zones": r["from_zones"],
                    "to_zones": r["to_zones"],
                    "translate_to": r["translate_to"],
                    "is_nat": r["is_nat"],
                    "is_pat": r["is_pat"],
                }
                for r in parsed_nat_rules[:3]
            ]
            debug_logger.debug(
                f"[DEBUG] {hostname}: zone_nat_map is empty despite {rule_count} parsed rule(s) "
                f"-- sample of first {len(sample_rules)} rule(s)' from/to/translate-to fields "
                f"(empty from_zones/to_zones on all of these would mean the rules are "
                f"genuinely zone-less/boilerplate or use 'any'; non-empty lists here would "
                f"instead point at a zone-mapping bug elsewhere): {sample_rules}"
            )

    sn_val = dev_attrs.get("sn") or dev_attrs.get("serialNumber") or "N/A"
    model_val = dev_attrs.get("model") or "N/A"

    if DEBUG_ZONES and device_is_firewall and all_intf_attrs:
        sample_intf_name = next(iter(all_intf_attrs))
        debug_logger.debug(
            f"[DEBUG] {hostname}: sample interface '{sample_intf_name}' raw attrs = "
            f"{all_intf_attrs[sample_intf_name]}"
        )

    for intf_name, attrs in all_intf_attrs.items():
        if not intf_name:
            continue

        clean_intf = str(intf_name).strip()

        if isinstance(attrs, dict):
            speed_val = attrs.get("speed") or attrs.get("bandwidth") or attrs.get("interfaceSpeed")
            clean_speed = str(speed_val).strip() if speed_val and str(speed_val).strip() else "N/A"

            descr_val = attrs.get("descr") or attrs.get("description") or attrs.get("interfaceDescription")
            clean_descr = str(descr_val).strip() if descr_val and str(descr_val).strip() else "N/A"

            vrf_val = str(attrs.get("mplsVrf") or attrs.get("vrfName") or attrs.get("vrf") or "").strip()
            clean_vrf = vrf_val if vrf_val and vrf_val.lower() not in ["none", "null", "undefined", "n/a", "0"] else "default"

            if device_is_firewall:
                zone_val = str(
                    attrs.get("securityZone")
                    or attrs.get("zoneName")
                    or attrs.get("zone")
                    or attrs.get("nameif")
                    or ""
                ).strip()
                if not zone_val or zone_val.lower() in ["none", "null", "undefined", "n/a"]:
                    # NetBrain appears to surface the firewall zone name through
                    # the same VRF-style attribute used for routers (e.g. it's
                    # empty/"default" on physical/HA interfaces and set to the
                    # real zone name on zone-assigned subinterfaces).
                    zone_val = vrf_val
                clean_zone = (
                    zone_val
                    if zone_val and zone_val.lower() not in ["none", "null", "undefined", "n/a", "0", "default"]
                    else "N/A"
                )
            else:
                clean_zone = "N/A"

            # NetBrain only populates isNatIntf/natType/nat (and the PAT
            # equivalents) for some platforms; on others (e.g. Palo Alto)
            # the key is present but always blank, or absent entirely,
            # because NAT/PAT is a policy construct rather than an
            # interface attribute there. A blank/missing key is NOT the
            # same as "confirmed no NAT" -- treat it as unknown ("N/A")
            # on firewalls, same as securityZone already does, rather than
            # silently reporting "No". This is the fallback used when we
            # don't have (or couldn't parse) an actual NAT rulebase below.
            nat_keys_present = any(
                attrs.get(k) not in (None, "")
                for k in ("isNatIntf", "natType", "nat")
            )
            pat_keys_present = any(
                attrs.get(k) not in (None, "")
                for k in ("isPatIntf", "patType", "pat")
            )

            nat_val = attrs.get("isNatIntf") or attrs.get("natType") or attrs.get("nat")
            pat_val = attrs.get("isPatIntf") or attrs.get("patType") or attrs.get("pat")

            if device_is_firewall and not nat_keys_present:
                is_nat = "N/A"
            else:
                is_nat = "Yes" if nat_val and str(nat_val).lower() not in ["false", "0", "disabled", "no", ""] else "No"

            if device_is_firewall and not pat_keys_present:
                is_pat = "N/A"
            else:
                is_pat = "Yes" if pat_val and str(pat_val).lower() not in ["false", "0", "disabled", "no", ""] else "No"

            # Authoritative override: if we successfully retrieved and parsed
            # this firewall's real NAT rulebase (zone_nat_map is not None),
            # trust that over the interface-attribute guess above -- it's
            # policy ground truth, keyed by the interface's own zone.
            # A zone with a known-empty rulebase correctly reports "No" here,
            # since the absence of NAT is now a confirmed fact, not a guess.
            nat_detail = "N/A"
            pat_detail = "N/A"
            if device_is_firewall and zone_nat_map is not None and clean_zone != "N/A":
                zone_entry = zone_nat_map.get(clean_zone.lower())
                is_nat = "Yes" if zone_entry and zone_entry["nat"] else "No"
                is_pat = "Yes" if zone_entry and zone_entry["pat"] else "No"

                zone_detail_entry = (zone_nat_details or {}).get(clean_zone.lower())
                if zone_detail_entry:
                    nat_detail = "; ".join(zone_detail_entry["nat_details"]) or "No NAT rules"
                    pat_detail = "; ".join(zone_detail_entry["pat_details"]) or "No PAT rules"
                else:
                    nat_detail = "No NAT rules"
                    pat_detail = "No PAT rules"

            if DEBUG_ZONES:
                nat_pat_candidates = {
                    k: v for k, v in attrs.items()
                    if any(tok in k.lower() for tok in ["nat", "pat"])
                }
                debug_logger.debug(
                    f"[DEBUG] {hostname}/{clean_intf}: zone={clean_zone!r} "
                    f"nat_val={nat_val!r} -> {is_nat} | "
                    f"pat_val={pat_val!r} -> {is_pat} | "
                    f"nat/pat-like raw attrs={nat_pat_candidates}"
                )

            intf_ip = "N/A"
            ips_raw = attrs.get("ips") or attrs.get("ipAddress")
            raw_list = ips_raw if isinstance(ips_raw, list) else [ips_raw]

            for item in raw_list:
                ip_str = item.get("ipLoc") if isinstance(item, dict) else item
                mask_val = item.get("mask") or item.get("subnetMask") if isinstance(item, dict) else ""

                c_ip = clean_ip(ip_str)
                if c_ip:
                    # Construct full IP with subnet mask if available separately
                    if mask_val and "/" not in str(ip_str):
                        full_ip_with_mask = f"{ip_str}/{mask_val}"
                    else:
                        full_ip_with_mask = str(ip_str).strip()

                    resolved_ip, _ = resolve_ptr(full_ip_with_mask, hostname)
                    intf_ip = resolved_ip
                    break  # one resolved IP per interface

            intf_data[clean_intf] = {
                "name": clean_intf,
                "description": clean_descr,
                "speed": clean_speed,
                "vrf": clean_vrf,
                "nat": is_nat,
                "pat": is_pat,
                "nat_detail": nat_detail,
                "pat_detail": pat_detail,
                "ip": intf_ip,
                "zone": clean_zone,
            }
        else:
            intf_data[clean_intf] = {
                "name": clean_intf,
                "description": "N/A",
                "speed": "N/A",
                "vrf": "default",
                "nat": "No",
                "pat": "No",
                "nat_detail": "N/A",
                "pat_detail": "N/A",
                "ip": "N/A",
                "zone": "N/A",
            }

    sorted_intfs = sorted(intf_data.keys())
    if sorted_intfs:
        interfaces_list = [
            {
                "interfaceName": intf_data[intf]["name"],
                "interfaceDescription": intf_data[intf]["description"],
                "interfaceSpeed": intf_data[intf]["speed"],
                "resolvedIP": intf_data[intf]["ip"],
                "vrfNames": intf_data[intf]["vrf"],
                "natInterface": intf_data[intf]["nat"],
                "patInterface": intf_data[intf]["pat"],
                "natInterfaceDetail": intf_data[intf]["nat_detail"],
                "patInterfaceDetail": intf_data[intf]["pat_detail"],
                "securityZone": intf_data[intf]["zone"],
            }
            for intf in sorted_intfs
        ]
    else:
        interfaces_list = [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "natInterface": "N/A", "patInterface": "N/A",
            "natInterfaceDetail": "N/A", "patInterfaceDetail": "N/A",
            "securityZone": "N/A"
        }]

    return (
        interfaces_list,
        sn_val,
        model_val,
        site_name,
    )


def main():
    authenticate()

    site_devices = []
    seen_hostnames = set()
    all_discovered_columns = {
        "requestedSite",
        "serialNumber",
        "hardwareModel",
        "interfaceDescription",
        "interfaceSpeed",
        "vrfNames",
        "resolvedIP",
        "natInterface",
        "patInterface",
    }
    
    EXCLUDED_FIELDS = {
        "hostName",
        "hostname",
        "mgmtIP",
        "domain",
        "domainName",
        "dnsDomain",
    }

    print(
        f"Fetching global CMDB devices for target site '{TARGET_SITE}' "
        f"(device types: {', '.join(sorted(TARGET_DEVICE_TYPES))})..."
    )
    raw_devices = fetch_all_devices()

    for device in raw_devices:
        if len(site_devices) >= LIMIT_DEVICES:
            break

        hostname = (
            device.get("hostName")
            or device.get("hostname")
            or device.get("name")
        )

        if hostname and hostname not in seen_hostnames:
            searchable_fields = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()

            if TARGET_SITE in searchable_fields and matches_target_device_type(device):
                seen_hostnames.add(hostname)
                flat_device = {"_raw_device": device}
                flat_device["requestedSite"] = extract_site_from_device(device)

                for k, v in device.items():
                    if k in EXCLUDED_FIELDS or any(
                        ex in k.lower() for ex in ["id", "discovery", "time"]
                    ):
                        continue
                    if k == "attributes" and isinstance(v, dict):
                        for sub_k, sub_v in v.items():
                            if sub_k not in EXCLUDED_FIELDS and not any(
                                ex in sub_k.lower() for ex in ["id", "discovery", "time"]
                            ):
                                flat_device[f"attr_{sub_k}"] = sub_v
                    else:
                        flat_device[k] = v

                all_discovered_columns.update(
                    k for k in flat_device if not k.startswith("_")
                )
                site_devices.append(flat_device)

    print(f"Limiting audit to {len(site_devices)} assets. Enriching metadata ({MAX_WORKERS} workers)...")

    if site_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(
                    enrich_device_metadata,
                    dev.get("name") or dev.get("hostName") or dev.get("hostname"),
                    dev.get("_raw_device", {}),
                ): dev
                for dev in site_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    (
                        interfaces_list,
                        sn_res,
                        model_res,
                        site_res,
                    ) = future.result()

                    dev["_interfaces"] = interfaces_list
                    dev["serialNumber"] = sn_res
                    dev["hardwareModel"] = model_res
                    dev["requestedSite"] = site_res
                except Exception:
                    dev["_interfaces"] = [{
                        "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
                        "resolvedIP": "N/A", "vrfNames": "default", "natInterface": "N/A", "patInterface": "N/A",
                        "natInterfaceDetail": "N/A", "patInterfaceDetail": "N/A",
                        "securityZone": "N/A"
                    }]
                    dev["serialNumber"] = "N/A"
                    dev["hardwareModel"] = "N/A"
                    dev["requestedSite"] = TARGET_SITE
                finally:
                    dev.pop("_raw_device", None)

    primary_headers = [
        "name",
        "requestedSite",
        "serialNumber",
        "hardwareModel",
        "interfaceName",
        "interfaceDescription",
        "interfaceSpeed",
        "resolvedIP",
        "vrfNames",
        "securityZone",
        "natInterface",
        "patInterface",
        "natInterfaceDetail",
        "patInterfaceDetail",
    ]
    extra_headers = sorted(
        [
            col
            for col in all_discovered_columns
            if col not in primary_headers and col not in EXCLUDED_FIELDS
        ]
    )
    ordered_headers = primary_headers + extra_headers

    # Expand each device into one row per interface, repeating device-level fields.
    final_rows = []
    for dev in site_devices:
        interfaces = dev.pop("_interfaces", None) or [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "natInterface": "N/A", "patInterface": "N/A",
            "natInterfaceDetail": "N/A", "patInterfaceDetail": "N/A",
            "securityZone": "N/A"
        }]
        for intf_row in interfaces:
            row = {**dev, **intf_row}
            final_rows.append(row)

    output_dir = os.path.dirname(OUTPUT_FILE)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=ordered_headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(final_rows)

    print(f"Export successful: {OUTPUT_FILE}")
    if DEBUG_ZONES:
        print(f"Debug log written to: {DEBUG_LOG_FILE}")


if __name__ == "__main__":
    main()
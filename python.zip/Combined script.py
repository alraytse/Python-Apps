#!/usr/bin/env python3
from netmiko import ConnectHandler
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from datetime import datetime
import ipaddress, getpass, csv, re, socket, subprocess, platform

TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
REPORT_FILE = f"subnet_report_{TIMESTAMP}.csv"
AUDIT_FILE = f"command_audit_{TIMESTAMP}.csv"
FAILED_FILE = f"failed_devices_{TIMESTAMP}.csv"

COMMAND_LOG=[]
FAILED_DEVICES=[]
COMMAND_LOCK=Lock()
FAILED_LOCK=Lock()
DEVICE_TYPES=["cisco_nxos","cisco_xe","cisco_ios","arista_eos"]

# Reachability

def ping_host(host):
    flag='-n' if platform.system().lower()=='windows' else '-c'
    try:
        r=subprocess.run(['ping',flag,'2',host],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
        return r.returncode==0
    except: return False

def verify_ssh(host,port=22):
    try:
        s=socket.create_connection((host,port),timeout=5)
        s.close(); return True
    except: return False

# VLAN / ARP

def build_vlan_db(output):
    vlan_db={}
    for line in output.splitlines():
        m=re.match(r'^\s*(\d+)\s+(\S+)',line)
        if m: vlan_db[f'Vlan{m.group(1)}']=m.group(2)
    return vlan_db


def get_vlan_info(interface_name,vlan_db):
    if not interface_name: return '',''
    m=re.search(r'Vlan(\d+)',interface_name,re.I) or re.search(r'\.(\d+)$',interface_name)
    if not m: return '',''
    vid=m.group(1)
    return vid,vlan_db.get(f'Vlan{vid}','')


def get_arp_count(arp_output, subnet):
    network=ipaddress.ip_network(subnet,strict=False)
    unique=set()
    for line in arp_output.splitlines():
        m=re.search(r'(\d+\.\d+\.\d+\.\d+)',line)
        if not m: continue
        try:
            ip=ipaddress.ip_address(m.group(1))
            if ip in network: unique.add(str(ip))
        except: pass
    return len(unique)


def get_utilization(subnet, arp_count):
    net=ipaddress.ip_network(subnet,strict=False)
    if net.prefixlen>=30: return 'N/A'
    usable=max(net.num_addresses-2,1)
    return round((arp_count/usable)*100,2)


def check_subnet_reachability(subnet, arp_output, next_hop=''):
    try:
        net=ipaddress.ip_network(subnet,strict=False)
        for line in arp_output.splitlines():
            m=re.search(r'(\d+\.\d+\.\d+\.\d+)',line)
            if not m: continue
            try:
                if ipaddress.ip_address(m.group(1)) in net:
                    return 'Reachable'
            except: pass
        if next_hop:
            flag='-n' if platform.system().lower()=='windows' else '-c'
            r=subprocess.run(['ping',flag,'2',next_hop],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5)
            if r.returncode==0: return 'Reachable'
        return 'Unreachable'
    except:
        return 'Unknown'

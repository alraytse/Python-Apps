
#!/usr/bin/env python3
"""
Enhanced Network Health Check:
- Checks UP interfaces with descriptions and MAC addresses
- Collects CDP neighbors
- Parses BGP, EIGRP, and Routing Table summaries
- Writes structured summary + raw outputs to per-device TXT file
"""

from netmiko import ConnectHandler
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import getpass
import re

# Prompt for hostnames
switch_input = input("Enter switch IPs or hostnames separated by commas: ").strip()
switch_hosts = [host.strip() for host in switch_input.split(",") if host.strip()]

# Prompt for credentials
username = input("Enter username: ").strip()
password = getpass.getpass("Enter password: ")

# Build device list
devices = [
    {
        "device_type": "cisco_ios",  # Change to cisco_nxos if needed
        "host": host,
        "username": username,
        "password": password,
        "timeout": 60,
        "conn_timeout": 30,
    }
    for host in switch_hosts
]

def parse_bgp_summary(output):
    """Parse BGP summary for AS, neighbors, established count, prefixes."""
    as_match = re.search(r"Local AS number\s+(\d+)", output)
    local_as = as_match.group(1) if as_match else "Unknown"

    neighbors = re.findall(r"(\d+\.\d+\.\d+\.\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\w+", output)
    neighbor_count = len(neighbors)

    established_count = len(re.findall(r"Established", output))
    prefixes_match = re.search(r"(\d+)\s+prefixes", output)
    prefixes = prefixes_match.group(1) if prefixes_match else "Unknown"

    return f"BGP: AS {local_as}, {neighbor_count} neighbors ({established_count} Established), {prefixes} prefixes"

def parse_eigrp_neighbors(output):
    """Parse EIGRP neighbors for count and interfaces."""
    neighbors = re.findall(r"Address:\s+(\d+\.\d+\.\d+\.\d+).*?Interface:\s+(\S+)", output, re.DOTALL)
    neighbor_count = len(neighbors)
    interfaces = {intf for _, intf in neighbors}
    return f"EIGRP: {neighbor_count} neighbors on {len(interfaces)} interfaces"

def parse_route_summary(output):
    """Parse routing summary for total, connected, static, dynamic routes."""
    total_match = re.search(r"Total number of routes:\s+(\d+)", output)
    total_routes = total_match.group(1) if total_match else "Unknown"

    connected = len(re.findall(r"C\s", output))
    static = len(re.findall(r"S\s", output))
    dynamic = len(re.findall(r"[A-Z]\s", output)) - connected - static

    return f"Routes: {total_routes} total (Connected: {connected}, Static: {static}, Dynamic: {dynamic})"

def check_device(device):
    host_for_log = device["host"]
    try:
        net_connect = ConnectHandler(**device)
        hostname = net_connect.find_prompt().strip("#>").strip()

        # Interfaces UP
        output = net_connect.send_command("show ip interface brief | include up")
        up_interfaces = [line.split()[0] for line in output.splitlines() if line.strip()]
        up_count = len(up_interfaces)

        descriptions = {}
        mac_addresses = {}

        for intf in up_interfaces:
            # Get interface description
            intf_output = net_connect.send_command(f"show interface {intf}")
            match = re.search(r"Description:\s*(.*)", intf_output)
            descriptions[intf] = match.group(1).strip() if match else "No description"

            # Get MAC addresses for the interface
            mac_output = net_connect.send_command(f"show mac address-table interface {intf}")
            mac_list = re.findall(r"([0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4})", mac_output, re.IGNORECASE)
            mac_addresses[intf] = mac_list if mac_list else ["No MAC found"]

        # CDP neighbors
        cdp_output = net_connect.send_command("show cdp neighbors")

        # BGP summary
        bgp_output = net_connect.send_command("show ip bgp summary")
        bgp_summary = parse_bgp_summary(bgp_output)

        # EIGRP neighbors
        eigrp_output = net_connect.send_command("show ip eigrp neighbors")
        eigrp_summary = parse_eigrp_neighbors(eigrp_output)

        # Routing summary
        route_output = net_connect.send_command("show ip route summary")
        route_summary = parse_route_summary(route_output)

        # Prepare filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{hostname}_{timestamp}.txt"

        # Write results
        with open(filename, "w") as f:
            f.write(f"Device: {hostname} ({host_for_log})\n")
            f.write(f"Checked at: {timestamp}\n\n")

            f.write("Summary:\n")
            f.write(f"- Interfaces UP: {up_count}\n")
            f.write(f"- {bgp_summary}\n")
            f.write(f"- {eigrp_summary}\n")
            f.write(f"- {route_summary}\n\n")

            f.write("Interfaces in UP state with descriptions and MAC addresses:\n")
            if up_interfaces:
                for intf in up_interfaces:
                    f.write(f"  {intf} - {descriptions[intf]} | MACs: {', '.join(mac_addresses[intf])}\n")
            else:
                f.write("  None\n")

            f.write("\n--- Raw Outputs ---\n")
            f.write("\n(show ip interface brief | include up)\n" + output + "\n")
            f.write("\n(show cdp neighbors)\n" + cdp_output + "\n")
            f.write("\n(show ip bgp summary)\n" + bgp_output + "\n")
            f.write("\n(show ip eigrp neighbors)\n" + eigrp_output + "\n")
            f.write("\n(show ip route summary)\n" + route_output + "\n")

        net_connect.disconnect()
        return f"[{hostname}] Results saved to {filename}"

    except Exception as e:
        return f"[{host_for_log}] Error: {e}"

# Run checks in parallel
max_workers = max(1, min(10, len(devices)))
with ThreadPoolExecutor(max_workers=max_workers) as executor:
    futures = [executor.submit(check_device, d) for d in devices]
    for future in as_completed(futures):
        print(future.result())

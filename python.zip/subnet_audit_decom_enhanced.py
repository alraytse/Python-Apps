# Enhanced version generated from subnet_audit_decom_maskinput.py
# Key additions:
# - MAC validation
# - Connected route detection
# - REVIEW classification for BGP/Static routes with no activity

import ipaddress
import re

def get_utilization(subnet, count):
    network = ipaddress.ip_network(subnet, strict=False)
    usable = max(network.num_addresses - 2, 1)
    return round((count / usable) * 100, 2)


def get_mac_count(mac_output, arp_output, subnet):
    network = ipaddress.ip_network(subnet, strict=False)
    mac_ips = set()
    for line in arp_output.splitlines():
        m = re.search(r'(\d+\.\d+\.\d+\.\d+)', line)
        if not m:
            continue
        ip = m.group(1)
        try:
            if ipaddress.ip_address(ip) in network:
                mac_ips.add(ip)
        except Exception:
            pass
    return len(mac_ips)


def classify_decom_candidate(route_present, route_type,
                             connected_route, vlan_id,
                             arp_count, mac_count):

    if not route_present and arp_count == 0 and mac_count == 0:
        return 'YES', 'No route, no ARPs, no MAC entries'

    if (route_present and route_type in ['BGP', 'Static'] and
            arp_count == 0 and mac_count == 0 and not vlan_id):
        return 'REVIEW', f'{route_type} route exists but no hosts detected'

    if connected_route and arp_count == 0 and mac_count == 0:
        return 'REVIEW', 'Connected subnet with zero ARPs and MACs'

    return 'NO', 'Active subnet'

print('Merge these functions into your existing subnet_audit_decom_maskinput.py')

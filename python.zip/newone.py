#!/usr/bin/env python3
"""
Network validation runner with compare support.

USAGE (examples):

# Run device commands (your current flow)
python savenew.py run

# Run and compare new artifacts to baselines (writes diffs for mismatches)
python savenew.py run --baseline-dir baseline --diff-dir artifacts/diffs --ignore-ws \
  --ignore-pattern '^# Generated' --ignore-pattern 'timestamp:.*'

# Ad-hoc compare two files/directories
python savenew.py compare A.txt B.txt --mode text --ignore-ws --diff-out diff.txt
python savenew.py compare a.json b.json --mode json --json-float-tol 6 --diff-out json.diff
python savenew.py compare dirA dirB --mode dir --dir-content --diff-out dir_report.txt

Exit codes: 0 equal/no diff, 1 difference(s), 2 error.
"""

import os
import re
import csv
import json
import time
import argparse
import logging
import hashlib
import difflib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

import paramiko

# ========= CONFIG =========
LOG_DIR = 'logs'
ARTIFACTS_DIR = 'artifacts'
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(ARTIFACTS_DIR, exist_ok=True)

# Per-run timestamp tag
RUN_TS = datetime.now().strftime('%Y%m%d_%H%M%S')

# Configure logging with timestamp
log_path = os.path.join(LOG_DIR, f'validation_log_{RUN_TS}.txt')
logging.basicConfig(
    filename=log_path,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
console.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().addHandler(console)

# ========= DEVICES & COMMANDS =========
# Define devices and their credentials
devices = {
    "NEW_DDC1-MDFE1-COR1": {"host": "NEW_DDC1-MDFE1-COR1", "username": "ekk30ws", "password": "New42day123!@#$%"},
    "NEW_DDC1-MDFE1-COR2": {"host": "NEW_DDC1-MDFE1-COR2", "username": "ekk30ws", "password": "New42day123!@#$%"}
}

# Validate Aruba Edge Connect environment
commands = {
    "NEW_DDC1-MDFE1-COR1": [
        "!Validating Aruba Edge Connect environment",
        "show int e3/35 | i rate",
        "sleep 1",
        "show int e3/36 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.50.66.58 | no-more",
        "show ip bgp 10.50.66.62 | no-more",
        "show ip bgp neighbors 10.50.66.58 | no-more",
        "show ip bgp neighbors 10.50.66.62 | no-more",
        "show ip route bgp int e3/35 | no-more",
        "show ip route bgp int e3/36 | no-more",
        "show ip route | no-more",
        "show int e3/28 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.255.132.137 | no-more",
        "show ip bgp neighbors 10.255.132.137 | no-more",
        "show ip route bgp int e3/28 | no-more",
        "show ip route | no-more"
    ],
    "NEW_DDC1-MDFE1-COR2": [
        "show int e3/35 | i rate",
        "sleep 1",
        "show int e3/36 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.50.66.66 | no-more",
        "show ip bgp 10.50.66.70 | no-more",
        "show ip bgp neighbors 10.50.66.66 | no-more",
        "show ip bgp neighbors 10.50.66.70 | no-more",
        "show ip route bgp int e3/35 | no-more",
        "show ip route bgp int e3/36 | no-more",
        "show ip route | no-more",
        "show int e3/28 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.255.132.117 | no-more",
        "show ip bgp neighbors 10.255.132.117 | no-more",
        "show ip route bgp int e3/28 | no-more",
        "show ip route | no-more"
    ]
}

# ========= ADDITIONAL TEST COMMANDS =========
# Validate sd-wan Viptela environment
commands["NEW_DDC1-MDFE1-COR1"].extend([
    "!Validate sd-wan Viptela environment",
    "show int e3/28 | i rate",
    "sleep 1",
    "show ip bgp sum | no-more",
    "show ip bgp 10.255.132.137 | no-more",
    "show ip bgp neighbors 10.255.132.137 | no-more",
    "show ip route bgp int e3/28 | no-more",
    "show ip route | no-more"
])
commands["NEW_DDC1-MDFE1-COR2"].extend([
    "show int e3/28 | i rate",
    "sleep 1",
    "show ip bgp sum | no-more",
    "show ip bgp 10.255.132.117 | no-more",
    "show ip bgp neighbors 10.255.132.117 | no-more",
    "show ip route bgp int e3/28 | no-more",
    "show ip route | no-more"
])

# ========= HELPERS =========
def safe_str(s: str) -> str:
    # strip CR and ANSI if any
    return (s or "").replace('\r', '').replace('\x1b', '')

def connect_ssh(host, username, password, port=22, timeout=15, banner_timeout=10):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    # Avoid using local SSH agent or keys unless you want that behavior
    client.connect(
        hostname=host,
        port=port,
        username=username,
        password=password,
        timeout=timeout,
        banner_timeout=banner_timeout,
        allow_agent=False,
        look_for_keys=False
    )
    return client

def run_exec(client: paramiko.SSHClient, cmd: str, read_timeout: float = 30.0):
    """
    Run a single command via exec_command with a read timeout.
    Returns (exit_status, stdout_text, stderr_text, elapsed_sec).
    """
    start = time.time()
    stdin, stdout, stderr = client.exec_command(cmd, timeout=read_timeout)
    # Set channel timeout for reads
    stdout.channel.settimeout(read_timeout)
    stderr.channel.settimeout(read_timeout)
    out = ""
    err = ""
    try:
        out = stdout.read().decode(errors='replace')
    except Exception as e:
        err += f"\n[stdout timeout/read error: {e}]"
    try:
        err += stderr.read().decode(errors='replace')
    except Exception as e:
        err += f"\n[stderr timeout/read error: {e}]"
    # Ensure we grab exit status
    try:
        exit_status = stdout.channel.recv_exit_status()
    except Exception:
        # Fallback if channel already closed unexpectedly
        exit_status = -1
    elapsed = time.time() - start
    return exit_status, safe_str(out), safe_str(err), elapsed

def execute_commands(device_name: str, device_info: dict, command_list: list, max_retries: int = 2):
    host = device_info['host']
    username = device_info.get('username')
    password = device_info.get('password')
    port = device_info.get('port', 22)

    if not username or not password or username == "REPLACE_ME" or password == "REPLACE_ME":
        msg = f"[{device_name}] Missing credentials (set env DEVICE_USER/DEVICE_PASS or COR_USER/COR_PASS)."
        logging.error(msg)
        return {"device": device_name, "host": host, "status": "failed", "reason": msg, "results": []}

    logging.info(f"Connecting to {device_name} ({host})")
    attempt = 0
    client = None
    last_exc = None
    while attempt <= max_retries:
        try:
            client = connect_ssh(host, username, password, port=port)
            break
        except Exception as e:
            last_exc = e
            attempt += 1
            logging.warning(f"[{device_name}] Connect attempt {attempt} failed: {e}")
            time.sleep(min(2 ** attempt, 10))
    if client is None:
        reason = f"Failed to connect to {device_name}: {last_exc}"
        logging.error(reason)
        return {"device": device_name, "host": host, "status": "failed", "reason": str(last_exc), "results": []}

    per_device_artifact = os.path.join(ARTIFACTS_DIR, f"{device_name}_{RUN_TS}.txt")
    results_csv = os.path.join(ARTIFACTS_DIR, f"{device_name}_{RUN_TS}.csv")
    results_rows = []

    try:
        with open(per_device_artifact, 'w', encoding='utf-8') as outf:
            outf.write(f"==== Device: {device_name} ({host}) Run: {RUN_TS} ====\n")
            for cmd in command_list:
                cmd_stripped = cmd.strip()
                # Treat leading '!' lines as comments/annotations (skip execution but log and write)
                if cmd_stripped.startswith("!"):
                    note = cmd_stripped.lstrip("!").strip()
                    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    logging.info(f"[{device_name}] Note: {note}")
                    outf.write(f"\n--- {ts} :: NOTE ---\n{note}\n")
                    continue
                if cmd_stripped.startswith("sleep"):
                    # Support "sleep N"
                    try:
                        delay = int(cmd_stripped.split()[1])
                    except Exception:
                        delay = 1
                    logging.info(f"[{device_name}] Sleeping for {delay} seconds")
                    time.sleep(delay)
                    continue
                ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                logging.info(f"[{device_name}] [{ts}] Executing: {cmd}")
                exit_status, out, err, elapsed = run_exec(client, cmd, read_timeout=60.0)

                # Log results
                if out.strip():
                    logging.info(f"[{device_name}] Output ({len(out)} bytes)")
                if err.strip():
                    logging.error(f"[{device_name}] Error: {err.strip()}")

                # Write to per-device text artifact
                outf.write(f"\n--- {ts} :: {cmd} ---\n")
                if out:
                    outf.write(out if out.endswith('\n') else out + '\n')
                if err:
                    outf.write(f"[stderr] {err if err.endswith('\n') else err + '\n'}")

                # Collect CSV row
                results_rows.append({
                    "timestamp": ts,
                    "device": device_name,
                    "host": host,
                    "command": cmd,
                    "exit_status": exit_status,
                    "duration_ms": int(elapsed * 1000),
                    "stdout_bytes": len(out),
                    "stderr_bytes": len(err)
                })
    finally:
        try:
            client.close()
        except Exception:
            pass
        logging.info(f"Disconnected from {device_name}")

    # Write CSV summary
    fieldnames = ["timestamp", "device", "host", "command", "exit_status", "duration_ms", "stdout_bytes", "stderr_bytes"]
    with open(results_csv, 'w', newline='', encoding='utf-8') as fcsv:
        writer = csv.DictWriter(fcsv, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results_rows)

    return {"device": device_name, "host": host, "status": "ok", "results_file": per_device_artifact, "csv": results_csv}

def run_all(devices: dict, commands: dict, max_workers: int = 4):
    futures = []
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        for device_name, device_info in devices.items():
            cmd_list = commands.get(device_name, [])
            futures.append(pool.submit(execute_commands, device_name, device_info, cmd_list))
        for fut in as_completed(futures):
            try:
                res = fut.result()
            except Exception as e:
                res = {"device": "unknown", "status": "failed", "reason": str(e), "results": []}
            results.append(res)

    # Save a run summary JSON
    summary_path = os.path.join(ARTIFACTS_DIR, f"run_summary_{RUN_TS}.json")
    with open(summary_path, 'w', encoding='utf-8') as js:
        json.dump(results, js, indent=2)
    logging.info(f"Run summary written to {summary_path}")
    return results

# ========= COMPARE UTILITIES =========
def files_equal(path_a, path_b, method: str = "auto", chunk_size: int = 4 * 1024 * 1024) -> bool:
    """
    Byte-for-byte compare. method: 'auto'|'hash'|'bytes'
    'auto' = hash if <=200MB else streaming bytes.
    """
    a, b = Path(path_a), Path(path_b)
    if not a.is_file(): raise FileNotFoundError(a)
    if not b.is_file(): raise FileNotFoundError(b)
    sa, sb = a.stat().st_size, b.stat().st_size
    if sa != sb: return False
    if method == "auto":
        method = "bytes" if sa > 200 * 1024 * 1024 else "hash"
    if method == "hash":
        def sha256(p: Path) -> bytes:
            h = hashlib.sha256()
            with p.open("rb") as f:
                for chunk in iter(lambda: f.read(chunk_size), b""):
                    h.update(chunk)
            return h.digest()
        return sha256(a) == sha256(b)
    # streaming bytes
    with a.open("rb") as fa, b.open("rb") as fb:
        while True:
            ba, bb = fa.read(chunk_size), fb.read(chunk_size)
            if ba != bb: return False
            if not ba: break
    return True

def text_equal(
    path_a,
    path_b,
    *,
    encoding: str = "utf-8",
    normalize_line_endings: bool = True,
    ignore_whitespace: bool = False,
    ignore_case: bool = False,
    ignore_patterns: Optional[List[str]] = None,   # e.g. [r"^# Generated .*", r"timestamp:.*"]
) -> bool:
    """
    Compares text content with optional normalization and ignore rules.
    """
    pa, pb = Path(path_a), Path(path_b)
    if not pa.is_file(): raise FileNotFoundError(pa)
    if not pb.is_file(): raise FileNotFoundError(pb)
    ta, tb = pa.read_text(encoding=encoding), pb.read_text(encoding=encoding)

    if normalize_line_endings:
        ta = ta.replace("\r\n", "\n").replace("\r", "\n")
        tb = tb.replace("\r\n", "\n").replace("\r", "\n")

    if ignore_patterns:
        rx = [re.compile(pat) for pat in ignore_patterns]
        def strip_ignored(t: str) -> str:
            lines = []
            for line in t.splitlines():
                if any(r.search(line) for r in rx):
                    continue
                lines.append(line)
            return "\n".join(lines)
        ta, tb = strip_ignored(ta), strip_ignored(tb)

    if ignore_whitespace:
        ta = re.sub(r"\s+", " ", ta).strip()
        tb = re.sub(r"\s+", " ", tb).strip()
    if ignore_case:
        ta, tb = ta.lower(), tb.lower()
    return ta == tb

def write_unified_diff(path_a, path_b, *, encoding="utf-8", normalize_line_endings=True, out_path: Optional[str] = None) -> str:
    pa, pb = Path(path_a), Path(path_b)
    ta, tb = pa.read_text(encoding=encoding), pb.read_text(encoding=encoding)
    if normalize_line_endings:
        ta = ta.replace("\r\n", "\n").replace("\r", "\n")
        tb = tb.replace("\r\n", "\n").replace("\r", "\n")
    la, lb = ta.splitlines(keepends=True), tb.splitlines(keepends=True)
    diff = "".join(difflib.unified_diff(la, lb, fromfile=str(pa), tofile=str(pb), lineterm=""))
    if out_path:
        Path(out_path).write_text(diff, encoding="utf-8")
    return diff
def _normalize_json(value, *, sort_keys=True, float_tol: Optional[int] = None):
    if isinstance(value, dict):
        items = sorted(value.items()) if sort_keys else value.items()
        return {k: _normalize_json(v, sort_keys=sort_keys, float_tol=float_tol) for k, v in items}
    if isinstance(value, list):
        return [_normalize_json(v, sort_keys=sort_keys, float_tol=float_tol) for v in value]
    if isinstance(value, float) and float_tol is not None:
        return round(value, float_tol)
    return value

def json_equal(path_a, path_b, *, encoding="utf-8", sort_keys=True, float_tol: Optional[int] = None, write_diff_to: Optional[str] = None) -> bool:
    pa, pb = Path(path_a), Path(path_b)
    ja, jb = json.loads(pa.read_text(encoding=encoding)), json.loads(pb.read_text(encoding=encoding))
    na, nb = _normalize_json(ja, sort_keys=sort_keys, float_tol=float_tol), _normalize_json(jb, sort_keys=sort_keys, float_tol=float_tol)
    if na == nb: return True
    if write_diff_to:
        ta, tb = json.dumps(na, indent=2, ensure_ascii=False), json.dumps(nb, indent=2, ensure_ascii=False)
        diff = "".join(difflib.unified_diff(
            ta.splitlines(keepends=True), tb.splitlines(keepends=True),
            fromfile=str(pa), tofile=str(pb), lineterm=""
        ))
        Path(write_diff_to).write_text(diff, encoding="utf-8")
    return False

def csv_keyed_equal(
    path_a, path_b, *, key_cols: List[str], encoding="utf-8",
    ignore_case=False, ignore_whitespace=True, write_report_to: Optional[str] = None
) -> bool:
    def load_csv(path: Path) -> Tuple[Dict[Tuple, Dict[str,str]], List[str]]:
        with path.open("r", encoding=encoding, newline="") as f:
            rdr = csv.DictReader(f)
            headers = rdr.fieldnames or []
            missing = [k for k in key_cols if k not in headers]
            if missing: raise ValueError(f"{path}: missing key column(s): {missing}")
            table: Dict[Tuple, Dict[str,str]] = {}
            for row in rdr:
                norm = {}
                for k, v in row.items():
                    v = "" if v is None else v
                    if ignore_whitespace: v = v.strip()
                    if ignore_case and k not in key_cols: v = v.lower()
                    norm[k] = v
                key = tuple(norm[k] for k in key_cols)
                if key in table: raise ValueError(f"{path}: duplicate key {key}")
                table[key] = norm
            return table, headers

    pa, pb = Path(path_a), Path(path_b)
    ta, _ = load_csv(pa); tb, _ = load_csv(pb)

    keys_a, keys_b = set(ta.keys()), set(tb.keys())
    only_a, only_b, common = sorted(keys_a - keys_b), sorted(keys_b - keys_a), sorted(keys_a & keys_b)

    diffs = []
    for key in common:
        ra, rb = ta[key], tb[key]
        for col in sorted(set(ra) | set(rb)):  # <-- fixed union here
            if ra.get(col, "") != rb.get(col, ""):
                diffs.append((key, col, ra.get(col, ""), rb.get(col, "")))

    equal = (not only_a and not only_b and not diffs)

    if write_report_to:
        lines = [f"CSV compare: {pa} vs {pb}", f"Keys: {key_cols}", ""]
        if only_a:
            lines += ["Only in A:"] + [f"  {k}" for k in only_a] + [""]
        if only_b:
            lines += ["Only in B:"] + [f"  {k}" for k in only_b] + [""]
        if diffs:
            lines += ["Row diffs:"]
            for key, col, va, vb in diffs:
                lines.append(f"  {key} :: {col}: A='{va}'  B='{vb}'")
        if equal: lines.append("No differences.")
        Path(write_report_to).write_text("\n".join(lines), encoding="utf-8")
    return equal

def dir_compare(dir_a, dir_b, *, compare_content=False, method="auto") -> Dict[str, List[str]]:
    root_a, root_b = Path(dir_a).resolve(), Path(dir_b).resolve()
    if not root_a.is_dir(): raise NotADirectoryError(root_a)
    if not root_b.is_dir(): raise NotADirectoryError(root_b)
    def inv(root: Path) -> Dict[str, Tuple[Path,int]]:
        out = {}
        for p in root.rglob("*"):
            if p.is_file():
                out[str(p.relative_to(root).as_posix())] = (p, p.stat().st_size)
        return out
    ia, ib = inv(root_a), inv(root_b)
    ra, rb = set(ia), set(ib)
    left_only, right_only, common = sorted(ra - rb), sorted(rb - ra), sorted(ra & rb)
    size_mismatch, content_mismatch = [], []
    for rel in common:
        pa, sa = ia[rel]; pb, sb = ib[rel]
        if sa != sb:
            size_mismatch.append(rel); continue
        if compare_content and not files_equal(pa, pb, method=method):
            content_mismatch.append(rel)
    return {"left_only": left_only, "right_only": right_only, "size_mismatch": size_mismatch, "content_mismatch": content_mismatch}

def ensure_equal_or_exit(
    mode: str, a: str, b: str, *,
    # text
    text_ignore_ws=False, text_ignore_case=False, text_normalize_eol=True, text_ignore_patterns: Optional[List[str]] = None,
    # json
    json_sort_keys=True, json_float_tol: Optional[int] = None,
    # csv
    csv_keys: Optional[List[str]] = None, csv_report: Optional[str] = None,
    # dir
    dir_compare_content=False,
    # binary
    binary_method="auto",
    # common
    diff_out: Optional[str] = None,
) -> None:
    """
    Exit codes: 0 equal, 1 different, 2 error
    """
    import sys
    try:
        if mode == "binary":
            ok = files_equal(a, b, method=binary_method)
        elif mode == "text":
            ok = text_equal(a, b,
                            normalize_line_endings=text_normalize_eol,
                            ignore_whitespace=text_ignore_ws,
                            ignore_case=text_ignore_case,
                            ignore_patterns=text_ignore_patterns)
            if not ok and diff_out:
                write_unified_diff(a, b, out_path=diff_out)
        elif mode == "json":
            ok = json_equal(a, b, sort_keys=json_sort_keys, float_tol=json_float_tol, write_diff_to=diff_out)
        elif mode == "csv":
            if not csv_keys:
                raise ValueError("csv mode requires csv_keys")
            ok = csv_keyed_equal(a, b, key_cols=csv_keys, write_report_to=csv_report)
        elif mode == "dir":
            report = dir_compare(a, b, compare_content=dir_compare_content)
            ok = all(not report[k] for k in report)
            if not ok and diff_out:
                lines = [f"Directory compare: {a} vs {b}", ""]
                for key in ("left_only","right_only","size_mismatch","content_mismatch"):
                    vals = report[key]
                    if vals:
                        lines.append(f"{key}:")
                        lines += [f"  {v}" for v in vals]
                        lines.append("")
                Path(diff_out).write_text("\n".join(lines), encoding="utf-8")
        else:
            raise ValueError(f"Unknown mode: {mode}")
        sys.exit(0 if ok else 1)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(2)

# ========= BASELINE COMPARE FOR RUN FLOW =========
def compare_against_baseline(
    run_results: List[dict],
    baseline_dir: str,
    diff_dir: str,
    *,
    ignore_ws: bool = True,
    ignore_case: bool = False,
    normalize_eol: bool = True,
    ignore_patterns: Optional[List[str]] = None
) -> Dict[str, List[str]]:
    """
    Compare each device's text artifact to baseline/<device>.txt
    Writes diffs for mismatches to diff_dir/<device>_<RUN_TS>.diff
    Returns dict with: matched, mismatched, missing_baseline, failed
    """
    os.makedirs(diff_dir, exist_ok=True)
    baseline = Path(baseline_dir)
    summary = {"matched": [], "mismatched": [], "missing_baseline": [], "failed": []}
    for r in run_results:
        dev = r.get("device")
        status = r.get("status")
        if status != "ok":
            summary["failed"].append(dev or "unknown")
            continue
        artifact = r.get("results_file")
        if not artifact or not Path(artifact).is_file():
            summary["failed"].append(dev or "unknown")
            continue
        base_txt = baseline / f"{dev}.txt"
        if not base_txt.is_file():
            summary["missing_baseline"].append(str(base_txt))
            continue
        equal = text_equal(
            base_txt,
            artifact,
            normalize_line_endings=normalize_eol,
            ignore_whitespace=ignore_ws,
            ignore_case=ignore_case,
            ignore_patterns=ignore_patterns
        )
        if equal:
            summary["matched"].append(dev)
        else:
            diff_path = Path(diff_dir) / f"{dev}_{RUN_TS}.diff"
            write_unified_diff(base_txt, artifact, out_path=str(diff_path))
            summary["mismatched"].append(str(diff_path))
    return summary

# ========= CLI =========
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Network validation runner with compare support")
    sub = p.add_subparsers(dest="cmd")

    # run (default)
    pr = sub.add_parser("run", help="Execute device commands and optionally compare to baselines")
    pr.add_argument("--max-workers", type=int, default=None, help="Thread workers (default=min(8,len(devices)))")
    pr.add_argument("--baseline-dir", help="Path to baselines (expects <device>.txt)")
    pr.add_argument("--diff-dir", default=os.path.join(ARTIFACTS_DIR, f"diffs_{RUN_TS}"), help="Where to write diff files")
    pr.add_argument("--ignore-ws", action="store_true", help="Ignore whitespace for text baseline compare")
    pr.add_argument("--ignore-case", action="store_true", help="Ignore case for text baseline compare")
    pr.add_argument("--no-normalize-eol", action="store_true", help="Do not normalize line endings for text baseline compare")
    pr.add_argument("--ignore-pattern", action="append", help="Regex to ignore lines (repeatable)")
    pr.add_argument("--no-fail-on-diff", action="store_true", help="Do not exit 1 on diffs; just log")

    # compare subcommand
    cp = sub.add_parser("compare", help="Compare two targets (files or directories)")
    cp.add_argument("a")
    cp.add_argument("b")
    cp.add_argument("--mode", choices=["binary","text","json","csv","dir"], default="binary")
    # Text
    cp.add_argument("--ignore-ws", action="store_true")
    cp.add_argument("--ignore-case", action="store_true")
    cp.add_argument("--no-normalize-eol", action="store_true")
    cp.add_argument("--ignore-pattern", action="append", help="Regex to ignore lines (repeatable)")
    # JSON
    cp.add_argument("--no-json-sort-keys", action="store_true")
    cp.add_argument("--json-float-tol", type=int, help="Round floats to N decimals")
    # CSV
    cp.add_argument("--csv-keys", nargs="+", help="Primary key columns for CSV mode")
    cp.add_argument("--csv-report", help="Write CSV diff report here")
    # Dir
    cp.add_argument("--dir-content", action="store_true", help="Also compare file contents")
    # Binary/common
    cp.add_argument("--binary-method", choices=["auto","hash","bytes"], default="auto")
    cp.add_argument("--diff-out", help="Write unified diff/report to this path")

    return p

def main():
    parser = build_parser()
    args = parser.parse_args()

    # Default to "run" when no subcommand is provided
    if args.cmd is None:
        args = parser.parse_args(["run"])

    if args.cmd == "run":
        max_workers = args.max_workers if args.max_workers else min(8, len(devices))
        summary = run_all(devices, commands, max_workers=max_workers)

        ok = [r for r in summary if r.get("status") == "ok"]
        fail = [r for r in summary if r.get("status") != "ok"]
        logging.info(f"Completed. Success: {len(ok)} Failed: {len(fail)}")

        exit_code = 0
        if args.baseline_dir:
            logging.info(f"Comparing artifacts to baselines in: {args.baseline_dir}")
            comp = compare_against_baseline(
                summary,
                args.baseline_dir,
                args.diff_dir,
                ignore_ws=args.ignore_ws,
                ignore_case=args.ignore_case,
                normalize_eol=not args.no_normalize_eol,
                ignore_patterns=args.ignore_pattern
            )
            # Log baseline compare results
            if comp["matched"]:
                logging.info(f"Matched ({len(comp['matched'])}): {', '.join(comp['matched'])}")
            if comp["mismatched"]:
                logging.warning("Mismatched diffs written:")
                for p in comp["mismatched"]:
                    logging.warning(f"  {p}")
                exit_code = 1 if not args.no_fail_on_diff else 0
            if comp["missing_baseline"]:
                logging.warning("Missing baselines:")
                for p in comp["missing_baseline"]:
                    logging.warning(f"  {p}")
                # Treat missing baseline as non-fatal here; adjust if you want exit 1
            if comp["failed"]:
                logging.error("Devices with failed collection:")
                for d in comp["failed"]:
                    logging.error(f"  {d}")
                # Collection failure already accounted in overall status; keep exit_code as is

        # Exit with code capturing baseline diffs (if any) unless --no-fail-on-diff
        raise SystemExit(exit_code)

    elif args.cmd == "compare":
        ensure_equal_or_exit(
            args.mode, args.a, args.b,
            text_ignore_ws=args.ignore_ws,
            text_ignore_case=args.ignore_case,
            text_normalize_eol=not args.no_normalize_eol,
            text_ignore_patterns=args.ignore_pattern,
            json_sort_keys=not args.no_json_sort_keys,
            json_float_tol=args.json_float_tol,
            csv_keys=args.csv_keys,
            csv_report=args.csv_report,
            dir_compare_content=args.dir_content,
            binary_method=args.binary_method,
            diff_out=args.diff_out,
        )
    else:
        parser.print_help()
        raise SystemExit(2)

if __name__ == "__main__":
    main()

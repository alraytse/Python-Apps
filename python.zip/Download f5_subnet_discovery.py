#!/usr/bin/env python3
import paramiko
import getpass
import socket
import ipaddress
import re


def resolve_host(host):
    try:
        socket.inet_aton(host)
        print(f"[INFO] Using IP address: {host}")
        return host
    except OSError:
        pass

    try:
        ip = socket.gethostbyname(host)
        print(f"[INFO] Resolved {host} -> {ip}")
        return ip
    except socket.gaierror:
        raise Exception(
            f"Unable to resolve hostname '{host}'. Use a valid hostname or management IP."
        )


def connect_f5(host, username, password):
    ip = resolve_host(host)

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    ssh.connect(
        hostname=ip,
        username=username,
        password=password,
        look_for_keys=False,
        allow_agent=False,
        timeout=20,
    )

    print(f"[INFO] Connected to {ip}")
    return ssh


def run_command(ssh, cmd):
    stdin, stdout, stderr = ssh.exec_command(cmd)
    return stdout.read().decode(errors='ignore')


def ip_in_subnet(ip, subnet):
    try:
        return ipaddress.ip_address(ip) in ipaddress.ip_network(subnet, strict=False)
    except Exception:
        return False


def search_routes(ssh, subnet):
    print('\n=== ROUTES ===')
    output = run_command(ssh, 'tmsh list net route')
    found = False
    for line in output.splitlines():
        if subnet in line:
            print(line.strip())
            found = True
    if not found:
        print('No routes found.')


def search_selfips(ssh, subnet):
    print('\n=== SELF IPS ===')
    output = run_command(ssh, 'tmsh list net self')
    found = False
    for block in output.split('net self'):
        ips = re.findall(r'address\s+(\d+\.\d+\.\d+\.\d+)', block)
        for ip in ips:
            if ip_in_subnet(ip, subnet):
                print(block.strip())
                print('-' * 60)
                found = True
    if not found:
        print('No Self IPs found.')


def search_virtuals(ssh, subnet):
    print('\n=== VIRTUAL SERVERS ===')
    output = run_command(ssh, 'tmsh list ltm virtual')
    found = False
    ips = re.findall(r'(\d+\.\d+\.\d+\.\d+)', output)
    for ip in sorted(set(ips)):
        if ip_in_subnet(ip, subnet):
            print(ip)
            found = True
    if not found:
        print('No virtual servers found.')


def search_pool_members(ssh, subnet):
    print('\n=== POOL MEMBERS ===')
    output = run_command(ssh, 'tmsh list ltm pool')
    found = False
    ips = re.findall(r'(\d+\.\d+\.\d+\.\d+):\d+', output)
    for ip in sorted(set(ips)):
        if ip_in_subnet(ip, subnet):
            print(ip)
            found = True
    if not found:
        print('No pool members found.')


def search_snats(ssh, subnet):
    print('\n=== SNATS ===')
    output = run_command(ssh, 'tmsh list ltm snat')
    found = False
    ips = re.findall(r'(\d+\.\d+\.\d+\.\d+)', output)
    for ip in sorted(set(ips)):
        if ip_in_subnet(ip, subnet):
            print(ip)
            found = True
    if not found:
        print('No SNAT addresses found.')


def main():
    print('F5 Subnet Discovery Tool')
    print('-' * 60)

    host = input('Enter F5 hostname or IP address: ').strip()
    username = input('Username: ').strip()
    password = getpass.getpass('Password: ')
    subnet = input('Subnet to search (e.g. 143.112.157.0/25): ').strip()

    try:
        ssh = connect_f5(host, username, password)
        search_routes(ssh, subnet)
        search_selfips(ssh, subnet)
        search_virtuals(ssh, subnet)
        search_pool_members(ssh, subnet)
        search_snats(ssh, subnet)
        ssh.close()
        print('\nCompleted.')
    except Exception as e:
        print(f'ERROR: {e}')


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
nat_acl_extractor.py

Prompts for a comma-delimited list of host names, a username, and a
password. Connects to each host, runs 'show running-config', finds any
NAT or PAT access-lists (i.e. ACLs referenced by 'ip nat ... source list'),
and extracts:
  - source: the IP networks/wildcards permitted by that ACL
  - destination: the NAT/PAT target itself (interface or pool name)

Assumes Cisco IOS-style syntax. Adjust the regex patterns / device_type
if your platform's config looks different (IOS-XE, ASA, etc.).

Requires: netmiko   ->   pip install netmiko
Falls back to a basic paramiko SSH session if netmiko isn't installed,
but netmiko is strongly recommended for clean command output.
"""

import re
import csv
import time
import getpass
import json
from datetime import datetime

MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 5

try:
    from netmiko import ConnectHandler
    HAVE_NETMIKO = True
except ImportError:
    HAVE_NETMIKO = False
    import paramiko


def get_running_config_netmiko(host, username, password):
    device = {
        "device_type": "cisco_ios",
        "host": host,
        "username": username,
        "password": password,
    }
    conn = ConnectHandler(**device)
    output = conn.send_command("show running-config", read_timeout=60)
    conn.disconnect()
    return output


def get_running_config_paramiko(host, username, password):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=username, password=password, timeout=10)
    shell = client.invoke_shell()
    time.sleep(1)
    if shell.recv_ready():
        shell.recv(65535)  # clear banner/prompt
    shell.send("terminal length 0\n")
    time.sleep(1)
    if shell.recv_ready():
        shell.recv(65535)
    shell.send("show running-config\n")
    time.sleep(3)
    output = ""
    while shell.recv_ready():
        output += shell.recv(65535).decode(errors="ignore")
        time.sleep(0.5)
    client.close()
    return output


def get_running_config(host, username, password):
    last_exception = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            if HAVE_NETMIKO:
                return get_running_config_netmiko(host, username, password)
            return get_running_config_paramiko(host, username, password)
        except Exception as exc:
            last_exception = exc
            print(f"    [!] Attempt {attempt}/{MAX_RETRIES} failed for {host}: {exc}")
            if attempt < MAX_RETRIES:
                print(f"    [i] Retrying in {RETRY_DELAY_SECONDS}s ...")
                time.sleep(RETRY_DELAY_SECONDS)
    raise last_exception


def find_nat_pat_acls(config_text):
    """
    Finds 'ip nat inside/outside source list <acl> ...' statements.
    Returns a list of dicts: {acl, nat_type, direction, destination}
    """
    nat_statements = []
    # Matches lines like:
    #   ip nat inside source list 101 interface GigabitEthernet0/0 overload
    #   ip nat inside source list NAT_ACL pool MYPOOL overload
    pattern = re.compile(
        r"^ip nat (inside|outside) source list (\S+)\s+"
        r"(interface\s+\S+|pool\s+\S+)(\s+overload)?",
        re.MULTILINE,
    )
    for direction, acl, destination, overload in pattern.findall(config_text):
        nat_statements.append({
            "acl": acl,
            "nat_type": "PAT (overload)" if overload else "NAT (dynamic)",
            "direction": direction,
            "destination": destination.strip(),
        })
    return nat_statements


def extract_acl_source_ips(config_text, acl_name):
    """
    Extracts source IP/wildcard entries for a given ACL name/number.
    Handles both numbered ACLs and named extended ACLs, e.g.:
      access-list 101 permit ip 10.1.1.0 0.0.0.255 any
      ip access-list extended NAT_ACL
       permit ip 10.1.2.0 0.0.0.255 any
    """
    sources = []

    # Numbered ACL style
    numbered_pattern = re.compile(
        rf"^access-list {re.escape(acl_name)} permit ip (\S+) (\S+)",
        re.MULTILINE,
    )
    for src_ip, wildcard in numbered_pattern.findall(config_text):
        sources.append(f"{src_ip} {wildcard}")

    # Named ACL style: capture the indented block under its header line
    named_block_pattern = re.compile(
        rf"ip access-list extended {re.escape(acl_name)}\n((?:\s+.*\n?)+)"
    )
    block_match = named_block_pattern.search(config_text)
    if block_match:
        block = block_match.group(1)
        line_pattern = re.compile(r"permit ip (\S+) (\S+)")
        for src_ip, wildcard in line_pattern.findall(block):
            sources.append(f"{src_ip} {wildcard}")

    return sources


def write_results_to_csv(results):
    """
    Writes one row per source IP entry to a CSV file named
    nat-pat-extract-<date>-<time>.csv, e.g. nat-pat-extract-20260924-153045.csv
    Columns: Host, ACL, NAT_Type, Source, Destination
    """
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"nat-pat-extract-{timestamp}.csv"

    with open(filename, "w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["Host", "ACL", "NAT_Type", "Source", "Destination"])

        for host, host_results in results.items():
            if isinstance(host_results, dict) and "error" in host_results:
                writer.writerow([host, "", "", f"ERROR: {host_results['error']}", ""])
                continue

            if not host_results:
                writer.writerow([host, "", "", "No NAT/PAT ACLs found", ""])
                continue

            for entry in host_results:
                sources = entry["source"] or [""]
                for src in sources:
                    writer.writerow([
                        host,
                        entry["acl"],
                        entry["nat_type"],
                        src,
                        entry["destination"],
                    ])

    return filename


def main():
    hosts_input = input("Enter host names (comma separated): ")
    hosts = [h.strip() for h in hosts_input.split(",") if h.strip()]

    username = input("Username: ")
    password = getpass.getpass("Password: ")

    if not HAVE_NETMIKO:
        print("[!] netmiko not installed, falling back to raw paramiko SSH.")
        print("    For reliable results, run: pip install netmiko\n")

    results = {}

    for host in hosts:
        print(f"\n[+] Connecting to {host} ...")
        try:
            config_text = get_running_config(host, username, password)
        except Exception as exc:
            print(f"[!] Failed to connect to {host}: {exc}")
            results[host] = {"error": str(exc)}
            continue

        nat_statements = find_nat_pat_acls(config_text)

        if not nat_statements:
            print(f"    No NAT/PAT ACLs found on {host}.")
            results[host] = []
            continue

        host_results = []
        for stmt in nat_statements:
            source_ips = extract_acl_source_ips(config_text, stmt["acl"])
            host_results.append({
                "acl": stmt["acl"],
                "nat_type": stmt["nat_type"],
                "source": source_ips,
                "destination": stmt["destination"],
            })

        results[host] = host_results

        print(f"    Found {len(host_results)} NAT/PAT ACL(s) on {host}:")
        for entry in host_results:
            print(f"      ACL {entry['acl']} ({entry['nat_type']})")
            print(f"        Source:      {entry['source']}")
            print(f"        Destination: {entry['destination']}")

    print("\n=== Summary (JSON) ===")
    print(json.dumps(results, indent=2))

    csv_filename = write_results_to_csv(results)
    print(f"\n[+] Results written to {csv_filename}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3

import requests
import urllib3
import json

urllib3.disable_warnings()

BASE_URL = "https://mckesson.portal.alkira.com"

API_ENDPOINTS = [
    "/api/policyrules",
    "/api/policies",
    "/api/policyRules"
]


def get_token():
    token = input("Paste Alkira Bearer Token: ").strip()

    if token.lower().startswith("bearer "):
        token = token[7:]

    return token


def get_policies(token):

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }

    session = requests.Session()
    session.verify = False
    session.headers.update(headers)

    for endpoint in API_ENDPOINTS:

        url = BASE_URL + endpoint

        print(f"\nTrying: {url}")

        try:
            response = session.get(
                url,
                timeout=30
            )

            print(f"HTTP Status: {response.status_code}")

            if response.status_code != 200:
                continue

            data = response.json()

            if isinstance(data, list):
                return data

            if isinstance(data, dict):

                for field in [
                    "items",
                    "content",
                    "rules",
                    "policyRules",
                    "policies"
                ]:
                    if field in data:
                        return data[field]

                return [data]

        except Exception as e:
            print(f"Error: {e}")

    return []


def hit_count(policy):

    fields = [
        "hitCount",
        "hits",
        "matchCount",
        "ruleHits"
    ]

    for field in fields:
        if field in policy:
            try:
                return int(policy[field])
            except:
                pass

    return 0


def get_name(policy):

    for field in [
        "name",
        "ruleName",
        "displayName",
        "policyName"
    ]:
        if field in policy:
            return str(policy[field])

    return "Unknown"


def display_top_10(policies):

    if not policies:
        print("\nNo policies returned.")
        return

    print("\nDetected Fields:")
    print(json.dumps(list(policies[0].keys()), indent=2))

    policies = sorted(
        policies,
        key=hit_count,
        reverse=True
    )

    top10 = policies[:10]

    print("\n")
    print("=" * 100)
    print("TOP 10 ALKIRA POLICIES")
    print("=" * 100)

    print(
        f"{'Rank':<5}"
        f"{'Policy Name':<60}"
        f"{'Hits':>12}"
    )

    print("-" * 100)

    for rank, policy in enumerate(top10, start=1):

        print(
            f"{rank:<5}"
            f"{get_name(policy)[:60]:<60}"
            f"{hit_count(policy):>12}"
        )

    print("=" * 100)


def main():

    token = get_token()

    policies = get_policies(token)

    display_top_10(policies)


if __name__ == "__main__":
    main()
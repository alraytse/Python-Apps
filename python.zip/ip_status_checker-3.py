#!/usr/bin/env python3
"""
IP Status Checker
-----------------
Prompts for a user ID and password, reads a CSV file of network IPs,
checks whether each IP is active (reachable) or shutdown (unreachable),
and displays a report. Optionally verifies SSH login with the credentials.

CSV format (header row recommended):
    ip,hostname
    192.168.1.1,core-router
    192.168.1.10,web-server

If there is no "ip" column, the first column is treated as the IP.

Usage:
    python ip_status_checker.py devices.csv
    python ip_status_checker.py devices.csv --ssh      # also test SSH login
    python ip_status_checker.py devices.csv --log-level DEBUG --log-file run.log
    python ip_status_checker.py devices.csv --network 143.112.0.0/16   # default filter

Only public IPs inside --network (default 143.112.0.0/16, i.e. 143.112.x.x)
are checked; everything else in the CSV is ignored and logged.

Logging:
    Every run writes a timestamped log file (ip_checker_YYYYMMDD_HHMMSS.log)
    with full detail. The password is never logged.
"""

import argparse
import csv
import getpass
import ipaddress
import logging
import platform
import re
import socket
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

try:
    import paramiko  # optional, only needed for --ssh
except ImportError:
    paramiko = None

log = logging.getLogger("ip_checker")


# --------------------------------------------------------------------------
# Logging setup
# --------------------------------------------------------------------------
def setup_logging(log_file, level):
    """Console shows INFO+ messages; the log file records everything at `level`."""
    log.setLevel(logging.DEBUG)
    log.handlers.clear()

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(threadName)-12s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"))

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(max(level, logging.INFO))
    console_handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))

    log.addHandler(file_handler)
    log.addHandler(console_handler)

    # Keep paramiko's internal chatter out of the console
    logging.getLogger("paramiko").setLevel(logging.WARNING)


# --------------------------------------------------------------------------
# Credential prompt
# --------------------------------------------------------------------------
def get_credentials():
    user_id = input("Enter User ID: ").strip()
    password = getpass.getpass("Enter Password: ")  # input is hidden
    if not user_id or not password:
        log.error("User ID and password are required.")
        sys.exit(1)
    log.info("Credentials entered for user '%s' (password not logged)", user_id)
    return user_id, password


# --------------------------------------------------------------------------
# CSV reading
# --------------------------------------------------------------------------
IPV4_RE = re.compile(r"(?<![\d.])((?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3})(?![\d.])")


def _octet(cell):
    cell = cell.strip()
    return cell.isdigit() and 0 <= int(cell) <= 255


def _find_ip(row, raw_line):
    """Return (ip, index_of_ip_cell) found anywhere in the row."""
    # 1) A cell containing an IPv4 address (also handles '10.0.0.1/24', 'host 10.0.0.1')
    for i, cell in enumerate(row):
        m = IPV4_RE.search(cell)
        if m:
            return m.group(1), i
    # 2) IP split across 4 cells, e.g. a line like 192,168,1,1,router
    for i in range(len(row) - 3):
        if all(_octet(c) for c in row[i:i + 4]):
            return ".".join(c.strip() for c in row[i:i + 4]), i
    # 3) Last resort: search the raw text line
    m = IPV4_RE.search(raw_line)
    if m:
        return m.group(1), None
    return None, None


def read_ips(csv_path):
    text = None
    # Excel often saves CSVs as Windows-1252, not UTF-8, so try several encodings
    for enc in ("utf-8-sig", "utf-16", "cp1252", "latin-1"):
        try:
            with open(csv_path, encoding=enc, newline="") as f:
                text = f.read()
            if "\x00" in text:          # wrong guess for a UTF-16 file
                log.debug("Encoding %s produced null bytes, trying next", enc)
                continue
            log.debug("Read %s using encoding %s", csv_path, enc)
            break
        except FileNotFoundError:
            log.error("File not found: %s", csv_path)
            sys.exit(1)
        except PermissionError:
            log.error("Permission denied reading: %s", csv_path)
            sys.exit(1)
        except UnicodeError:
            log.debug("Encoding %s failed, trying next", enc)
            continue

    if not text or not text.strip():
        log.error("CSV file is empty: %s", csv_path)
        sys.exit(1)

    # Detect the delimiter (comma, semicolon, tab or pipe) - never '.'
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","
        log.debug("Could not detect delimiter, defaulting to ','")

    lines = text.splitlines()
    rows = list(csv.reader(lines, delimiter=delimiter))

    # Find a name/hostname column if there is a header row
    header = [h.strip().lower() for h in rows[0]] if rows else []
    name_idx = next((i for i, h in enumerate(header)
                     if h in ("hostname", "host", "name", "device", "device name")), None)

    devices, seen, skipped = [], set(), []
    for line, row in zip(lines, rows):
        if not row or not any(c.strip() for c in row):
            continue
        ip, ip_idx = _find_ip(row, line)
        if not ip:
            skipped.append(line.strip())
            continue
        if ip in seen:
            log.debug("Duplicate IP ignored: %s", ip)
            continue
        seen.add(ip)
        if name_idx is not None and name_idx < len(row) and name_idx != ip_idx:
            name = row[name_idx].strip()
        else:  # use the first non-IP, non-empty cell as a label
            name = next((c.strip() for i, c in enumerate(row)
                         if i != ip_idx and c.strip() and not IPV4_RE.search(c)
                         and not _octet(c)), "")
        devices.append({"ip": ip, "name": name[:20]})

    # Ignore a header line silently; report anything else that had no IP
    if skipped and header and not IPV4_RE.search(lines[0]):
        skipped = [s for s in skipped if s != lines[0].strip()]
    if skipped:
        log.warning("Skipped %d line(s) with no IP address, e.g.:", len(skipped))
        for s in skipped[:3]:
            log.warning("   %s", s[:80])
        for s in skipped[3:]:
            log.debug("Skipped line: %s", s[:80])
    log.info("Found %d unique IP(s) in %s (delimiter %r)", len(devices), csv_path, delimiter)
    return devices


# --------------------------------------------------------------------------
# IP filtering
# --------------------------------------------------------------------------
def filter_ips(devices, network):
    """Keep only public IPs inside `network` (e.g. 143.112.0.0/16)."""
    kept, outside, private = [], [], []
    for d in devices:
        ip = ipaddress.ip_address(d["ip"])
        if ip not in network:
            outside.append(d["ip"])
        elif not ip.is_global:
            private.append(d["ip"])
        else:
            kept.append(d)

    if outside:
        log.info("Ignored %d IP(s) outside %s", len(outside), network)
        for ip in outside:
            log.debug("Outside %s, ignored: %s", network, ip)
    if private:
        log.info("Ignored %d non-public IP(s)", len(private))
        for ip in private:
            log.debug("Not a public IP, ignored: %s", ip)
    log.info("%d public IP(s) in %s will be checked", len(kept), network)
    return kept


# --------------------------------------------------------------------------
# Status checks
# --------------------------------------------------------------------------
_PING_MISSING_LOGGED = False


def ping(ip, timeout=2):
    """Return True if the host replies to ping."""
    if platform.system().lower() == "windows":
        cmd = ["ping", "-n", "1", "-w", str(timeout * 1000), ip]
    else:
        cmd = ["ping", "-c", "1", "-W", str(timeout), ip]
    try:
        result = subprocess.run(cmd, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, timeout=timeout + 2)
        log.debug("%s ping return code %d", ip, result.returncode)
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        log.debug("%s ping timed out", ip)
        return False
    except FileNotFoundError:
        global _PING_MISSING_LOGGED
        if not _PING_MISSING_LOGGED:  # report once, not for every IP
            _PING_MISSING_LOGGED = True
            log.error("'ping' command not found; using TCP port checks only")
        return False


def port_open(ip, ports=(22, 80, 443), timeout=2):
    """Fallback check: True if any common TCP port accepts a connection."""
    for port in ports:
        try:
            with socket.create_connection((ip, port), timeout=timeout):
                log.debug("%s TCP port %d open", ip, port)
                return port
        except OSError as e:
            log.debug("%s TCP port %d closed/unreachable (%s)", ip, port, e)
            continue
    return None


def ssh_login(ip, user_id, password, timeout=5):
    """Try an SSH login with the supplied credentials."""
    if paramiko is None:
        return "paramiko not installed"
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(ip, username=user_id, password=password, timeout=timeout,
                       allow_agent=False, look_for_keys=False)
        log.debug("%s SSH login succeeded for %s", ip, user_id)
        return "Login OK"
    except paramiko.AuthenticationException:
        log.warning("%s SSH authentication failed for %s", ip, user_id)
        return "Auth failed"
    except Exception as e:
        log.debug("%s SSH unavailable: %s", ip, e)
        return "SSH unavailable"
    finally:
        client.close()


def check_device(device, user_id, password, use_ssh):
    ip = device["ip"]
    start = time.perf_counter()
    try:
        if ping(ip):
            active, method = True, "ping"
        else:
            port = port_open(ip)
            active, method = (True, f"tcp/{port}") if port else (False, "no response")
        device["status"] = "ACTIVE" if active else "SHUTDOWN"
        device["method"] = method
        device["ssh"] = ssh_login(ip, user_id, password) if (use_ssh and active) else "-"
    except Exception:
        log.exception("Unexpected error checking %s", ip)
        device.update(status="SHUTDOWN", method="error", ssh="-")
    device["elapsed"] = f"{time.perf_counter() - start:.2f}s"
    return device


# --------------------------------------------------------------------------
# Report
# --------------------------------------------------------------------------
def print_report(results, use_ssh):
    active = [r for r in results if r["status"] == "ACTIVE"]
    inactive = [r for r in results if r["status"] == "SHUTDOWN"]

    line = "=" * (70 if use_ssh else 50)
    print(f"\n{line}")
    print(f" NETWORK IP STATUS REPORT  -  {datetime.now():%Y-%m-%d %H:%M:%S}")
    print(line)

    def section(title, items):
        print(f"\n{title} ({len(items)})")
        print("-" * len(line))
        if not items:
            print("  None")
            return
        for r in items:
            row = f"  {r['ip']:<18}{r['name']:<22}{r['status']:<10}"
            if use_ssh:
                row += r["ssh"]
            print(row)

    section("ACTIVE IPs", active)
    section("INACTIVE / SHUTDOWN IPs", inactive)

    print(f"\n{line}")
    print(f" Total: {len(results)}   Active: {len(active)}   Inactive: {len(inactive)}")
    print(line)


def save_report(results, path):
    try:
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["ip", "name", "status", "method", "ssh", "elapsed"])
            writer.writeheader()
            writer.writerows(results)
        log.info("Report saved to: %s", path)
    except OSError as e:
        log.error("Could not save report to %s: %s", path, e)


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Check if network IPs are active or shutdown.")
    parser.add_argument("csv_file", nargs="?", help="CSV file containing IPs")
    parser.add_argument("--ssh", action="store_true", help="Also verify SSH login with credentials")
    parser.add_argument("--workers", type=int, default=20, help="Parallel checks (default 20)")
    parser.add_argument("--network", default="143.112.0.0/16",
                        help="Only check public IPs in this network (default 143.112.0.0/16)")
    parser.add_argument("--log-file", default=f"ip_checker_{RUN_STAMP}.log",
                        help="Log file path (default ip_checker_<timestamp>.log)")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        help="Detail level for the log file (default INFO)")
    args = parser.parse_args()

    try:
        network = ipaddress.ip_network(args.network, strict=False)
    except ValueError:
        parser.error(f"invalid --network value: {args.network}")

    setup_logging(args.log_file, getattr(logging, args.log_level))
    log.info("=== IP Status Checker started (python %s, %s) ===",
             platform.python_version(), platform.system())

    user_id, password = get_credentials()
    print(f"\nWelcome, {user_id}.")

    csv_file = args.csv_file or input("Enter CSV file path: ").strip()
    devices = read_ips(csv_file)
    if not devices:
        log.error("No valid IPs found in the CSV file.")
        sys.exit(1)

    devices = filter_ips(devices, network)
    if not devices:
        log.error("No public IPs in %s found in the CSV file.", network)
        sys.exit(1)

    if args.ssh and paramiko is None:
        log.warning("--ssh requested but paramiko is not installed (pip install paramiko)")

    log.info("Checking %d IP(s) with %d workers...", len(devices), args.workers)
    start = time.perf_counter()
    results, total = [], len(devices)
    with ThreadPoolExecutor(max_workers=args.workers, thread_name_prefix="worker") as pool:
        futures = [pool.submit(check_device, d, user_id, password, args.ssh) for d in devices]
        for n, fut in enumerate(as_completed(futures), 1):
            r = fut.result()
            results.append(r)
            log.info("[%d/%d] %-15s %-8s (%s, %s)%s", n, total, r["ip"], r["status"],
                     r["method"], r["elapsed"],
                     f" SSH: {r['ssh']}" if args.ssh and r["ssh"] != "-" else "")

    # keep the report in the same order as the CSV
    order = {d["ip"]: i for i, d in enumerate(devices)}
    results.sort(key=lambda r: order[r["ip"]])

    print_report(results, args.ssh)
    save_report(results, f"ip_status_report_{RUN_STAMP}.csv")

    active = sum(r["status"] == "ACTIVE" for r in results)
    log.info("=== Finished in %.1fs: %d total, %d active, %d inactive ===",
             time.perf_counter() - start, total, active, total - active)
    log.info("Log written to: %s", args.log_file)


RUN_STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log.warning("Cancelled by user.")
        print("\nCancelled by user.")
    except Exception:
        log.exception("Fatal error")
        raise

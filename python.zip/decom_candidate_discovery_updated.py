#!/usr/bin/env python3
import csv
import getpass
import ipaddress
import re
from datetime import datetime
from netmiko import ConnectHandler

OUTPUT_FILE=f"decom_candidates_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

# prompts

def get_subnets():
    start=input('Starting Subnet: ').strip()
    end=input('Ending Subnet: ').strip()
    s=ipaddress.ip_network(start,strict=False)
    e=ipaddress.ip_network(end,strict=False)
    if s.prefixlen!=e.prefixlen:
        raise ValueError('Starting and Ending subnets must use same mask')
    subs=[]
    cur=int(s.network_address)
    while cur<=int(e.network_address):
        subs.append(str(ipaddress.ip_network((ipaddress.ip_address(cur),s.prefixlen),strict=False)))
        cur+=s.num_addresses
    return subs

def get_switches():
    return [x.strip() for x in input('Switches (comma separated): ').split(',') if x.strip()]

def subnet_details(subnet):
    net=ipaddress.ip_network(subnet,strict=False)
    hosts=list(net.hosts())
    return {'Network':str(net.network_address),'Netmask':str(net.netmask),'Prefix':net.prefixlen,'FirstUsable':str(hosts[0]) if hosts else '','LastUsable':str(hosts[-1]) if hosts else '','UsableIPs':len(hosts)}

def get_route(conn,subnet):
    for cmd in [f'show ip route {subnet}',f'show ip route vrf all {subnet}',f'show route {subnet}']:
        try:
            out=conn.send_command(cmd,read_timeout=60)
            if not out:
                continue
            low=out.lower()
            if any(x in low for x in ['not in table','route not found','network not in table']):
                continue
            return out
        except Exception:
            pass
    return ''

def classify_route(route):
    r=route.lower()
    if 'null0' in r: return 'Null0'
    if 'directly connected' in r or 'attached' in r or 'vlan' in r: return 'Connected'
    if 'static' in r: return 'Static'
    if 'bgp' in r: return 'BGP'
    return 'Unknown'

def extract_vlan(route):
    m=re.search(r'vlan(\d+)',route,re.I)
    return m.group(1) if m else ''

def get_arp_count(conn,vlan):
    if not vlan:return 0
    try: out=conn.send_command(f'show ip arp vlan {vlan}',read_timeout=60)
    except: return 0
    ips=set()
    for line in out.splitlines():
        m=re.search(r'(\d+\.\d+\.\d+\.\d+)',line)
        if m and 'incomplete' not in line.lower(): ips.add(m.group(1))
    return len(ips)

def get_mac_count(conn,vlan):
    if not vlan:return 0
    try: out=conn.send_command(f'show mac address-table vlan {vlan}',read_timeout=60)
    except: return 0
    macs=set()
    for line in out.splitlines():
        m=re.search(r'([0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4})',line)
        if m: macs.add(m.group(1).lower())
    return len(macs)

def get_bgp_status(conn,subnet):
    for cmd in [f'show ip bgp {subnet}',f'show bgp ipv4 unicast {subnet}']:
        try:
            out=conn.send_command(cmd)
            if out and 'not in table' not in out.lower(): return True
        except: pass
    return False

def get_vlan_status(conn,vlan):
    if not vlan:return 'UNKNOWN'
    try:
        out=conn.send_command(f'show interface vlan {vlan}')
        low=out.lower()
        if 'administratively down' in low:return 'ADMIN_DOWN'
        if 'line protocol is down' in low:return 'DOWN'
        if 'line protocol is up' in low:return 'UP'
    except: pass
    return 'UNKNOWN'

def classify_candidate(rt,arp,mac,bgp,vs):
    if rt=='Unknown': return 'NO_ROUTE_FOUND'
    if rt in ['Null0','Static'] and arp==0 and mac==0 and not bgp and vs in ['DOWN','ADMIN_DOWN','UNKNOWN']:
        return 'HIGH_CONFIDENCE_DECOM'
    if arp==0 and mac==0: return 'REVIEW_REQUIRED'
    return 'ACTIVE'

if __name__=='__main__':
    results=[]
    subs=get_subnets()
    switches=get_switches()
    user=input('Username: ')
    pwd=getpass.getpass('Password: ')
    for sw in switches:
        try:
            conn=ConnectHandler(device_type='cisco_nxos',host=sw,username=user,password=pwd)
        except Exception as e:
            print(f'Failed {sw}: {e}')
            continue
        for subnet in subs:
            route=get_route(conn,subnet)
            vlan=extract_vlan(route)
            arp=get_arp_count(conn,vlan)
            mac=get_mac_count(conn,vlan)
            bgp=get_bgp_status(conn,subnet)
            vs=get_vlan_status(conn,vlan)
            rt=classify_route(route)
            row={'Subnet':subnet,'Switch':sw,'VLAN':vlan,'VLAN_Status':vs,'RouteType':rt,'ARP_Count':arp,'MAC_Count':mac,'BGP_Advertised':bgp,'Status':classify_candidate(rt,arp,mac,bgp,vs)}
            row.update(subnet_details(subnet))
            results.append(row)
        conn.disconnect()
    if results:
        with open(OUTPUT_FILE,'w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(results[0].keys()))
            w.writeheader(); w.writerows(results)
        print(f'Report written to {OUTPUT_FILE}')
        print('
=== SUMMARY ===')
        print('Total:',len(results))
        for state in ['ACTIVE','REVIEW_REQUIRED','NO_ROUTE_FOUND','HIGH_CONFIDENCE_DECOM']:
            print(f'{state}:',sum(1 for r in results if r['Status']==state))

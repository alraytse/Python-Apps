"""
Palo Alto NAT Policy Report
============================

Connects to one or more Palo Alto firewalls via the PAN-OS XML API and
generates a CSV audit of every NAT rule, including rule-hit-count usage
stats and a public-IP ownership lookup resolved from a local mapping file.

Inputs (interactive prompts):
    Firewalls          - comma-delimited list of firewall hostnames or IPs.
    Username / Password - PAN-OS admin credentials (used to generate an API
                           key on each firewall via type=keygen).
    Public IP map CSV  - path to a CSV with columns "subnet,owner"
                         (e.g. "143.112.184.0/24,Mckesson"). Used to resolve
                         the "Public IP Subnet" / "Public IP Ownership"
                         columns. Defaults to ./public_ip_map.csv.

Output:
    ~/Downloads/paloalto.nat.report.{TIMESTAMP}.csv
    One row per NAT rule (across all vsys, on all firewalls given), with
    columns:
        Name, Tags, Group, Original Packet Source Zone,
        Original Packet Destination Zone, Original Packet Destination
        Interface, Original Packet Source Address, Original Packet
        Destination Address, Original Packet Service, Translated Packet
        Source Translation, Translated Packet Destination Translation,
        Description, Rule Usage Hit Count, USON or MT NAT, Public IP
        Subnet, Public IP Ownership, Firewall, Vsys

ASSUMPTIONS (edit the constants below if your environment differs):
    - "USON or MT NAT" is derived from the NAT rule's source-translation
      type: static-ip -> "MT", dynamic-ip / dynamic-ip-and-port -> "USON".
      See NAT_TYPE_LABELS. Rules with no source-translation (destination
      NAT only) fall back to checking destination-translation type.
    - "Public IP Subnet"/"Public IP Ownership" are resolved by checking,
      in order: the translated source address, the translated destination
      address, the original destination address, and the original source
      address, against the subnets listed in the mapping CSV. First match
      wins.
    - Rule hit counts come from the "show rule-hit-count" operational
      command per vsys. If your PAN-OS version/permissions don't support
      this, the column will show "N/A" for all rules rather than failing.

Requires network access to each firewall's management HTTPS API and valid
PAN-OS admin credentials. SSL certificate verification is disabled.
"""

import csv
import getpass
import ipaddress
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from xml.etree import ElementTree as ET

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------------------
# Configuration (edit to match your environment)
# ---------------------------------------------------------------------------
NAT_TYPE_LABELS = {
    "static-ip": "MT",
    "dynamic-ip": "USON",
    "dynamic-ip-and-port": "USON",
}
API_TIMEOUT = 30
MAX_WORKERS = 5

# ---------------------------------------------------------------------------
# Interactive Inputs
# ---------------------------------------------------------------------------
fw_input = input("Enter comma-delimited list of firewalls (hostname or IP): ").strip()
FIREWALLS = [f.strip() for f in fw_input.split(",") if f.strip()]

USERNAME = input("Enter PAN-OS Username: ").strip()
PASSWORD = getpass.getpass("Enter PAN-OS Password: ").strip()

if not FIREWALLS:
    sys.exit("Error: No firewalls provided.")
if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")

map_path_input = input(
    "Enter path to Public IP ownership mapping CSV [default: ./public_ip_map.csv]: "
).strip()
MAP_PATH = map_path_input or "./public_ip_map.csv"

TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
OUTPUT_FILE = os.path.expanduser(
    f"~/Downloads/paloalto.nat.report.{TIMESTAMP}.csv"
)

session = requests.Session()
session.verify = False


# ---------------------------------------------------------------------------
# Public IP mapping
# ---------------------------------------------------------------------------
def load_ip_mapping(path: str) -> list:
    """Loads a CSV of subnet,owner rows into a list of (ip_network, owner)."""
    mapping = []
    if not os.path.isfile(path):
        print(f"Warning: mapping file '{path}' not found. Public IP columns will be 'N/A'.")
        return mapping

    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        rows = list(reader)

    if not rows:
        return mapping

    # Skip a header row if present.
    start_idx = 1 if rows[0] and rows[0][0].strip().lower() in ("subnet", "network") else 0

    for row in rows[start_idx:]:
        if len(row) < 2:
            continue
        subnet_str, owner = row[0].strip(), row[1].strip()
        if not subnet_str:
            continue
        try:
            network = ipaddress.ip_network(subnet_str, strict=False)
            mapping.append((network, owner))
        except ValueError:
            print(f"Warning: skipping invalid subnet '{subnet_str}' in mapping file.")

    return mapping


def resolve_public_ip(candidates: list, mapping: list) -> tuple:
    """Checks candidate address strings (may contain multiple ';'-separated
    IPs) against the mapping and returns (subnet, owner) for the first hit."""
    for candidate in candidates:
        if not candidate or candidate.lower() in ("none", "any", "n/a"):
            continue
        for token in str(candidate).split(";"):
            token = token.strip().split("/")[0]
            try:
                ip_obj = ipaddress.ip_address(token)
            except ValueError:
                continue
            for network, owner in mapping:
                if ip_obj in network:
                    return (str(network), owner)
    return ("N/A", "N/A")


# ---------------------------------------------------------------------------
# PAN-OS API helpers
# ---------------------------------------------------------------------------
def generate_api_key(fw: str) -> str:
    url = f"https://{fw}/api/"
    params = {"type": "keygen", "user": USERNAME, "password": PASSWORD}
    res = session.get(url, params=params, timeout=API_TIMEOUT)
    res.raise_for_status()
    root = ET.fromstring(res.text)
    key_el = root.find(".//key")
    if key_el is None or not key_el.text:
        raise RuntimeError(f"Could not obtain API key from {fw} (check credentials).")
    return key_el.text


def api_get(fw: str, key: str, params: dict) -> ET.Element:
    url = f"https://{fw}/api/"
    params = {**params, "key": key}
    res = session.get(url, params=params, timeout=API_TIMEOUT)
    res.raise_for_status()
    root = ET.fromstring(res.text)
    if root.get("status") != "success":
        msg_el = root.find(".//msg")
        msg = msg_el.text if msg_el is not None else "unknown error"
        raise RuntimeError(f"API error on {fw}: {msg}")
    return root


def fetch_vsys_list(fw: str, key: str) -> list:
    """Returns list of vsys names; falls back to ['vsys1'] if the op
    command fails or the firewall reports none (single-vsys mode)."""
    try:
        root = api_get(fw, key, {"type": "op", "cmd": "<show><vsys></vsys></show>"})
        names = [e.get("name") for e in root.findall(".//vsys/entry") if e.get("name")]
        return names or ["vsys1"]
    except Exception:
        return ["vsys1"]


def fetch_nat_rules(fw: str, key: str, vsys: str) -> list:
    """Fetches raw NAT rule <entry> elements for one vsys."""
    xpath = f"/config/devices/entry/vsys/entry[@name='{vsys}']/rulebase/nat/rules"
    root = api_get(fw, key, {"type": "config", "action": "get", "xpath": xpath})
    return root.findall(".//rules/entry")


def fetch_hit_counts(fw: str, key: str, vsys: str) -> dict:
    """Returns {rule_name: hit_count_str} for a vsys's NAT rulebase.
    Returns an empty dict (rather than raising) if unsupported."""
    cmd = (
        "<show><rule-hit-count><vsys><vsys-name>"
        f"<entry name='{vsys}'><rule-base><entry name='nat'>"
        "<rules><all/></rules></entry></rule-base></entry>"
        "</vsys-name></vsys></rule-hit-count></show>"
    )
    try:
        root = api_get(fw, key, {"type": "op", "cmd": cmd})
        counts = {}
        for entry in root.findall(".//rules/entry"):
            name = entry.get("name")
            hit_el = entry.find("hit-count")
            if name and hit_el is not None and hit_el.text:
                counts[name] = hit_el.text.strip()
        return counts
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# Rule field extraction
# ---------------------------------------------------------------------------
def members_text(entry: ET.Element, tag: str, default: str = "any") -> str:
    parent = entry.find(tag)
    if parent is None:
        return default
    members = [m.text.strip() for m in parent.findall("member") if m.text and m.text.strip()]
    return ";".join(members) if members else default


def extract_source_translation(entry: ET.Element) -> tuple:
    """Returns (translation_summary_str, nat_type_key)."""
    st = entry.find("source-translation")
    if st is None:
        return ("none", None)

    for nat_type in ("static-ip", "dynamic-ip-and-port", "dynamic-ip"):
        child = st.find(nat_type)
        if child is None:
            continue

        if nat_type == "static-ip":
            addr_el = child.find("translated-address")
            addr = addr_el.text.strip() if addr_el is not None and addr_el.text else "N/A"
            return (addr, nat_type)

        translated_addr = child.find("translated-address")
        if translated_addr is not None:
            members = [m.text.strip() for m in translated_addr.findall("member") if m.text]
            if members:
                return (";".join(members), nat_type)

        iface_addr = child.find("interface-address")
        if iface_addr is not None:
            ip_el = iface_addr.find("ip")
            if ip_el is not None and ip_el.text:
                return (ip_el.text.strip(), nat_type)

        return ("N/A", nat_type)

    return ("N/A", None)


def extract_destination_translation(entry: ET.Element) -> tuple:
    """Returns (translation_summary_str, nat_type_key)."""
    dt = entry.find("destination-translation")
    if dt is None:
        return ("none", None)

    addr_el = dt.find("translated-address")
    port_el = dt.find("translated-port")
    addr = addr_el.text.strip() if addr_el is not None and addr_el.text else "N/A"
    if port_el is not None and port_el.text:
        addr = f"{addr}:{port_el.text.strip()}"

    dt_type_el = dt.find("dynamic-translated-address")
    nat_type = "static-ip" if dt_type_el is None else "dynamic-ip"
    return (addr, nat_type)


def determine_nat_label(src_type: str, dst_type: str) -> str:
    if src_type and src_type in NAT_TYPE_LABELS:
        return NAT_TYPE_LABELS[src_type]
    if dst_type and dst_type in NAT_TYPE_LABELS:
        return NAT_TYPE_LABELS[dst_type]
    return "N/A"


def build_row(fw: str, vsys: str, entry: ET.Element, hit_counts: dict, ip_mapping: list) -> dict:
    name = entry.get("name", "N/A")

    tag_el = entry.find("tag")
    tags = (
        ";".join(m.text.strip() for m in tag_el.findall("member") if m.text and m.text.strip())
        if tag_el is not None
        else "none"
    )
    tags = tags or "none"

    group_el = entry.find("group-tag")
    group = group_el.text.strip() if group_el is not None and group_el.text else "none"

    src_zone = members_text(entry, "from")
    dst_zone = members_text(entry, "to")

    to_iface_el = entry.find("to-interface")
    dst_iface = to_iface_el.text.strip() if to_iface_el is not None and to_iface_el.text else "any"

    orig_src_addr = members_text(entry, "source")
    orig_dst_addr = members_text(entry, "destination")

    service_el = entry.find("service")
    service = service_el.text.strip() if service_el is not None and service_el.text else "any"

    src_translation, src_nat_type = extract_source_translation(entry)
    dst_translation, dst_nat_type = extract_destination_translation(entry)

    descr_el = entry.find("description")
    description = descr_el.text.strip() if descr_el is not None and descr_el.text else "none"

    hit_count = hit_counts.get(name, "N/A")
    nat_label = determine_nat_label(src_nat_type, dst_nat_type)

    public_subnet, public_owner = resolve_public_ip(
        [src_translation, dst_translation, orig_dst_addr, orig_src_addr], ip_mapping
    )

    return {
        "Name": name,
        "Tags": tags,
        "Group": group,
        "Original Packet Source Zone": src_zone,
        "Original Packet Destination Zone": dst_zone,
        "Original Packet Destination Interface": dst_iface,
        "Original Packet Source Address": orig_src_addr,
        "Original Packet Destination Address": orig_dst_addr,
        "Original Packet Service": service,
        "Translated Packet Source Translation": src_translation,
        "Translated Packet Destination Translation": dst_translation,
        "Description": description,
        "Rule Usage Hit Count": hit_count,
        "USON or MT NAT": nat_label,
        "Public IP Subnet": public_subnet,
        "Public IP Ownership": public_owner,
        "Firewall": fw,
        "Vsys": vsys,
    }


# ---------------------------------------------------------------------------
# Per-firewall processing
# ---------------------------------------------------------------------------
def process_firewall(fw: str, ip_mapping: list) -> list:
    rows = []
    try:
        key = generate_api_key(fw)
    except Exception as e:
        print(f"[{fw}] Skipped: {e}")
        return rows

    vsys_list = fetch_vsys_list(fw, key)

    for vsys in vsys_list:
        try:
            rule_entries = fetch_nat_rules(fw, key, vsys)
        except Exception as e:
            print(f"[{fw}/{vsys}] Failed to fetch NAT rules: {e}")
            continue

        hit_counts = fetch_hit_counts(fw, key, vsys)

        for entry in rule_entries:
            rows.append(build_row(fw, vsys, entry, hit_counts, ip_mapping))

    print(f"[{fw}] Collected {len(rows)} NAT rule(s).")
    return rows


def main():
    ip_mapping = load_ip_mapping(MAP_PATH)

    all_rows = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {
            executor.submit(process_firewall, fw, ip_mapping): fw for fw in FIREWALLS
        }
        for future in as_completed(future_map):
            fw = future_map[future]
            try:
                all_rows.extend(future.result())
            except Exception as e:
                print(f"[{fw}] Unhandled error: {e}")

    headers = [
        "Name",
        "Tags",
        "Group",
        "Original Packet Source Zone",
        "Original Packet Destination Zone",
        "Original Packet Destination Interface",
        "Original Packet Source Address",
        "Original Packet Destination Address",
        "Original Packet Service",
        "Translated Packet Source Translation",
        "Translated Packet Destination Translation",
        "Description",
        "Rule Usage Hit Count",
        "USON or MT NAT",
        "Public IP Subnet",
        "Public IP Ownership",
        "Firewall",
        "Vsys",
    ]

    output_dir = os.path.dirname(OUTPUT_FILE)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"Export successful: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()

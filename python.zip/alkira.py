#!/usr/bin/env python3

import requests
import urllib3
import json

urllib3.disable_warnings()

token = input("Paste Bearer Token: ").strip()

if token.lower().startswith("bearer "):
    token = token[7:]

headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/json"
}

url = "https://mckesson.portal.alkira.com/api/tenantnetworks"

r = requests.get(
    url,
    headers=headers,
    verify=False,
    timeout=30
)

print(f"Status: {r.status_code}")

try:
    print(json.dumps(r.json(), indent=4))
except Exception:
    print(r.text)
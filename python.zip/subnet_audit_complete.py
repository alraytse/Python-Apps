#!/usr/bin/env python3
"""Enterprise Subnet Audit Tool
VRF-aware audit for Cisco IOS/IOS-XE, NX-OS and Arista EOS.
Includes route analysis, ARP/MAC utilization, interface descriptions,
reachability testing, null-route detection and decom recommendations.
"""

import csv
import getpass
import ipaddress
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from threading import Lock
from netmiko import ConnectHandler

TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
REPORT_FILE = f"subnet_report_{TIMESTAMP}.csv"
LOG_FILE = f"subnet_audit_{TIMESTAMP}.log"
AUDIT_FILE = f"command_audit_{TIMESTAMP}.csv"
FAILED_FILE = f"failed_devices_{TIMESTAMP}.csv"

COMMAND_LOG = []
FAILED_DEVICES = []
COMMAND_LOCK = Lock()
FAILED_LOCK = Lock()

SUPPORTED_TYPES = {"cisco_ios","cisco_xe","cisco_nxos","arista_eos"}

logging.basicConfig(level=logging.INFO,format="%(asctime)s | %(levelname)-8s | %(message)s",handlers=[logging.FileHandler(LOG_FILE),logging.StreamHandler()])

def record_command(host, command):
    with COMMAND_LOCK:
        COMMAND_LOG.append([datetime.now().isoformat(timespec="seconds"), host, command])

def send_command(conn, host, command, read_timeout=120):
    record_command(host, command)
    return conn.send_command(command, read_timeout=read_timeout)

def normalize_vrf(value):
    value=(value or '').strip()
    return None if not value or value.lower() in {'global','default','none'} else value

def build_route_command(subnet, vrf):
    net=ipaddress.ip_network(subnet, strict=False)
    return f'show ip route vrf {vrf} {net.network_address}' if vrf else f'show ip route {net.network_address}'

def build_arp_command(vrf):
    return f'show ip arp vrf {vrf}' if vrf else 'show ip arp'

def build_ping_command(target, vrf, device_type):
    if device_type=='cisco_nxos':
        return f'ping {target} count 5 timeout 1' + (f' vrf {vrf}' if vrf else '')
    return (f'ping vrf {vrf} ' if vrf else 'ping ') + f'{target} repeat 5 timeout 1'

def build_interface_description_db(output):
    db={}
    for line in output.splitlines():
        parts=re.split(r'\s{2,}', line.strip())
        if len(parts)>=2: db[parts[0].lower()]=parts[-1]
    return db

def count_arp_entries(arp_output, subnet):
    net=ipaddress.ip_network(subnet, strict=False)
    return len({ip for ip in re.findall(r'\b\d+\.\d+\.\d+\.\d+\b', arp_output) if ipaddress.ip_address(ip) in net})

def count_mac_entries(mac_output, vlan_id):
    if not vlan_id: return 0
    cnt=0
    for line in mac_output.splitlines():
        if 'dynamic' in line.lower():
            f=line.split()
            if f and f[0]==str(vlan_id): cnt+=1
    return cnt

def parse_route_output(output):
    lower=output.lower()
    route_present=not any(x in lower for x in ['network not in table','route not found','no route'])
    route_present = route_present and bool(re.search(r'routing entry|known via|directly connected|via\s+\d+\.\d+\.\d+\.\d+', lower))
    null_route=bool(re.search(r'null0|discard|blackhole|reject', lower))
    nh=re.search(r'via\s+(\d+\.\d+\.\d+\.\d+)', output,re.I)
    intf=''
    for p in [r'(Vlan\d+)',r'(Loopback\d+)',r'(Port-channel\d+)',r'(Po\d+)',r'(GigabitEthernet\S+)',r'(TenGigabitEthernet\S+)',r'(Ethernet\S+)',r'(Eth\S+)']:
        m=re.search(p,output,re.I)
        if m: intf=m.group(1); break
    rtype='Connected' if 'connected' in lower else 'Static' if 'static' in lower else 'BGP' if 'bgp' in lower else 'OSPF' if 'ospf' in lower else 'Unknown'
    return {'route_present':route_present,'route_type':rtype if route_present else 'No Route','interface':intf,'next_hop':nh.group(1) if nh else '','null_route':null_route}

def classify(route_present,null_route,arp_count,mac_count,reachability):
    if null_route: return 'NO','Intentional Null Route'
    if route_present and reachability=='REACHABLE': return 'NO','Route present and reachable'
    if route_present and (arp_count>0 or mac_count>0): return 'REVIEW','Activity detected'
    if not route_present and arp_count==0 and mac_count==0: return 'YES','No route, ARP or MAC activity'
    return 'REVIEW','Manual validation recommended'

print('Script created successfully')

import csv
import getpass
import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

USERNAME = input("Enter NetBrain Username: ").strip()
PASSWORD = getpass.getpass("Enter NetBrain Password: ").strip()

if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
OUTPUT_FILE = os.path.expanduser("~/Downloads/ddc1_network_inventory.csv")

MAX_WORKERS = 10
PAGE_LIMIT = 100
MAX_ESTIMATED_PAGES = 100

session = requests.Session()
session.verify = False
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


def authenticate() -> dict:
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    res = session.post(login_url, json=login_payload, timeout=15)
    if res.status_code != 200:
        raise RuntimeError(f"Auth failed ({res.status_code}): {res.text}")

    data = res.json()
    token = data.get("token")
    if not token:
        raise RuntimeError("Token missing in response payload.")

    session.headers.update(
        {
            "Token": token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
    )

    if data.get("tenantId") and data.get("domainId"):
        session.headers.update(
            {"tenantId": data.get("tenantId"), "domainId": data.get("domainId")}
        )

    return data


def fetch_device_page(skip_value: int) -> list:
    url = f"{BASE_URL}/CMDB/Devices"
    try:
        res = session.get(
            url, params={"skip": skip_value, "limit": PAGE_LIMIT}, timeout=30
        )
        return res.json().get("devices", []) if res.status_code == 200 else []
    except requests.RequestException:
        return []


def extract_interface_type(intf) -> str:
    if not intf:
        return ""

    if isinstance(intf, str):
        intf_name = intf.strip()
    elif isinstance(intf, dict):
        type_keys = [
            "interfaceType", "type", "intfType", "mediaType",
            "portType", "interface_type", "subType", "speed",
            "typeName", "type_name", "media_type", "port_type"
        ]

        for key in type_keys:
            val = intf.get(key)
            if val and str(val).strip() and str(val).lower() not in ["none", "null", "undefined", "n/a", "unknown"]:
                return str(val).strip()

        for parent in ["attributes", "properties", "details", "interfaceInfo", "spec", "data"]:
            sub_dict = intf.get(parent)
            if isinstance(sub_dict, dict):
                for key in type_keys:
                    val = sub_dict.get(key)
                    if val and str(val).strip() and str(val).lower() not in ["none", "null", "undefined", "n/a", "unknown"]:
                        return str(val).strip()

        intf_name = (
            intf.get("name")
            or intf.get("interfaceName")
            or intf.get("intfName")
            or intf.get("intf_name")
            or intf.get("ifName")
            or intf.get("portName")
            or ""
        )
    else:
        intf_name = str(intf).strip()

    if intf_name:
        match = re.match(r"^([a-zA-Z-]+)", str(intf_name).strip())
        if match:
            prefix = match.group(1).rstrip("-")
            if len(prefix) >= 2:
                return prefix

    return ""


def extract_vrfs_from_dict(data_obj, found_vrfs: set):
    """Recursively parses dicts or lists for VRF attributes cleanly without double-traversal."""
    if isinstance(data_obj, dict):
        vrf_keys = {
            "vrf", "vrfname", "vrf_name", "vrfs", "vrflist", "vrf_list",
            "vrftable", "vrfinfo", "vrfdetails", "virtualrouting"
        }
        
        for k, v in data_obj.items():
            k_lower = k.lower()
            if k_lower in vrf_keys:
                if isinstance(v, str) and v.strip():
                    found_vrfs.add(v.strip())
                elif isinstance(v, (int, float)):
                    found_vrfs.add(str(v))
                elif isinstance(v, list):
                    for item in v:
                        if isinstance(item, (str, int, float)) and str(item).strip():
                            found_vrfs.add(str(item).strip())
                        elif isinstance(item, dict):
                            extract_vrfs_from_dict(item, found_vrfs)
                elif isinstance(v, dict):
                    extract_vrfs_from_dict(item, found_vrfs)
            elif isinstance(v, (dict, list)):
                extract_vrfs_from_dict(v, found_vrfs)

    elif isinstance(data_obj, list):
        for item in data_obj:
            extract_vrfs_from_dict(item, found_vrfs)


def clean_vrf_names(vrfs: set) -> list:
    """Filters out status/boolean strings and normalizes the VRF list."""
    invalid_terms = {
        "none", "null", "undefined", "n/a", "unknown", "", "false", "true",
        "enabled", "disabled", "up", "down", "active", "inactive", "0"
    }
    
    valid_vrfs = {
        v.strip() for v in vrfs
        if isinstance(v, str) and v.strip() and v.strip().lower() not in invalid_terms
    }
    
    return sorted(list(valid_vrfs)) if valid_vrfs else ["default"]


def extract_interface_ips(data_obj, found_ips: set = None) -> set:
    if found_ips is None:
        found_ips = set()

    if not data_obj:
        return found_ips

    if isinstance(data_obj, str):
        ip_matches = re.findall(
            r"\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b", 
            data_obj
        )
        for ip in ip_matches:
            if ip not in ["0.0.0.0", "255.255.255.255", "127.0.0.1"]:
                found_ips.add(ip)

    elif isinstance(data_obj, dict):
        for k, v in data_obj.items():
            extract_interface_ips(v, found_ips)

    elif isinstance(data_obj, (list, tuple, set)):
        for item in data_obj:
            extract_interface_ips(item, found_ips)

    return found_ips


def enrich_device_metadata(device_id: str, hostname: str, device_raw: dict) -> tuple:
    types, vrfs, ip_addrs = set(), set(), set()

    extract_vrfs_from_dict(device_raw, vrfs)
    extract_interface_ips(device_raw, ip_addrs)

    params_to_try = []
    if device_id:
        params_to_try.append({"deviceId": device_id})
    if hostname:
        params_to_try.append({"hostname": hostname})

    endpoints = [
        f"{BASE_URL}/CMDB/Devices/Interfaces",
        f"{BASE_URL}/CMDB/Interfaces",
    ]

    for url in endpoints:
        for params in params_to_try:
            try:
                r = session.get(url, params=params, timeout=10)
                if r.status_code == 200:
                    res_data = r.json()
                    extract_vrfs_from_dict(res_data, vrfs)
                    extract_interface_ips(res_data, ip_addrs)

                    interfaces = res_data if isinstance(res_data, list) else res_data.get("interfaces", [])
                    for intf in interfaces:
                        if_type = extract_interface_type(intf)
                        if if_type:
                            types.add(if_type)
                    if interfaces or vrfs:
                        break
            except requests.RequestException:
                continue

    valid_vrfs = clean_vrf_names(vrfs)
    return list(types), valid_vrfs, list(ip_addrs)


def main():
    authenticate()

    all_ddc1_devices = []
    seen_hostnames = set()
    all_discovered_columns = {
        "interfaceTypes",
        "vrfNames",
        "interfaceIPs",
    }
    skip_offsets = [i * PAGE_LIMIT for i in range(MAX_ESTIMATED_PAGES)]

    EXCLUDED_FIELDS = {"hostName", "hostname", "mgmtIP"}

    print(f"Fetching global CMDB devices ({MAX_WORKERS} workers)...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(fetch_device_page, skip): skip
            for skip in skip_offsets
        }

        for future in as_completed(futures):
            devices_batch = future.result()
            for device in devices_batch:
                hostname = (
                    device.get("hostName")
                    or device.get("hostname")
                    or device.get("name")
                )

                if hostname and hostname not in seen_hostnames:
                    searchable_fields = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()

                    if "DDC1" in searchable_fields:
                        seen_hostnames.add(hostname)
                        flat_device = {
                            "_internal_id": device.get("id") or device.get("deviceId"),
                            "_raw_device": device
                        }

                        for k, v in device.items():
                            if k in EXCLUDED_FIELDS or any(
                                ex in k.lower() for ex in ["id", "discovery", "time"]
                            ):
                                continue
                            if k == "attributes" and isinstance(v, dict):
                                for sub_k, sub_v in v.items():
                                    if sub_k not in EXCLUDED_FIELDS and not any(
                                        ex in sub_k.lower() for ex in ["id", "discovery", "time"]
                                    ):
                                        flat_device[f"attr_{sub_k}"] = sub_v
                            else:
                                flat_device[k] = v

                        all_discovered_columns.update(
                            k for k in flat_device if not k.startswith("_")
                        )
                        all_ddc1_devices.append(flat_device)

    print(f"Found {len(all_ddc1_devices)} DDC1 assets. Enriching metadata...")

    if all_ddc1_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(
                    enrich_device_metadata,
                    dev.get("_internal_id"),
                    dev.get("name") or dev.get("hostName") or dev.get("hostname"),
                    dev.get("_raw_device", {})
                ): dev
                for dev in all_ddc1_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    types, vrfs, ips = future.result()
                    dev["interfaceTypes"] = ", ".join(sorted(types)) if types else "N/A"
                    dev["vrfNames"] = ", ".join(vrfs)
                    dev["interfaceIPs"] = ", ".join(sorted(ips)) if ips else "N/A"
                except Exception:
                    dev["interfaceTypes"] = "N/A"
                    dev["vrfNames"] = "default"
                    dev["interfaceIPs"] = "N/A"
                finally:
                    dev.pop("_internal_id", None)
                    dev.pop("_raw_device", None)

    if not all_ddc1_devices:
        all_ddc1_devices.append(
            {
                "name": "No Matching DDC1 Assets Discovered",
                "interfaceIPs": "N/A",
                "interfaceTypes": "N/A",
                "vrfNames": "default",
            }
        )

    # Header construction without dynamic boolean ifType columns
    primary_headers = ["name", "interfaceIPs", "interfaceTypes", "vrfNames"]
    extra_headers = sorted(
        [
            col
            for col in all_discovered_columns
            if col not in primary_headers and col not in EXCLUDED_FIELDS
        ]
    )
    ordered_headers = primary_headers + extra_headers

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=ordered_headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(all_ddc1_devices)

    print(f"Export successful: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
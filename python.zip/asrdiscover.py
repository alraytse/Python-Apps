
#!/usr/bin/env python3
"""
Discover Cisco ASR devices starting from a seed IP using SNMP-based CDP/LLDP.
Author: Alex-friendly build
"""

import argparse
import logging
import sys
import re
import json
import csv
from collections import deque
from typing import Dict, List, Optional, Tuple, Set


# --- Common OIDs ---
# System
OID_sysDescr     = '1.3.6.1.2.1.1.1.0'
OID_sysName      = '1.3.6.1.2.1.1.5.0'
OID_sysObjectID  = '1.3.6.1.2.1.1.2.0'

# ENTITY-MIB: entPhysicalModelName (string table)
OID_entPhysicalModelName = '1.3.6.1.2.1.47.1.1.1.1.13'

# CISCO-CDP-MIB (cdpCacheTable)
OID_cdpCacheAddress   = '1.3.6.1.4.1.9.9.23.1.2.1.1.4'   # Returns networkAddress (OCTET STRING with AFI)
OID_cdpCacheDeviceId  = '1.3.6.1.4.1.9.9.23.1.2.1.1.6'
OID_cdpCachePlatform  = '1.3.6.1.4.1.9.9.23.1.2.1.1.16'

# LLDP-MIB: remote systems
OID_lldpRemTable      = '1.0.8802.1.1.2.1.4.1.1'
OID_lldpRemSysName    = '1.0.8802.1.1.2.1.4.1.1.9'
# LLDP Remote Management Address Table (mgmt IPs)
OID_lldpRemManAddrTable = '1.0.8802.1.1.2.1.4.2.1'
OID_lldpRemManAddrIfSubtype = '1.0.8802.1.1.2.1.4.2.1.2'
OID_lldpRemManAddrInterfaceId = '1.0.8802.1.1.2.1.4.2.1.3'
OID_lldpRemManAddrOID = '1.0.8802.1.1.2.1.4.2.1.4'  # the Mgmt address (OCTET STRING; IPv4 bytes)


def build_auth(args):
    if args.snmp_version == '2c':
        return CommunityData(args.community, mpModel=1)
    else:
        # SNMPv3 user
        auth_proto = {
            'MD5': 'usmHMACMD5AuthProtocol',
            'SHA': 'usmHMACSHAAuthProtocol',
            'SHA256': 'usmHMAC128SHA224AuthProtocol',  # pysnmp depends on version
        }.get(args.auth, 'usmHMACSHAAuthProtocol')

        priv_proto = {
            'DES': 'usmDESPrivProtocol',
            'AES': 'usmAESPrivProtocol',
            'AES128': 'usmAES128PrivProtocol',
            'AES256': 'usmAES256PrivProtocol',
        }.get(args.priv, 'usmAESPrivProtocol')

        # Resolve actual objects from names
        from pysnmp.hlapi import (
            usmNoAuthProtocol,
            usmNoPrivProtocol,
            usmHMACMD5AuthProtocol,
            usmHMACSHAAuthProtocol,
            usmDESPrivProtocol,
            usmAESPrivProtocol,
            usmAES128PrivProtocol,
            usmAES256PrivProtocol,
        )
        auth_map = {
            'usmHMACMD5AuthProtocol': usmHMACMD5AuthProtocol,
            'usmHMACSHAAuthProtocol': usmHMACSHAAuthProtocol,
        }
        priv_map = {
            'usmDESPrivProtocol': usmDESPrivProtocol,
            'usmAESPrivProtocol': usmAESPrivProtocol,
            'usmAES128PrivProtocol': usmAES128PrivProtocol,
            'usmAES256PrivProtocol': usmAES256PrivProtocol,
        }

        auth_proto_obj = auth_map.get(auth_proto, usmNoAuthProtocol)
        priv_proto_obj = priv_map.get(priv_proto, usmNoPrivProtocol)

        return UsmUserData(
            args.user or '',
            args.authpass or None,
            args.privpass or None,
            authProtocol=auth_proto_obj,
            privProtocol=priv_proto_obj
        )


def snmp_get(ip: str, auth, oid: str, timeout: int, retries: int) -> Optional[str]:
    """Perform SNMP GET and return stringified value or None."""
    iterator = getCmd(
        SnmpEngine(),
        auth,
        UdpTransportTarget((ip, 161), timeout=timeout, retries=retries),
        ContextData(),
        ObjectType(ObjectIdentity(oid))
    )
    errorIndication, errorStatus, errorIndex, varBinds = next(iterator)
    if errorIndication or errorStatus:
        return None
    # Return the value as a native Python type converted to str
    return str(varBinds[0][1])


def snmp_walk(ip: str, auth, oid: str, timeout: int, retries: int) -> List[Tuple[str, str]]:
    """SNMP WALK; returns list of (oid, value) tuples as strings."""
    results = []
    for (errorIndication, errorStatus, errorIndex, varBinds) in nextCmd(
        SnmpEngine(),
        auth,
        UdpTransportTarget((ip, 161), timeout=timeout, retries=retries),
        ContextData(),
        ObjectType(ObjectIdentity(oid)),
        lexicographicMode=False
    ):
        if errorIndication or errorStatus:
            break
        for oid_obj, val in varBinds:
            results.append((str(oid_obj), val.prettyPrint()))
    return results


def _parse_cdp_ipv4(octet_str: str) -> Optional[str]:
    """
    Parse CISCO-CDP-MIB cdpCacheAddress OCTET STRING containing AFI+address.
    Many devices return 4-byte IPv4 directly; some include an AFI. We'll attempt common formats.
    """
    # pysnmp prettyPrint returns hex or dot; try to decode common forms
    if not octet_str:
        return None
    # If it's already dotted IP
    if re.match(r'^\d+\.\d+\.\d+\.\d+$', octet_str):
        return octet_str
    # If hex string like '0x0A141E32' -> convert last 4 bytes
    hexm = re.match(r'^0x([0-9A-Fa-f]+)$', octet_str)
    if hexm:
        hexbytes = hexm.group(1)
        # Use last 8 hex chars as IPv4
        if len(hexbytes) >= 8:
            b = bytes.fromhex(hexbytes[-8:])
            return '.'.join(str(x) for x in b)
    return None


def _parse_lldp_mgmt_addr(octet_str: str) -> Optional[str]:
    """
    LLDP mgmt address OCTET STRING often encodes IPv4 address as raw 4 bytes.
    We'll try to parse dotted decimal from either bytes or hex representation.
    """
    if not octet_str:
        return None
    if re.match(r'^\d+\.\d+\.\d+\.\d+$', octet_str):
        return octet_str
    hexm = re.match(r'^0x([0-9A-Fa-f]+)$', octet_str)
    if hexm:
        hb = hexm.group(1)
        # IPv4 commonly 4 bytes
        if len(hb) >= 8:
            b = bytes.fromhex(hb[-8:])
            return '.'.join(str(x) for x in b)
    return None


def get_device_info(ip: str, auth, timeout: int, retries: int) -> Dict[str, Optional[str]]:
    info = {
        'ip': ip,
        'sysName': snmp_get(ip, auth, OID_sysName, timeout, retries),
        'sysDescr': snmp_get(ip, auth, OID_sysDescr, timeout, retries),
        'sysObjectID': snmp_get(ip, auth, OID_sysObjectID, timeout, retries),
        'model': None
    }
    # Try to retrieve a representative entPhysicalModelName if present
    ent_models = snmp_walk(ip, auth, OID_entPhysicalModelName, timeout, retries)
    # Pick the first non-empty, or the longest descriptive one
    candidates = [v for _, v in ent_models if v and v != '']
    if candidates:
        # Choose the longest string as the "most descriptive"
        info['model'] = sorted(candidates, key=lambda s: len(s), reverse=True)[0]
    return info


_ASR_PATTERN = re.compile(
    r'\bASR\s?(1000|9K|9000|920|903|9900|9904|9010|9922|9006|9001)\b',
    re.IGNORECASE
)

def is_asr(info: Dict[str, Optional[str]]) -> bool:
    text = ' '.join([t for t in [info.get('sysDescr'), info.get('model')] if t])
    if _ASR_PATTERN.search(text or ''):
        return True
    # Some boxes report "ASR" alone in platform/model
    if text and 'ASR' in text.upper():
        return True
    # Cisco ASR often have Cisco OIDs; not definitive, but helps
    if info.get('sysObjectID', '').startswith('1.3.6.1.4.1.9'):  # Cisco
        # Require at least some ASR hint
        return _ASR_PATTERN.search(text or '') is not None
    return False


def get_neighbors(ip: str, auth, timeout: int, retries: int) -> List[Dict[str, Optional[str]]]:
    neighbors: List[Dict[str, Optional[str]]] = []

    # --- CDP neighbors ---
    cdp_addrs = snmp_walk(ip, auth, OID_cdpCacheAddress, timeout, retries)
    cdp_ids   = snmp_walk(ip, auth, OID_cdpCacheDeviceId, timeout, retries)
    cdp_plats = snmp_walk(ip, auth, OID_cdpCachePlatform, timeout, retries)

    # Index joins by trailing OID (instance index)
    def index_map(rows):  # rows: list[(oid, value)]
        m = {}
        for oid, val in rows:
            idx = oid.split('.')  # full oid
            m['.'.join(idx)] = val
        return m

    # For CDP, better to align by the common prefix path excluding last var id
    # Simplify: we won't do perfect index joins; we will just iterate addresses list.
    for oid, addr_val in cdp_addrs:
        ip_candidate = _parse_cdp_ipv4(addr_val)
        if ip_candidate:
            neighbors.append({
                'ip': ip_candidate,
                'via': 'CDP',
                'name': None,
                'platform': None
            })

    # Try to populate names/platforms roughly (best-effort)
    cdp_name_map = {oid: val for oid, val in cdp_ids}
    cdp_plat_map = {oid: val for oid, val in cdp_plats}

    # Attempt to match same instance index (use last 3-4 arcs heuristic)
    for n in neighbors:
        # Find closest matching OID suffix containing cdpCacheAddress instance
        # This is heuristic and may not always match; acceptable for discovery hints.
        pass  # keeping simple; platform/name will be filled by device_info later

    # --- LLDP neighbors (mgmt address if exposed) ---
    lldp_mgmt = snmp_walk(ip, auth, OID_lldpRemManAddrOID, timeout, retries)
    for oid, addr_val in lldp_mgmt:
        ip_candidate = _parse_lldp_mgmt_addr(addr_val)
        if ip_candidate:
            neighbors.append({
                'ip': ip_candidate,
                'via': 'LLDP',
                'name': None,
                'platform': None
            })

    # Deduplicate by IP while preserving first occurrence
    seen = set()
    deduped = []
    for n in neighbors:
        if n['ip'] and n['ip'] not in seen:
            deduped.append(n)
            seen.add(n['ip'])
    return deduped


def discover(seed_ips: List[str], auth, timeout: int, retries: int, max_depth: int) -> Tuple[Dict[str, Dict], List[Tuple[str, str, str]]]:
    """
    BFS discovery. Returns:
    - devices: map ip -> device_info dict (with ASR classification)
    - edges: list of (parent_ip, neighbor_ip, via)
    """
    devices: Dict[str, Dict] = {}
    edges: List[Tuple[str, str, str]] = []

    queue = deque([(seed, 0) for seed in seed_ips])
    visited: Set[str] = set()

    while queue:
        ip, depth = queue.popleft()
        if ip in visited:
            continue
        visited.add(ip)

        logging.info(f"Querying device {ip} at depth {depth}")
        info = get_device_info(ip, auth, timeout, retries)
        info['isASR'] = is_asr(info)
        devices[ip] = info

        if depth >= max_depth:
            continue

        neighs = get_neighbors(ip, auth, timeout, retries)
        for n in neighs:
            nip = n['ip']
            if not nip:
                continue
            edges.append((ip, nip, n.get('via') or 'unknown'))
            if nip not in visited:
                queue.append((nip, depth + 1))

    return devices, edges


def save_csv(path: str, devices: Dict[str, Dict], edges: List[Tuple[str, str, str]]) -> None:
    with open(path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['type', 'ip', 'neighbor_ip', 'via', 'sysName', 'model', 'sysDescr', 'sysObjectID', 'isASR'])
        for ip, d in devices.items():
            w.writerow(['device', ip, '', '', d.get('sysName'), d.get('model'), d.get('sysDescr'), d.get('sysObjectID'), d.get('isASR')])
        for u, v, via in edges:
            w.writerow(['edge', u, v, via, '', '', '', '', ''])


def main():
    parser = argparse.ArgumentParser(description="Discover Cisco ASR devices via SNMP CDP/LLDP BFS.")
    parser.add_argument('--seed', nargs='+', required=True, help='Seed IPv4 address(es) to start discovery.')
    parser.add_argument('--snmp-version', choices=['2c', '3'], default='2c', help='SNMP version (default: 2c)')
    parser.add_argument('-c', '--community', default='public', help='SNMPv2c community')
    parser.add_argument('--user', help='SNMPv3 user')
    parser.add_argument('--auth', choices=['MD5', 'SHA'], default='SHA', help='SNMPv3 auth protocol')
    parser.add_argument('--authpass', help='SNMPv3 auth password')
    parser.add_argument('--priv', choices=['DES', 'AES', 'AES128', 'AES256'], default='AES', help='SNMPv3 privacy protocol')
    parser.add_argument('--privpass', help='SNMPv3 privacy password')
    parser.add_argument('--timeout', type=int, default=2, help='SNMP timeout seconds (per request)')
    parser.add_argument('--retries', type=int, default=1, help='SNMP retries')
    parser.add_argument('--max-depth', type=int, default=3, help='Max neighbor depth to explore')
    parser.add_argument('--csv', help='Save discovery results to CSV path')
    parser.add_argument('--json', help='Save discovery results to JSON path')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s'
    )

    auth = build_auth(args)

    devices, edges = discover(args.seed, auth, args.timeout, args.retries, args.max_depth)

    # Print summary
    print("\n=== Devices Discovered ===")
    for ip, d in devices.items():
        flag = "ASR" if d.get('isASR') else "-"
        name = d.get('sysName') or ''
        model = d.get('model') or ''
        print(f"{ip:15} [{flag}]  {name:25}  {model}")

    print("\n=== Edges (parent -> neighbor via) ===")
    for u, v, via in edges:
        print(f"{u} -> {v}  ({via})")

    if args.csv:
        save_csv(args.csv, devices, edges)
        print(f"\nCSV written: {args.csv}")

    if args.json:
        with open(args.json, 'w') as jf:
            json.dump({'devices': devices, 'edges': edges}, jf, indent=2)
        print(f"JSON written: {args.json}")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(1)




#!/usr/bin/env python3
"""
Aruba switches: clear interface statistics, wait, then show error stats across multiple hosts via SSH.

Workflow:
- Prompt for comma-separated hostnames/IPs.
- Prompt for SSH username/password (global; optional). If omitted, prompt per-host.
- Execute on each host:
    1) clear interface statistics
    2) sleep N seconds (configurable delay)
    3) show interface error-statistics
- Write a per-host TXT file: <hostname>_<YYYY-MM-DD_HH-MM-SS>.txt

Requirements:
- Python 3.8+
- Paramiko: pip install paramiko
"""

import getpass
import datetime
import socket
import time
from typing import Tuple

def ssh_exec(host: str, username: str, password: str, cmd: str,
             port: int = 22, timeout: int = 15) -> Tuple[str, str, str]:
    """Execute a command over SSH. Returns (stdout, stderr, error_msg)."""
    try:
        import paramiko
    except Exception as e:
        return "", "", f"Paramiko not available: {e}. Install with 'pip install paramiko'."

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=host,
            username=username,
            password=password,
            port=port,
            timeout=timeout,
            look_for_keys=False,
            allow_agent=False,
        )
        stdin, stdout, stderr = client.exec_command(cmd)
        out = stdout.read().decode(errors="ignore")
        err = stderr.read().decode(errors="ignore")
        client.close()
        return out, err, None
    except (paramiko.SSHException, paramiko.AuthenticationException) as e:
        return "", "", f"SSH error: {e}"
    except socket.timeout:
        return "", "", "Connection timed out"
    except Exception as e:
        return "", "", f"Unexpected error: {e}"

def main():
    print("Aruba Clear → Delay → Show Interface Error-Stats (AOS-CX)")
    hosts_raw = input("Enter hostnames/IPs (comma-separated): ").strip()
    hosts = [h.strip() for h in hosts_raw.split(",") if h.strip()]
    if not hosts:
        print("No hosts provided. Exiting.")
        return

    username = input("Enter SSH username (press Enter to set per-host later): ").strip()
    password = None
    if username:
        password = getpass.getpass("Enter SSH password: ")

    # Delay prompt (seconds)
    delay_input = input("Enter delay (seconds) between CLEAR and SHOW [default 5]: ").strip()
    try:
        delay_seconds = int(delay_input) if delay_input else 5
        if delay_seconds < 0:
            raise ValueError
    except ValueError:
        print("Invalid delay value. Using default: 5 seconds.")
        delay_seconds = 5

    # Commands for AOS-CX
    clear_cmd = "clear interface statistics"
    show_cmd  = "show interface error-statistics"

    for host in hosts:
        print(f"\n--- {host} ---")
        host_user = username
        host_pass = password
        if not host_user:
            host_user = input(f"[{host}] SSH username: ").strip()
            host_pass = getpass.getpass(f"[{host}] SSH password: ")

        # 1) Clear counters
        clear_out, clear_err, clear_errmsg = ssh_exec(host, host_user, host_pass, clear_cmd)

        # 2) Delay
        print(f"[{host}] Waiting {delay_seconds} second(s) before collecting error statistics...")
        time.sleep(delay_seconds)

        # 3) Show error statistics
        show_out, show_err, show_errmsg = ssh_exec(host, host_user, host_pass, show_cmd)

        # Build per-host filename
        ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        safe_host = host.replace(":", "_").replace("/", "_")
        fname = f"{safe_host}_{ts}.txt"

        # Write report
        with open(fname, "w", encoding="utf-8") as fh:
            fh.write(f"Host: {host}\n")
            fh.write(f"Timestamp: {datetime.datetime.now().isoformat(timespec='seconds')}\n")

            fh.write(f"\n== CLEAR ==\nCommand: {clear_cmd}\n")
            if clear_errmsg:
                fh.write(f"ERROR: {clear_errmsg}\n")
            else:
                if clear_err and clear_err.strip():
                    fh.write("STDERR:\n" + clear_err + "\n")
                fh.write("OUTPUT:\n")
                fh.write(clear_out if clear_out else "<no output>\n")

            fh.write(f"\n== DELAY ==\nSeconds: {delay_seconds}\n")

            fh.write(f"\n== SHOW ==\nCommand: {show_cmd}\n")
            if show_errmsg:
                fh.write(f"ERROR: {show_errmsg}\n")
            else:
                if show_err and show_err.strip():
                    fh.write("STDERR:\n" + show_err + "\n\n")
                fh.write("OUTPUT:\n")
                fh.write(show_out if show_out else "<no output>\n")

        print(f"[{host}] Saved: {fname}")

    print("\nAll done.")

if __name__ == "__main__":
    main()

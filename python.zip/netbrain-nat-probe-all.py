"""
NetBrain NAT Data Probe -- ALL FIREWALLS
==========================================

One-off diagnostic script (not for reporting). Discovers every firewall at
a given site (same detection logic as netbrain-interface-report.py) and
pulls the vendor-appropriate NAT CLI command for each, in one pass, instead
of probing one hostname at a time.

Only pulls small, NAT-specific "show" commands via
CMDB/Devices/DeviceRawData -- never the full running config (which is
2.5MB+ and contains passwords/PSKs/SNMP strings).

Vendor -> command mapping (edit VENDOR_NAT_COMMANDS below as we confirm
real output for each platform):
    Palo Alto   -> "show running nat-policy"   (confirmed working, parser built)
    Cisco ASA   -> "show nat detail"           (unconfirmed -- needs a sample)
    Fortinet    -> "show firewall policy"      (unconfirmed -- needs a sample)
    Check Point -> not attempted -- CP NAT is normally read via SmartConsole/
                   Management API, not firewall CLI. Flagged, not queried.
    Unknown/other vendor -> skipped, listed at the end for manual follow-up.

Output: nat_probe_all_firewalls.json, keyed by hostname, containing each
firewall's vendor guess, the command run (if any), and the raw response.
A summary is also printed to the console.

Usage:
    python netbrain-nat-probe-all.py
"""

import getpass
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
PAGE_LIMIT = 100
MAX_WORKERS = 8

FIREWALL_KEYWORDS = [
    "firewall", "asa", "fortigate", "fortinet", "palo alto", "paloalto",
    "panorama", "checkpoint", "check point", "srx firewall", "ngfw",
]

# (vendor_label, command_or_None). None means "detected but not queried".
VENDOR_NAT_COMMANDS = [
    ("Palo Alto", ["palo alto", "paloalto", "panorama"], "show running nat-policy"),
    ("Cisco ASA", ["asa"], "show nat detail"),
    ("Fortinet", ["fortigate", "fortinet"], "show firewall policy"),
    ("Check Point", ["checkpoint", "check point"], None),
]


def authenticate(session, username, password):
    res = session.post(f"{BASE_URL}/Session", json={"username": username, "password": password}, timeout=60)
    res.raise_for_status()
    data = res.json()
    token = data.get("token") or data.get("tokenID")
    if not token:
        sys.exit(f"Error: no token in login response: {data}")
    session.headers.update({"Token": token, "Content-Type": "application/json", "Accept": "application/json"})
    if "tenantId" in data and "domainId" in data:
        session.headers.update({"tenantId": str(data["tenantId"]), "domainId": str(data["domainId"])})


def fetch_all_devices(session):
    all_devices = []
    skip = 0
    while True:
        url = f"{BASE_URL}/CMDB/Devices"
        try:
            res = session.get(url, params={"skip": skip, "limit": PAGE_LIMIT}, timeout=60)
            res.raise_for_status()
            devices = res.json().get("devices", [])
            if not devices:
                break
            all_devices.extend(devices)
            skip += PAGE_LIMIT
            if len(devices) < PAGE_LIMIT:
                break
        except requests.RequestException:
            break
    return all_devices


def is_firewall_device(device: dict) -> bool:
    candidate_values = []
    for key in ["subType", "sub_type", "subTypeName", "sub_type_name", "family", "type", "deviceType", "vendor", "model"]:
        val = device.get(key)
        if val and isinstance(val, str):
            candidate_values.append(val.lower())
    attrs = device.get("attributes")
    if isinstance(attrs, dict):
        for key in ["subType", "subTypeName", "family", "type", "deviceType", "vendor", "model"]:
            val = attrs.get(key)
            if val and isinstance(val, str):
                candidate_values.append(val.lower())
    combined = " ".join(candidate_values)
    return any(kw in combined for kw in FIREWALL_KEYWORDS), combined


def guess_vendor(combined_values: str):
    """Returns (vendor_label, command_or_None) or (None, None) if no match."""
    for label, keywords, cmd in VENDOR_NAT_COMMANDS:
        if any(kw in combined_values for kw in keywords):
            return label, cmd
    return "Unknown/other", None


def get_raw_data(session, hostname, cmd):
    url = f"{BASE_URL}/CMDB/Devices/DeviceRawData"
    params = {"hostname": hostname, "dataType": 2, "cmd": cmd}
    try:
        res = session.get(url, params=params, timeout=45)
        if res.status_code == 200:
            return res.json()
        return {"error": f"HTTP {res.status_code}"}
    except (requests.RequestException, ValueError) as e:
        return {"error": str(e)}


def main():
    username = input("Enter NetBrain Username: ").strip()
    password = getpass.getpass("Enter NetBrain Password: ").strip()
    site_input = input("Enter Target Site [default: DDC1]: ").strip().upper()
    target_site = site_input if site_input else "DDC1"

    if not username or not password:
        sys.exit("Username and password are required.")

    session = requests.Session()
    session.verify = False
    authenticate(session, username, password)

    print(f"Fetching CMDB devices for site '{target_site}'...")
    raw_devices = fetch_all_devices(session)

    firewalls = []
    seen = set()
    for device in raw_devices:
        hostname = device.get("hostName") or device.get("hostname") or device.get("name")
        if not hostname or hostname in seen:
            continue
        searchable = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()
        if target_site not in searchable:
            continue
        is_fw, combined = is_firewall_device(device)
        if is_fw:
            seen.add(hostname)
            vendor_label, cmd = guess_vendor(combined)
            firewalls.append({"hostname": hostname, "vendor": vendor_label, "cmd": cmd})

    print(f"Found {len(firewalls)} firewall(s) at site '{target_site}':")
    for fw in firewalls:
        status = fw["cmd"] if fw["cmd"] else "(no command mapped -- will list only, not query)"
        print(f"  - {fw['hostname']:35s} vendor={fw['vendor']:15s} cmd={status}")

    results = {}
    queryable = [fw for fw in firewalls if fw["cmd"]]
    skipped = [fw for fw in firewalls if not fw["cmd"]]

    if queryable:
        print(f"\nQuerying {len(queryable)} firewall(s)...")
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(get_raw_data, session, fw["hostname"], fw["cmd"]): fw
                for fw in queryable
            }
            for future in as_completed(future_map):
                fw = future_map[future]
                response = future.result()
                results[fw["hostname"]] = {
                    "vendor": fw["vendor"],
                    "cmd": fw["cmd"],
                    "response": response,
                }
                content = response.get("content", "") if isinstance(response, dict) else ""
                size = len(content) if isinstance(content, str) else 0
                print(f"  [{fw['vendor']}] {fw['hostname']}: {size} chars returned")

    for fw in skipped:
        results[fw["hostname"]] = {"vendor": fw["vendor"], "cmd": None, "response": None}

    with open("nat_probe_all_firewalls.json", "w") as f:
        json.dump(results, f, indent=2)

    print(f"\nSaved all results -> nat_probe_all_firewalls.json")
    print("\nSummary by vendor:")
    vendor_counts = {}
    for fw in firewalls:
        vendor_counts[fw["vendor"]] = vendor_counts.get(fw["vendor"], 0) + 1
    for vendor, count in sorted(vendor_counts.items()):
        print(f"  {vendor}: {count}")

    if skipped:
        print(
            f"\n{len(skipped)} firewall(s) had no mapped command and were not queried "
            f"(Check Point and unrecognized vendors) -- see the list above."
        )

    print(
        "\nBefore sharing nat_probe_all_firewalls.json: skim it for anything "
        "you'd rather redact (real internal IPs/hostnames), then paste back "
        "the response for one representative host per NEW vendor (ASA, "
        "Fortinet) so real parsers can be built the same way as Palo Alto."
    )


if __name__ == "__main__":
    main()

# CHG0199957.py — network validation with previous-run diffing (safe creds)
# + changes-only summary with regex filters to ignore counters/rates/timers

import os
import time
import json
import csv
import logging
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import glob
import difflib
import re
from typing import Optional, List, Tuple

try:
    import paramiko
except ImportError as e:
    raise SystemExit("Missing dependency 'paramiko'. Install with: pip install paramiko") from e

# ========= CONFIG =========
LOG_DIR = 'logs'
ARTIFACTS_DIR = 'artifacts'
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(ARTIFACTS_DIR, exist_ok=True)

# Per-run timestamp tag
RUN_TS = datetime.now().strftime('%Y%m%d_%H%M%S')

# Configure logging with timestamp
log_path = os.path.join(LOG_DIR, f'validation_log_{RUN_TS}.txt')
logging.basicConfig(
    filename=log_path,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
console.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().addHandler(console)

# -------- Devices & Commands --------
# Use environment variables for credentials (do NOT hard-code):
#   Global:  COR_USER / COR_PASS  (or DEVICE_USER / DEVICE_PASS)
#   Per-device override: <SANITIZED_DEVICE_NAME>_USER / <SANITIZED_DEVICE_NAME>_PASS
#   Example: export NEW_DDC1_MDFE1_COR1_USER=user ; export NEW_DDC1_MDFE1_COR1_PASS=pass

devices = {
    "NEW_DDC1-MDFE1-COR1": {"host": "NEW_DDC1-MDFE1-COR1", "username": None, "password": None},
    "NEW_DDC1-MDFE1-COR2": {"host": "NEW_DDC1-MDFE1-COR2", "username": None, "password": None},
}

# Command sets (single-line pipes; avoid embedded newlines)
commands = {
    "NEW_DDC1-MDFE1-COR1": [
        "show int e3/35 | i rate",
        "sleep 1",
        "show int e3/36 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.50.66.58 | no-more",
        "show ip bgp 10.50.66.62 | no-more",
        "show ip bgp neighbors 10.50.66.58 | no-more",
        "show ip bgp neighbors 10.50.66.62 | no-more",
        "show ip route bgp int e3/35 | no-more",
        "show ip route bgp int e3/36 | no-more",
        "show ip route | no-more",
        "show int e3/28 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.255.132.137 | no-more",
        "show ip bgp neighbors 10.255.132.137 | no-more",
        "show ip route bgp int e3/28 | no-more",
        "show ip route | no-more",
        # additional repeated verification
        "show int e3/28 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.255.132.137 | no-more",
        "show ip bgp neighbors 10.255.132.137 | no-more",
        "show ip route bgp int e3/28 | no-more",
        "show ip route | no-more",
    ],
    "NEW_DDC1-MDFE1-COR2": [
        "show int e3/35 | i rate",
        "sleep 1",
        "show int e3/36 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.50.66.66 | no-more",
        "show ip bgp 10.50.66.70 | no-more",
        "show ip bgp neighbors 10.50.66.66 | no-more",
        "show ip bgp neighbors 10.50.66.70 | no-more",
        "show ip route bgp int e3/35 | no-more",
        "show ip route bgp int e3/36 | no-more",
        "show ip route | no-more",
        "show int e3/28 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.255.132.117 | no-more",
        "show ip bgp neighbors 10.255.132.117 | no-more",
        "show ip route bgp int e3/28 | no-more",
        "show ip route | no-more",
        # additional repeated verification
        "show int e3/28 | i rate",
        "sleep 1",
        "show ip bgp sum | no-more",
        "show ip bgp 10.255.132.117 | no-more",
        "show ip bgp neighbors 10.255.132.117 | no-more",
        "show ip route bgp int e3/28 | no-more",
        "show ip route | no-more",
    ],
}

# ========= HELPERS =========

def _env_key(name: str) -> str:
    """Sanitize device name to an ENV key (alnum + '_')."""
    return re.sub(r'[^A-Za-z0-9_]', '_', name)

def safe_str(s: str) -> str:
    return (s or "").replace('\r', '').replace('\x1b', '')

def connect_ssh(host, username, password, port=22, timeout=15, banner_timeout=10):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=host,
        port=port,
        username=username,
        password=password,
        timeout=timeout,
        banner_timeout=banner_timeout,
        allow_agent=False,
        look_for_keys=False,
    )
    return client

def run_exec(client: paramiko.SSHClient, cmd: str, read_timeout: float = 30.0):
    """Run a single command via exec_command with a read timeout."""
    start = time.time()
    stdin, stdout, stderr = client.exec_command(cmd, timeout=read_timeout)
    stdout.channel.settimeout(read_timeout)
    stderr.channel.settimeout(read_timeout)

    out = ""
    err = ""
    try:
        out = stdout.read().decode(errors='replace')
    except Exception as e:
        err += f"\n[stdout timeout/read error: {e}]"
    try:
        err += stderr.read().decode(errors='replace')
    except Exception as e:
        err += f"\n[stderr timeout/read error: {e}]"
    try:
        exit_status = stdout.channel.recv_exit_status()
    except Exception:
        exit_status = -1

    elapsed = time.time() - start
    return exit_status, safe_str(out), safe_str(err), elapsed

def _resolve_credentials(device_name: str, device_info: dict) -> Tuple[Optional[str], Optional[str]]:
    """Resolve credentials from device_info or environment variables."""
    env_prefix = _env_key(device_name)
    username = (
        device_info.get('username')
        or os.getenv(f'{env_prefix}_USER')
        or os.getenv('COR_USER')
        or os.getenv('DEVICE_USER')
    )
    password = (
        device_info.get('password')
        or os.getenv(f'{env_prefix}_PASS')
        or os.getenv('COR_PASS')
        or os.getenv('DEVICE_PASS')
    )
    return username, password

def execute_commands(device_name: str, device_info: dict, command_list: list, max_retries: int = 2):
    host = device_info['host']
    username, password = _resolve_credentials(device_name, device_info)
    port = device_info.get('port', 22)

    if not username or not password or username == 'REPLACE_ME' or password == 'REPLACE_ME':
        msg = (
            f"[{device_name}] Missing credentials (set env COR_USER/COR_PASS or DEVICE_USER/DEVICE_PASS, "
            f"or {_env_key(device_name)}_USER/{_env_key(device_name)}_PASS)."
        )
        logging.error(msg)
        return {"device": device_name, "host": host, "status": "failed", "reason": msg, "results": []}

    logging.info(f"Connecting to {device_name} ({host})")
    attempt = 0
    client = None
    last_exc = None

    while attempt <= max_retries:
        try:
            client = connect_ssh(host, username, password, port=port)
            break
        except Exception as e:
            last_exc = e
            attempt += 1
            logging.warning(f"[{device_name}] Connect attempt {attempt} failed: {e}")
            time.sleep(min(2 ** attempt, 10))

    if client is None:
        reason = f"Failed to connect to {device_name}: {last_exc}"
        logging.error(reason)
        return {"device": device_name, "host": host, "status": "failed", "reason": str(last_exc), "results": []}

    per_device_artifact = os.path.join(ARTIFACTS_DIR, f"{device_name}_{RUN_TS}.txt")
    results_csv = os.path.join(ARTIFACTS_DIR, f"{device_name}_{RUN_TS}.csv")
    results_rows = []

    try:
        with open(per_device_artifact, 'w', encoding='utf-8') as outf:
            outf.write(f"==== Device: {device_name} ({host}) Run: {RUN_TS} ====\n")
            for cmd in command_list:
                if cmd.startswith('sleep'):
                    try:
                        delay = int(cmd.split()[1])
                    except Exception:
                        delay = 1
                    logging.info(f"[{device_name}] Sleeping for {delay} seconds")
                    time.sleep(delay)
                    continue

                ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                logging.info(f"[{device_name}] [{ts}] Executing: {cmd}")
                exit_status, out, err, elapsed = run_exec(client, cmd, read_timeout=60.0)

                if out.strip():
                    logging.info(f"[{device_name}] Output ({len(out)} bytes)")
                if err.strip():
                    logging.error(f"[{device_name}] Error: {err.strip()}")

                outf.write(f"\n--- {ts} :: {cmd} ---\n")
                if out:
                    outf.write(out if out.endswith('\n') else out + '\n')
                if err:
                    outf.write(f"[stderr] {err if err.endswith('\n') else err + '\n'}")

                results_rows.append({
                    "timestamp": ts,
                    "device": device_name,
                    "host": host,
                    "command": cmd,
                    "exit_status": exit_status,
                    "duration_ms": int(elapsed * 1000),
                    "stdout_bytes": len(out),
                    "stderr_bytes": len(err)
                })
    finally:
        try:
            client.close()
        except Exception:
            pass
        logging.info(f"Disconnected from {device_name}")

    fieldnames = ["timestamp", "device", "host", "command", "exit_status", "duration_ms", "stdout_bytes", "stderr_bytes"]
    with open(results_csv, 'w', newline='', encoding='utf-8') as fcsv:
        writer = csv.DictWriter(fcsv, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results_rows)

    return {"device": device_name, "host": host, "status": "ok", "results_file": per_device_artifact, "csv": results_csv}

def run_all(devices: dict, commands: dict, max_workers: int = 4):
    futures = []
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        for device_name, device_info in devices.items():
            cmd_list = commands.get(device_name, [])
            futures.append(pool.submit(execute_commands, device_name, device_info, cmd_list))
        for fut in as_completed(futures):
            try:
                res = fut.result()
            except Exception as e:
                res = {"device": "unknown", "status": "failed", "reason": str(e), "results": []}
            results.append(res)

    summary_path = os.path.join(ARTIFACTS_DIR, f"run_summary_{RUN_TS}.json")
    with open(summary_path, 'w', encoding='utf-8') as js:
        json.dump(results, js, indent=2)
    logging.info(f"Run summary written to {summary_path}")
    return results

# ========= DIFF HELPERS (previous run comparison) =========

def _extract_run_ts_from_artifact(path: str) -> Optional[str]:
    """Extract run timestamp (YYYYMMDD_HHMMSS) from artifact filename '<device>_<RUN_TS>.txt'"""
    m = re.search(r'_(\d{8}_\d{6})\.txt$', os.path.basename(path))
    return m.group(1) if m else None
def _preprocess_lines_for_diff(text: str) -> List[str]:
    """Normalize volatile values (timestamps, run tags) to reduce noisy diffs; then splitlines."""
    text = re.sub(r'\b\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\b', '<TS>', text)
    text = re.sub(r'\b\d{8}_\d{6}\b', '<RUN_TS>', text)
    text = text.replace('\r', '')
    return text.splitlines()

def _find_previous_artifact(device: str, current_artifact: str, artifacts_dir: str, current_run_ts: str
                           ) -> Tuple[Optional[str], Optional[str]]:
    """Among '<device>_*.txt' in artifacts_dir, pick the most recent file older than current_run_ts."""
    pattern = os.path.join(artifacts_dir, f"{device}_*.txt")
    candidates = []
    for path in glob.glob(pattern):
        ts = _extract_run_ts_from_artifact(path)
        if ts and ts < current_run_ts and os.path.abspath(path) != os.path.abspath(current_artifact):
            candidates.append((ts, path))
    if not candidates:
        return None, None
    candidates.sort(key=lambda x: x[0])  # latest older
    prev_ts, prev_path = candidates[-1]
    return prev_path, prev_ts

# -- NEW: changes-only filter and ignore rules --

def _filter_changes_only(diff_lines: List[str]) -> List[str]:
    """Keep only actual change lines ('+' or '-') from a unified diff, excluding headers/hunks."""
    changes = []
    for ln in diff_lines:
        if not ln:
            continue
        if ln.startswith('+++') or ln.startswith('---') or ln.startswith('@@'):
            continue
        if ln[0] in ('+', '-'):
            changes.append(ln)
    return changes

# Default ignore regexes (counters/rates/timers etc.)
IGNORE_REGEXES_DEFAULT = [
    # Interface rates / counters
    r'\b(input|output)\s+rate\b',
    r'\b(?:rx|tx)[-_ ]?(?:rate|bytes|pkts|packets|drops|errors)\b',
    r'\b\d+\s+(?:packets|pkts|bytes|bits)\b',
    r'\b(?:bits|bytes|packets)/(?:sec|s)\b',
    r'\b\d+\s+(?:drop|drops|error|errors)\b',
    r'\b(?:crc|frame|overrun|underrun|ignored|abort|collisions)\b.*\d+',
    r'\b5\s*minute\b',
    r'\breliability\b',
    r'\brxload\b|\btxload\b',
    r'\bload-interval\b',
    r'\bqueue\b.*\b(depth|drops|taildrop|threshold)\b.*\d+',
    r'\blast clearing of.*counters\b',

    # BGP/neighbor counters & volatile timers
    r'\b(Received|Sent)\s+\d+\s+(?:messages|updates|notifications)\b',
    r'\bBytes\s+(?:in|out)\b',
    r'\bLast\s+(?:read|write)\b',
    r'\bHold\s*timer\b|\bKeep-?alive\b',
    r'\bEstablished\s+\d{2}:\d{2}:\d{2}\b',

    # Generic monotonic counters/timestamps
    r'\buptime\b|\bup\s+\d+\s+(?:day|days
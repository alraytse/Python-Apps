import csv
import getpass
import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

USERNAME = input("Enter NetBrain Username: ").strip()
PASSWORD = getpass.getpass("Enter NetBrain Password: ").strip()

if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
OUTPUT_FILE = os.path.expanduser("~/Downloads/ddc1_network_inventory.csv")

MAX_WORKERS = 10
PAGE_LIMIT = 100
MAX_ESTIMATED_PAGES = 100

session = requests.Session()
session.verify = False
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


def authenticate() -> dict:
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    res = session.post(login_url, json=login_payload, timeout=15)
    if res.status_code != 200:
        raise RuntimeError(f"Auth failed ({res.status_code}): {res.text}")

    data = res.json()
    token = data.get("token")
    if not token:
        raise RuntimeError("Token missing in response payload.")

    session.headers.update(
        {
            "Token": token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
    )

    if data.get("tenantId") and data.get("domainId"):
        session.headers.update(
            {"tenantId": data.get("tenantId"), "domainId": data.get("domainId")}
        )

    return data


def fetch_device_page(skip_value: int) -> list:
    url = f"{BASE_URL}/CMDB/Devices"
    try:
        res = session.get(
            url, params={"skip": skip_value, "limit": PAGE_LIMIT}, timeout=30
        )
        return res.json().get("devices", []) if res.status_code == 200 else []
    except requests.RequestException:
        return []


def extract_interface_type(intf_name: str) -> str:
    if not intf_name:
        return ""
    match = re.match(r"^([a-zA-Z-]+)", str(intf_name).strip())
    if match:
        prefix = match.group(1).rstrip("-")
        if len(prefix) >= 2:
            return prefix
    return ""


def extract_site_from_device(device: dict) -> str:
    for key in ["siteName", "site", "sitePath", "location", "site_name"]:
        val = device.get(key)
        if val and isinstance(val, str) and val.strip():
            return val.strip()

    hostname = device.get("name") or device.get("hostName") or device.get("hostname") or ""
    if hostname:
        parts = hostname.split("-")
        if parts:
            return parts[0].strip()

    return "DDC1"


def fetch_single_interface_attr(hostname: str, intf_name: str) -> tuple:
    url = f"{BASE_URL}/CMDB/Interfaces/Attributes"
    try:
        r = session.get(url, params={"hostname": hostname, "interfaceName": intf_name}, timeout=10)
        if r.status_code == 200:
            attrs = r.json().get("attributes", {}).get(intf_name, {})

            # Extract VRF
            vrf = attrs.get("mplsVrf", "").strip()

            # Extract description
            description = (
                attrs.get("description")
                or attrs.get("descr")
                or attrs.get("ifDescr")
                or attrs.get("interfaceDescription")
                or ""
            )
            if isinstance(description, str):
                description = description.strip()
            else:
                description = ""

            # Check NAT & PAT attributes
            nat_val = (
                attrs.get("isNatIntf")
                or attrs.get("natType")
                or attrs.get("nat")
                or attrs.get("natMode")
            )
            pat_val = (
                attrs.get("isPatIntf")
                or attrs.get("patType")
                or attrs.get("pat")
                or attrs.get("patMode")
            )

            # Extract IPs
            found_ips = []
            ips_raw = attrs.get("ips")
            if isinstance(ips_raw, list):
                for item in ips_raw:
                    if isinstance(item, dict) and item.get("ipLoc"):
                        found_ips.append(item["ipLoc"])
                    elif isinstance(item, str) and item.strip():
                        found_ips.append(item.strip())
            elif isinstance(ips_raw, str) and ips_raw.strip():
                found_ips.append(ips_raw.strip())

            has_nat = bool(nat_val and str(nat_val).lower() not in ["false", "0", "disabled", "no", ""])
            has_pat = bool(pat_val and str(pat_val).lower() not in ["false", "0", "disabled", "no", ""])

            return vrf, found_ips, has_nat, has_pat, description
    except requests.RequestException:
        pass
    return "", [], False, False, ""


def enrich_device_metadata(hostname: str) -> tuple:
    types, vrfs, ip_addrs = set(), set(), set()
    nat_interfaces, pat_interfaces = set(), set()
    intf_descriptions = {}

    if not hostname:
        return ["N/A"], ["default"], ["N/A"], "No", "No", "N/A"

    url = f"{BASE_URL}/CMDB/Interfaces"
    try:
        r = session.get(url, params={"hostname": hostname}, timeout=15)
        if r.status_code == 200:
            intf_names = r.json().get("interfaces", [])

            for intf in intf_names:
                if_type = extract_interface_type(intf)
                if if_type:
                    types.add(if_type)

            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = {
                    executor.submit(fetch_single_interface_attr, hostname, intf): intf
                    for intf in intf_names
                }
                for future in as_completed(futures):
                    intf_name = futures[future]
                    vrf, ips, has_nat, has_pat, description = future.result()

                    if vrf and vrf.lower() not in ["none", "null", "undefined", "n/a", "0"]:
                        vrfs.add(vrf)
                    for ip in ips:
                        ip_addrs.add(ip)
                    if has_nat:
                        nat_interfaces.add(intf_name)
                    if has_pat:
                        pat_interfaces.add(intf_name)
                    if description:
                        intf_descriptions[intf_name] = description

    except requests.RequestException:
        pass

    valid_vrfs = sorted(list(vrfs)) if vrfs else ["default"]
    nat_summary = "\n".join(sorted(nat_interfaces)) if nat_interfaces else "No"
    pat_summary = "\n".join(sorted(pat_interfaces)) if pat_interfaces else "No"
    description_summary = (
        "\n".join(f"{intf}: {desc}" for intf, desc in sorted(intf_descriptions.items()))
        if intf_descriptions
        else "N/A"
    )

    return list(types), valid_vrfs, list(ip_addrs), nat_summary, pat_summary, description_summary


def main():
    authenticate()

    all_ddc1_devices = []
    seen_hostnames = set()
    all_discovered_columns = {
        "requestedSite",
        "interfaceTypes",
        "vrfNames",
        "interfaceIPs",
        "interfaceDescriptions",
        "hasNAT",
        "hasPAT",
    }
    skip_offsets = [i * PAGE_LIMIT for i in range(MAX_ESTIMATED_PAGES)]
    EXCLUDED_FIELDS = {
        "hostName",
        "hostname",
        "mgmtIP",
        "dnsName",
        "dns",
        "primaryDns",
        "secondaryDns",
        "dnsServer",
    }

    print(f"Fetching global CMDB devices ({MAX_WORKERS} workers)...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(fetch_device_page, skip): skip
            for skip in skip_offsets
        }

        for future in as_completed(futures):
            devices_batch = future.result()
            for device in devices_batch:
                hostname = (
                    device.get("hostName")
                    or device.get("hostname")
                    or device.get("name")
                )

                if hostname and hostname not in seen_hostnames:
                    searchable_fields = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()

                    if "DDC1" in searchable_fields:
                        seen_hostnames.add(hostname)
                        flat_device = {"_raw_device": device}
                        flat_device["requestedSite"] = extract_site_from_device(device)

                        for k, v in device.items():
                            if k in EXCLUDED_FIELDS or any(
                                ex in k.lower() for ex in ["id", "discovery", "time", "dns"]
                            ):
                                continue
                            if k == "attributes" and isinstance(v, dict):
                                for sub_k, sub_v in v.items():
                                    if sub_k not in EXCLUDED_FIELDS and not any(
                                        ex in sub_k.lower() for ex in ["id", "discovery", "time", "dns"]
                                    ):
                                        flat_device[f"attr_{sub_k}"] = sub_v
                            else:
                                flat_device[k] = v

                        all_discovered_columns.update(
                            k for k in flat_device if not k.startswith("_")
                        )
                        all_ddc1_devices.append(flat_device)

    print(f"Found {len(all_ddc1_devices)} DDC1 assets. Enriching metadata...")

    if all_ddc1_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(
                    enrich_device_metadata,
                    dev.get("name") or dev.get("hostName") or dev.get("hostname")
                ): dev
                for dev in all_ddc1_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    types, vrfs, ips, nat_res, pat_res, desc_res = future.result()
                    dev["interfaceTypes"] = "\n".join(sorted(types)) if types else "N/A"
                    dev["vrfNames"] = "\n".join(vrfs)
                    dev["interfaceIPs"] = "\n".join(sorted(ips)) if ips else "N/A"
                    dev["hasNAT"] = nat_res
                    dev["hasPAT"] = pat_res
                    dev["interfaceDescriptions"] = desc_res
                except Exception:
                    dev["interfaceTypes"] = "N/A"
                    dev["vrfNames"] = "default"
                    dev["interfaceIPs"] = "N/A"
                    dev["hasNAT"] = "No"
                    dev["hasPAT"] = "No"
                    dev["interfaceDescriptions"] = "N/A"
                finally:
                    dev.pop("_raw_device", None)

    if not all_ddc1_devices:
        all_ddc1_devices.append(
            {
                "name": "No Matching DDC1 Assets Discovered",
                "requestedSite": "DDC1",
                "interfaceIPs": "N/A",
                "interfaceTypes": "N/A",
                "vrfNames": "default",
                "hasNAT": "No",
                "hasPAT": "No",
                "interfaceDescriptions": "N/A",
            }
        )

    primary_headers = [
        "name",
        "requestedSite",
        "interfaceIPs",
        "interfaceTypes",
        "interfaceDescriptions",
        "vrfNames",
        "hasNAT",
        "hasPAT",
    ]
    extra_headers = sorted(
        [
            col
            for col in all_discovered_columns
            if col not in primary_headers
            and col not in EXCLUDED_FIELDS
            and "dns" not in col.lower()
        ]
    )
    ordered_headers = primary_headers + extra_headers

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=ordered_headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(all_ddc1_devices)

    print(f"Export successful: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
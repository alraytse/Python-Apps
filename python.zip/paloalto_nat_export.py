#!/usr/bin/env python3
"""
paloalto_nat_export.py

Queries Palo Alto firewalls directly via their native XML API (bypassing
NetBrain entirely) to pull live NAT policy rules for every vsys, and
writes the results to a CSV file.

SECURITY NOTE:
Credentials are entered interactively at runtime (password hidden via
getpass) and are never hardcoded or logged to disk. If you already have
an API key issued, you can pass it directly with --api-key instead of
generating one from username/password.

Usage examples:
    # Pull firewall list from a previous NetBrain export CSV, generate
    # an API key from username/password, query all vsys on each box:
    python3 paloalto_nat_export.py --from-netbrain-csv nat_export.csv

    # Specify firewalls explicitly:
    python3 paloalto_nat_export.py --firewalls 10.7.30.161,10.7.30.162

    # Use an existing API key instead of generating one:
    python3 paloalto_nat_export.py --firewalls 10.7.30.161 --api-key abcdef123...

Requirements:
    pip install requests --break-system-packages
"""

import argparse
import csv
import getpass
import re
import sys
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

MAX_WORKERS = 5   # keep conservative -- these are live queries against production firewalls


def api_get(host, params, verify_ssl, timeout=30):
    """Low-level GET against a PAN-OS firewall's XML API."""
    url = f"https://{host}/api/"
    resp = requests.get(url, params=params, verify=verify_ssl, timeout=timeout)
    resp.raise_for_status()
    return resp.text


def generate_api_key(host, username, password, verify_ssl):
    """Exchange username/password for an API key."""
    xml_text = api_get(host, {"type": "keygen", "user": username, "password": password}, verify_ssl)
    root = ET.fromstring(xml_text)
    if root.get("status") != "success":
        msg = root.findtext(".//msg") or xml_text[:300]
        raise RuntimeError(f"keygen failed: {msg}")
    key = root.findtext(".//key")
    if not key:
        raise RuntimeError(f"keygen response had no key: {xml_text[:300]}")
    return key


def get_ha_state(host, key, verify_ssl):
    """Return 'active', 'passive', 'standalone', or 'unknown'."""
    cmd = "<show><high-availability><state></state></high-availability></show>"
    try:
        xml_text = api_get(host, {"type": "op", "cmd": cmd, "key": key}, verify_ssl)
        root = ET.fromstring(xml_text)
        enabled = root.findtext(".//enabled")
        if enabled is not None and enabled.strip().lower() == "no":
            return "standalone"
        state = (
            root.findtext(".//group/local-info/state")
            or root.findtext(".//local-info/state")
        )
        return state or "unknown"
    except Exception:
        return "unknown"


def get_vsys_list(host, key, verify_ssl, debug=False):
    """
    Return list of vsys names configured on the firewall, e.g. ['vsys1','vsys2'].
    Falls back to ['vsys1'] if the query fails (e.g. multi-vsys not licensed,
    single-vsys mode still uses the vsys1 xpath internally on PAN-OS).
    """
    xpath = "/config/devices/entry/vsys/entry"
    try:
        xml_text = api_get(
            host, {"type": "config", "action": "get", "xpath": xpath, "key": key}, verify_ssl
        )
        if debug:
            print(f"[DEBUG] {host} vsys query raw: {xml_text[:500]}")
        root = ET.fromstring(xml_text)
        if root.get("status") != "success":
            return ["vsys1"]
        names = [e.get("name") for e in root.findall(".//result/entry") if e.get("name")]
        return names or ["vsys1"]
    except Exception as e:
        if debug:
            print(f"[DEBUG] {host} vsys query failed ({e}), defaulting to vsys1")
        return ["vsys1"]


def get_nat_rules_xml(host, key, vsys, verify_ssl):
    """Fetch the raw NAT rulebase XML for a given vsys."""
    xpath = f"/config/devices/entry/vsys/entry[@name='{vsys}']/rulebase/nat/rules"
    return api_get(host, {"type": "config", "action": "get", "xpath": xpath, "key": key}, verify_ssl)


def _member_text(entry, tag):
    """Join all <member> children of a tag into a single ';'-separated string."""
    node = entry.find(tag)
    if node is None:
        return ""
    members = [m.text for m in node.findall("member") if m.text]
    if members:
        return ";".join(members)
    return node.text or ""


def _translation_summary(entry, tag):
    """
    Summarize a <source-translation> or <destination-translation> block into
    (type, detail) strings. PAN-OS supports several translation types
    (static-ip, dynamic-ip, dynamic-ip-and-port, translated-address, etc.)
    so this covers the common ones and falls back to raw XML text otherwise.
    """
    node = entry.find(tag)
    if node is None:
        return "", ""

    for child in list(node):
        ttype = child.tag
        parts = []
        addr = child.find("translated-address")
        if addr is not None:
            members = [m.text for m in addr.findall("member") if m.text]
            parts.append(";".join(members) if members else (addr.text or ""))
        iface = child.findtext("interface")
        if iface:
            parts.append(f"interface={iface}")
        port = child.findtext("translated-port")
        if port:
            parts.append(f"port={port}")
        if child.tag == "static-ip":
            plain_addr = child.findtext("translated-address")
            if plain_addr:
                parts = [plain_addr]
        detail = ", ".join(p for p in parts if p)
        return ttype, detail

    # No recognized sub-element; fall back to a flat dump
    return "unknown", ET.tostring(node, encoding="unicode").strip()


def parse_nat_rules(xml_text):
    """Parse a NAT rulebase XML response into a list of rule dicts."""
    rules = []
    root = ET.fromstring(xml_text)
    if root.get("status") != "success":
        return rules

    for entry in root.findall(".//result/rules/entry"):
        src_type, src_detail = _translation_summary(entry, "source-translation")
        dst_type, dst_detail = _translation_summary(entry, "destination-translation")

        rules.append({
            "rule_name": entry.get("name", ""),
            "disabled": entry.findtext("disabled") or "no",
            "tags": _member_text(entry, "tag"),
            "from_zone": _member_text(entry, "from"),
            "to_zone": _member_text(entry, "to"),
            "to_interface": entry.findtext("to-interface") or "",
            "source": _member_text(entry, "source"),
            "destination": _member_text(entry, "destination"),
            "service": entry.findtext("service") or "",
            "source_translation_type": src_type,
            "source_translation_detail": src_detail,
            "destination_translation_type": dst_type,
            "destination_translation_detail": dst_detail,
            "raw_xml": ET.tostring(entry, encoding="unicode").strip(),
        })
    return rules


def load_firewalls_from_netbrain_csv(path):
    """
    Read a previous NetBrain export CSV and return a deduped list of
    (base_hostname, mgmt_ip) for entries that look like firewalls,
    collapsing '.../vsysN' sub-entries down to their parent device.
    """
    seen = {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            hostname = row.get("hostname", "")
            mgmt_ip = row.get("mgmt_ip", "")
            if not hostname or not mgmt_ip:
                continue
            if "fw" not in hostname.lower():
                continue
            base_hostname = re.sub(r"/vsys\d+$", "", hostname, flags=re.IGNORECASE)
            seen[mgmt_ip] = base_hostname
    return [(name, ip) for ip, name in seen.items()]


def process_firewall(name, host, username, password, api_key, verify_ssl, debug):
    """Full pipeline for one firewall: key, HA state, vsys list, NAT rules."""
    rows = []
    try:
        key = api_key or generate_api_key(host, username, password, verify_ssl)
    except Exception as e:
        return [{
            "firewall": name, "mgmt_ip": host, "ha_state": "", "vsys": "",
            "rule_name": "", "disabled": "", "tags": "", "from_zone": "", "to_zone": "",
            "to_interface": "", "source": "", "destination": "", "service": "",
            "source_translation_type": "", "source_translation_detail": "",
            "destination_translation_type": "", "destination_translation_detail": "",
            "raw_xml": "", "error": f"API key error: {e}",
        }]

    ha_state = get_ha_state(host, key, verify_ssl)
    vsys_list = get_vsys_list(host, key, verify_ssl, debug=debug)

    for vsys in vsys_list:
        try:
            xml_text = get_nat_rules_xml(host, key, vsys, verify_ssl)
            if debug:
                print(f"[DEBUG] {name} {vsys} raw response (first 500 chars): {xml_text[:500]}")
            parsed = parse_nat_rules(xml_text)
            if not parsed:
                rows.append({
                    "firewall": name, "mgmt_ip": host, "ha_state": ha_state, "vsys": vsys,
                    "rule_name": "", "disabled": "", "tags": "", "from_zone": "", "to_zone": "",
                    "to_interface": "", "source": "", "destination": "", "service": "",
                    "source_translation_type": "", "source_translation_detail": "",
                    "destination_translation_type": "", "destination_translation_detail": "",
                    "raw_xml": "", "error": "no NAT rules found (or query failed)",
                })
            for r in parsed:
                r["firewall"] = name
                r["mgmt_ip"] = host
                r["ha_state"] = ha_state
                r["vsys"] = vsys
                r["error"] = ""
                rows.append(r)
        except Exception as e:
            rows.append({
                "firewall": name, "mgmt_ip": host, "ha_state": ha_state, "vsys": vsys,
                "rule_name": "", "disabled": "", "tags": "", "from_zone": "", "to_zone": "",
                "to_interface": "", "source": "", "destination": "", "service": "",
                "source_translation_type": "", "source_translation_detail": "",
                "destination_translation_type": "", "destination_translation_detail": "",
                "raw_xml": "", "error": f"NAT rule query error: {e}",
            })
    return rows


def main():
    parser = argparse.ArgumentParser(description="Export NAT policy from Palo Alto firewalls to CSV")
    parser.add_argument("--from-netbrain-csv", default=None,
                         help="Load firewall list from a previous NetBrain export CSV (dedupes vsys sub-entries)")
    parser.add_argument("--firewalls", default=None,
                         help="Comma-separated list of firewall hostnames/IPs to query directly")
    parser.add_argument("--api-key", default=None,
                         help="Use an existing PAN-OS API key instead of generating one from username/password")
    parser.add_argument("--output", default="paloalto_nat_export.csv", help="Output CSV filename")
    parser.add_argument("--insecure", action="store_true",
                         help="Skip SSL certificate verification (firewalls commonly use self-signed certs)")
    parser.add_argument("--debug", action="store_true", help="Print raw API responses for troubleshooting")
    args = parser.parse_args()

    firewalls = []
    if args.from_netbrain_csv:
        firewalls = load_firewalls_from_netbrain_csv(args.from_netbrain_csv)
        print(f"Loaded {len(firewalls)} firewall(s) from {args.from_netbrain_csv}:")
        for name, ip in firewalls:
            print(f"  {name}  ({ip})")
    elif args.firewalls:
        for item in args.firewalls.split(","):
            item = item.strip()
            if item:
                firewalls.append((item, item))
    else:
        raw = input("Firewall hostnames/IPs (comma-separated): ").strip()
        for item in raw.split(","):
            item = item.strip()
            if item:
                firewalls.append((item, item))

    if not firewalls:
        print("No firewalls to query.")
        sys.exit(1)

    verify_ssl = not args.insecure

    username = None
    password = None
    if not args.api_key:
        username = input("Firewall admin username: ").strip()
        password = getpass.getpass("Firewall admin password: ")
        print("(Same credentials will be used for all listed firewalls.)")

    all_rows = []
    print(f"\nQuerying {len(firewalls)} firewall(s) using {MAX_WORKERS} worker thread(s) ...")
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(process_firewall, name, ip, username, password, args.api_key, verify_ssl, args.debug): name
            for name, ip in firewalls
        }
        completed = 0
        for future in as_completed(futures):
            name = futures[future]
            try:
                rows = future.result()
            except Exception as e:
                rows = [{"firewall": name, "mgmt_ip": "", "ha_state": "", "vsys": "",
                         "rule_name": "", "disabled": "", "tags": "", "from_zone": "", "to_zone": "",
                         "to_interface": "", "source": "", "destination": "", "service": "",
                         "source_translation_type": "", "source_translation_detail": "",
                         "destination_translation_type": "", "destination_translation_detail": "",
                         "raw_xml": "", "error": f"Unexpected error: {e}"}]
            all_rows.extend(rows)
            completed += 1
            print(f"  [{completed}/{len(firewalls)}] {name} done ({len(rows)} row(s))")

    fieldnames = [
        "firewall", "mgmt_ip", "ha_state", "vsys", "rule_name", "disabled", "tags",
        "from_zone", "to_zone", "to_interface", "source", "destination", "service",
        "source_translation_type", "source_translation_detail",
        "destination_translation_type", "destination_translation_detail",
        "raw_xml", "error",
    ]
    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"\nDone. Wrote {len(all_rows)} row(s) to {args.output}")


if __name__ == "__main__":
    main()

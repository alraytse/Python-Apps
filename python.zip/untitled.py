#!/usr/bin/env python3

import csv
import getpass
import re
from netmiko import ConnectHandler

INVENTORY_FILE = "network_inventory_report.csv"
NAT_RULES_FILE = "configured_nat_rules.csv"
NAT_INVENTORY_FILE = "nat_inventory_report.csv"

COMMANDS = [
    "show ip interface brief",
    "show ip nat translations",
    "show ip nat statistics",
    "show access-lists Viptela-Underlay-NAT",
    "show interfaces tunnel",
    "show sdwan vpn"
]

NAT_CONFIG_COMMANDS = [
    "show running-config | include ip nat",
    "show running-config | section ip nat",
    "show running-config | include overload",
    "show access-lists Viptela-Underlay-NAT"
]

NAT_RULE_FIELDS = [
    "Device",
    "Platform",
    "Rule_Type",
    "Source",
    "Translated_Source",
    "Destination",
    "Translated_Destination",
    "Protocol",
    "Original_Port",
    "Translated_Port",
    "Interface",
    "Command",
    "Details"
]

NAT_INVENTORY_FIELDS = [
    "Device",
    "Platform",
    "Public_IP",
    "Private_IP",
    "NAT_Type",
    "NAT_ACL",
    "Outside_Interface",
    "Protocol",
    "Primary_External_Destination",
    "Active_Internal_Hosts",
    "Hits",
    "Misses",
    "Expired_Translations"
]


def run_command(conn, command):
    try:
        return conn.send_command(
            command,
            read_timeout=120
        )
    except Exception:
        return ""


def connect_device(host, username, password):

    device_types = [
        "cisco_nxos",
        "cisco_ios",
        "cisco_asa"
    ]

    for device_type in device_types:

        try:

            connection = ConnectHandler(
                device_type=device_type,
                host=host,
                username=username,
                password=password,
                fast_cli=False,
            )

            return connection, device_type

        except Exception:
            continue

    return None, None


def parse_nat_rule(line):

    row = {
        "Rule_Type": "NAT",
        "Source": "",
        "Translated_Source": "",
        "Destination": "",
        "Translated_Destination": "",
        "Protocol": "",
        "Original_Port": "",
        "Translated_Port": "",
        "Interface": ""
    }

    lower = line.lower()

    if "overload" in lower:
        row["Rule_Type"] = "PAT"

    proto_match = re.search(
        r"\b(tcp|udp|icmp)\b",
        line,
        re.IGNORECASE
    )

    if proto_match:
        row["Protocol"] = proto_match.group(1).upper()

    ips = re.findall(
        r"(?:\d{1,3}\.){3}\d{1,3}",
        line
    )

    if len(ips) >= 1:
        row["Source"] = ips[0]

    if len(ips) >= 2:
        row["Translated_Source"] = ips[1]

    interface_match = re.search(
        r"interface\s+(\S+)",
        line,
        re.IGNORECASE
    )

    if interface_match:
        row["Interface"] = interface_match.group(1)

    return row


def collect_nat_rules(conn, hostname, platform):

    results = []

    for command in NAT_CONFIG_COMMANDS:

        output = run_command(
            conn,
            command
        )

        if not output:
            continue

        for line in output.splitlines():

            line = line.strip()

            if not line:
                continue

            parsed = parse_nat_rule(line)

            results.append({
                "Device": hostname,
                "Platform": platform,
                "Rule_Type": parsed["Rule_Type"],
                "Source": parsed["Source"],
                "Translated_Source": parsed["Translated_Source"],
                "Destination": parsed["Destination"],
                "Translated_Destination": parsed["Translated_Destination"],
                "Protocol": parsed["Protocol"],
                "Original_Port": parsed["Original_Port"],
                "Translated_Port": parsed["Translated_Port"],
                "Interface": parsed["Interface"],
                "Command": command,
                "Details": line
            })

    if not results:

        results.append({
            "Device": hostname,
            "Platform": platform,
            "Rule_Type": "NONE",
            "Source": "",
            "Translated_Source": "",
            "Destination": "",
            "Translated_Destination": "",
            "Protocol": "",
            "Original_Port": "",
            "Translated_Port": "",
            "Interface": "",
            "Command": "",
            "Details": "No configured NAT/PAT rules found"
        })

    return results


def collect_nat_inventory(conn, hostname, platform):

    inventory = {}

    translations = run_command(
        conn,
        "show ip nat translations"
    )

    statistics = run_command(
        conn,
        "show ip nat statistics"
    )

    hits = ""
    misses = ""
    expired = ""
    nat_acl = ""
    outside_interface = ""

    if statistics:

        hit_match = re.search(
            r"Hits:\s*(\d+)\s+Misses:\s*(\d+)",
            statistics
        )

        if hit_match:
            hits = hit_match.group(1)
            misses = hit_match.group(2)

        exp_match = re.search(
            r"Expired translations:\s*(\d+)",
            statistics
        )

        if exp_match:
            expired = exp_match.group(1)

        acl_match = re.search(
            r"access-list\s+(\S+)\s+interface\s+(\S+)",
            statistics,
            re.IGNORECASE
        )

        if acl_match:
            nat_acl = acl_match.group(1)
            outside_interface = acl_match.group(2)

    pattern = re.compile(
        r"^(icmp|tcp|udp)\s+"
        r"(\S+)\s+"
        r"(\S+)\s+"
        r"(\S+)\s+"
        r"(\S+)",
        re.IGNORECASE
    )

    if translations:

        for line in translations.splitlines():

            line = line.strip()

            match = pattern.match(line)

            if not match:
                continue

            protocol = match.group(1).upper()

            public_ip = match.group(2).split(":")[0]
            private_ip = match.group(3).split(":")[0]
            outside_ip = match.group(4).split(":")[0]

            key = (
                hostname,
                public_ip,
                private_ip
            )

            inventory[key] = {
                "Device": hostname,
                "Platform": platform,
                "Public_IP": public_ip,
                "Private_IP": private_ip,
                "NAT_Type": "PAT",
                "NAT_ACL": nat_acl,
                "Outside_Interface": outside_interface,
                "Protocol": protocol,
                "Primary_External_Destination": outside_ip,
                "Hits": hits,
                "Misses": misses,
                "Expired_Translations": expired
            }

    host_counts = {}

    for row in inventory.values():

        host_counts.setdefault(
            row["Device"],
            set()
        ).add(
            row["Private_IP"]
        )

    rows = []

    for row in inventory.values():

        row["Active_Internal_Hosts"] = len(
            host_counts[row["Device"]]
        )

        rows.append(row)

    return rows


def collect_device(host, username, password):

    conn, platform = connect_device(
        host,
        username,
        password
    )

    if not conn:

        return (
            [{
                "Device": host,
                "Platform": "UNKNOWN",
                "Command": "",
                "Output": "LOGIN FAILED"
            }],
            [],
            []
        )

    inventory_rows = []

    try:

        hostname = (
            conn.find_prompt()
            .replace("#", "")
            .strip()
        )

        for command in COMMANDS:

            print(f"{hostname}: {command}")

            output = run_command(
                conn,
                command
            )

            if output:

                inventory_rows.append({
                    "Device": hostname,
                    "Platform": platform,
                    "Command": command,
                    "Output": output.replace("\n", " | ")
                })

        nat_rule_rows = collect_nat_rules(
            conn,
            hostname,
            platform
        )

        nat_inventory_rows = collect_nat_inventory(
            conn,
            hostname,
            platform
        )

    finally:

        conn.disconnect()

    return (
        inventory_rows,
        nat_rule_rows,
        nat_inventory_rows
    )


def main():

    print()

    username = input("User ID: ")
    password = getpass.getpass("Password: ")

    hosts_input = input(
        "Enter hosts (comma separated): "
    )

    hosts = [
        host.strip()
        for host in hosts_input.split(",")
        if host.strip()
    ]

    inventory_rows = []
    nat_rule_rows = []
    nat_inventory_rows = []

    for host in hosts:

        print(f"\nCollecting {host}")

        inventory_data, nat_data, nat_inv_data = collect_device(
            host,
            username,
            password
        )

        inventory_rows.extend(
            inventory_data
        )

        nat_rule_rows.extend(
            nat_data
        )

        nat_inventory_rows.extend(
            nat_inv_data
        )

    with open(
        INVENTORY_FILE,
        "w",
        newline="",
        encoding="utf-8"
    ) as csvfile:

        writer = csv.DictWriter(
            csvfile,
            fieldnames=[
                "Device",
                "Platform",
                "Command",
                "Output"
            ]
        )

        writer.writeheader()
        writer.writerows(
            inventory_rows
        )

    with open(
        NAT_RULES_FILE,
        "w",
        newline="",
        encoding="utf-8"
    ) as csvfile:

        writer = csv.DictWriter(
            csvfile,
            fieldnames=NAT_RULE_FIELDS
        )

        writer.writeheader()
        writer.writerows(
            nat_rule_rows
        )

    with open(
        NAT_INVENTORY_FILE,
        "w",
        newline="",
        encoding="utf-8"
    ) as csvfile:

        writer = csv.DictWriter(
            csvfile,
            fieldnames=NAT_INVENTORY_FIELDS
        )

        writer.writeheader()
        writer.writerows(
            nat_inventory_rows
        )

    print()
    print("=" * 70)
    print(f"Inventory CSV      : {INVENTORY_FILE}")
    print(f"NAT Rules CSV      : {NAT_RULES_FILE}")
    print(f"NAT Inventory CSV  : {NAT_INVENTORY_FILE}")
    print(f"Inventory Records  : {len(inventory_rows)}")
    print(f"NAT Rule Records   : {len(nat_rule_rows)}")
    print(f"NAT Inventory Rows : {len(nat_inventory_rows)}")
    print("=" * 70)


if __name__ == "__main__":
    main()
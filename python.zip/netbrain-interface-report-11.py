"""
NetBrain Interface Report
==========================

Generates a per-interface CSV audit report for devices at a given NetBrain
site, using the NetBrain REST API (CMDB/Devices and CMDB/Interfaces
endpoints).

Interface
---------
Inputs (interactive prompts):
    NetBrain Username   - str, required. NetBrain login username.
    NetBrain Password   - str, required (hidden input). NetBrain login password.
    Target Site         - str, optional. Site code to filter devices by
                           (matched against hostname, mgmt IP, and subtype).
                           Defaults to "DDC1" if left blank.

Configuration (constants, edit in source to change):
    BASE_URL       - NetBrain Services API base URL.
    MAX_WORKERS    - Thread pool size for concurrent device enrichment (default 10).
    PAGE_LIMIT     - Page size when paginating the CMDB Devices endpoint (default 100).
    LIMIT_DEVICES  - Max number of matching devices to process (default 375).

Output:
    A CSV file written to:
        ~/Downloads/{TARGET_SITE}.netbrain.interface.report.{TIMESTAMP}.csv
    One row per device interface, with columns including:
        name, requestedSite, serialNumber, hardwareModel,
        interfaceName, interfaceDescription, interfaceSpeed, resolvedIP,
        vrfNames, securityZone, natInterface, patInterface,
        natTranslationDetails, plus any additional device attributes
        discovered from the API response.
        securityZone is populated only for devices detected as firewalls
        (see FIREWALL_KEYWORDS / is_firewall_device); it is "N/A" for
        all other device types. natTranslationDetails lists every
        source/destination/translated IP from NAT rules touching that
        interface's zone, semicolon-separated, for firewalls where the
        real NAT rulebase was retrieved; "N/A" otherwise.

Usage:
    python netbrain-interface-report.py

Requires network access to the NetBrain API host and valid NetBrain
credentials. SSL certificate verification is disabled for API requests.
"""

import csv
import getpass
import os
import re
import socket
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import requests
import urllib3

# Disable insecure HTTPS warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Set NETBRAIN_DEBUG=1 in the environment to print diagnostic info about
# firewall detection and raw interface attribute keys/values as returned by
# the NetBrain API. Use this to confirm the real field names for security
# zone data if securityZone is coming back as "N/A" unexpectedly.
DEBUG_ZONES = os.environ.get("NETBRAIN_DEBUG", "").strip().lower() in ("1", "true", "yes")

# ---------------------------------------------------------------------------
# Interactive Inputs & Configuration
# ---------------------------------------------------------------------------
USERNAME = input("Enter NetBrain Username: ").strip()
PASSWORD = getpass.getpass("Enter NetBrain Password: ").strip()

site_input = input("Enter Target Site [default: DDC1]: ").strip().upper()
TARGET_SITE = site_input if site_input else "DDC1"

if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
OUTPUT_FILE = os.path.expanduser(
    f"~/Downloads/{TARGET_SITE}.netbrain.interface.report.{TIMESTAMP}.csv"
)

MAX_WORKERS = 10
PAGE_LIMIT = 100
LIMIT_DEVICES = 30 # Cap processing to 3 devices

session = requests.Session()
session.verify = False

# Optimize HTTP connection pool
adapter = requests.adapters.HTTPAdapter(
    pool_connections=50, 
    pool_maxsize=50, 
    max_retries=2
)
session.mount("https://", adapter)
session.mount("http://", adapter)

DNS_CACHE = {}


def authenticate() -> dict:
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    try:
        res = session.post(login_url, json=login_payload, timeout=60)
        res.raise_for_status()
    except requests.exceptions.RequestException as e:
        sys.exit(f"Auth error: {e}")

    data = res.json()
    token = data.get("token") or data.get("tokenID")
    if not token:
        sys.exit("Error: Token missing in response payload.")

    session.headers.update({
        "Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json"
    })

    if "tenantId" in data and "domainId" in data:
        session.headers.update({
            "tenantId": str(data["tenantId"]),
            "domainId": str(data["domainId"])
        })
    return data


def fetch_all_devices() -> list:
    """Dynamically paginates through NetBrain CMDB devices until limit or end is reached."""
    all_devices = []
    skip = 0

    while True:
        url = f"{BASE_URL}/CMDB/Devices"
        try:
            res = session.get(url, params={"skip": skip, "limit": PAGE_LIMIT}, timeout=30)
            if res.status_code != 200:
                break
            
            devices = res.json().get("devices", [])
            if not devices:
                break

            all_devices.extend(devices)
            skip += PAGE_LIMIT
            
            if len(devices) < PAGE_LIMIT:
                break
        except requests.RequestException:
            break

    return all_devices


def fetch_device_attributes(hostname: str) -> dict:
    """Queries CMDB Device Attributes passing attributeNames=sn,model."""
    url = f"{BASE_URL}/CMDB/Devices/Attributes"
    params = {
        "hostname": hostname,
        "attributeNames": "sn,serialNumber,model"
    }
    try:
        res = session.get(url, params=params, timeout=15)
        if res.status_code == 200:
            return res.json().get("attributes", {})
    except requests.RequestException:
        pass
    return {}


def fetch_all_interface_attrs(hostname: str) -> dict:
    """Retrieves all interface attributes for a given hostname in a single API call."""
    url = f"{BASE_URL}/CMDB/Interfaces/Attributes"
    try:
        r = session.get(url, params={"hostname": hostname}, timeout=15)
        if r.status_code == 200:
            return r.json().get("attributes", {})
    except requests.RequestException:
        pass
    return {}


_NAT_POLICY_CACHE = {}
_NAT_POLICY_CACHE_LOCK = threading.Lock()


def fetch_nat_policy_raw(hostname: str) -> str:
    """Fetches the live NAT rulebase for a firewall by pulling its merged
    config dump and slicing out the "show running nat-policy" section.

    NOTE: "show running nat-policy" is Palo Alto-specific. On other firewall
    vendors (ASA, Fortinet, Check Point) the marker below won't be found in
    the config dump, and callers correctly fall back to N/A rather than
    reporting "No" -- see the empty-string return contract below.

    Returns "" on any failure (unreachable, marker not found, bad response).
    Callers MUST treat "" as "lookup unavailable" and must NOT interpret it
    as "no NAT configured" -- those are different facts.

    IMPLEMENTATION NOTE: there is no confirmed NetBrain endpoint for pulling
    a single arbitrary CLI command by name. The only endpoint proven to
    return real NAT data (validated against DDC1-USONME-FW4) is
    CMDB/DataEngine/DeviceData/Configuration, which returns one large
    dump containing several merged "show ..." command outputs back to
    back. We pull that once per firewall and slice out just the
    "show running nat-policy" section client-side.

    On multi-vsys Palo Alto devices, only query the BASE hostname (e.g.
    "DDC1-B2B-FW5", not "DDC1-B2B-FW5/vsys1") -- the "/vsysN" suffix is a
    NetBrain CMDB sub-object naming convention, not a real, independently
    queryable hostname, and passing it here will fail. If a firewall has
    multiple vsys, the merged config dump may only reflect the vsys context
    NetBrain polled by default; per-vsys NAT policy accuracy on multi-vsys
    boxes hasn't been validated and should be spot-checked against the
    device directly if that matters for your audit.
    """
    base_hostname = hostname.split("/")[0]  # strip "/vsysN" if present

    with _NAT_POLICY_CACHE_LOCK:
        if base_hostname in _NAT_POLICY_CACHE:
            return _NAT_POLICY_CACHE[base_hostname]

    url = f"{BASE_URL}/CMDB/DataEngine/DeviceData/Configuration"
    try:
        res = session.get(url, params={"hostname": base_hostname}, timeout=45)
        if res.status_code != 200:
            result = ""
        else:
            full_text = res.json().get("configuration", "") or ""
            marker = "show running nat-policy"
            start = full_text.find(marker)
            if start == -1:
                result = ""  # not Palo Alto, or command not present in this dump
            else:
                end = full_text.find("show running nat-policy-addresses", start)
                if end == -1:
                    end = full_text.find("show high-availability", start)
                if end == -1:
                    end = len(full_text)
                result = full_text[start:end]
    except (requests.RequestException, ValueError):
        result = ""

    with _NAT_POLICY_CACHE_LOCK:
        _NAT_POLICY_CACHE[base_hostname] = result

    return result


# Matches one PAN-OS NAT rule block, e.g.:
#   "Meraki_Public-to-intraf-34-1; index: 1" {
#           nat-type ipv4;
#           from buINTRAFUSION;
#           ...
#           translate-to "src: 143.112.197.34 (static-ip) (pool idx: 1)";
#           terminal no;
#   }
_NAT_RULE_BLOCK_RE = re.compile(r'"([^"]+);\s*index:\s*(\d+)"\s*\{(.*?)\n\}', re.DOTALL)
_NAT_FIELD_RE = re.compile(r'^\s*([\w-]+)\s+(.*?);\s*$', re.MULTILINE)


def _split_zone_list(raw: str) -> list:
    """Parses a PAN-OS 'from'/'to' field value, which may be a single zone
    name, an 'any', or a bracketed list like '[ zoneA zoneB ]'."""
    raw = raw.strip()
    if raw.startswith("[") and raw.endswith("]"):
        return [z for z in raw[1:-1].split() if z]
    if raw and raw.lower() != "any":
        return [raw]
    return []


_IP_RE = re.compile(r'\d{1,3}(?:\.\d{1,3}){3}(?:/\d{1,2})?')


def _extract_ips(raw: str) -> list:
    """Pulls every IPv4 (optionally /CIDR) literal out of a field value,
    ignoring non-IP tokens like 'any' or zone/pool names."""
    if not raw:
        return []
    return _IP_RE.findall(raw)


def parse_nat_policy(raw_text: str) -> list:
    """Parses PAN-OS 'show running nat-policy' CLI output into rule dicts:
    {name, index, from_zones, to_zones, source, destination, translate_to,
     source_ips, destination_ips, translated_ips, is_nat, is_pat}.

    is_nat: True if the rule performs any source/destination translation
            (a non-empty translate-to field).
    is_pat: True specifically when translate-to indicates port-overloaded
            translation ("dynamic-ip-and-port") -- i.e. true PAT, as
            opposed to a static 1:1 NAT or a non-overloaded dynamic-ip pool.
    source_ips/destination_ips/translated_ips: IPs parsed out of the
            'source', 'destination', and 'translate-to' fields respectively
            (e.g. "any" contributes no IPs; a bracketed list contributes
            each address in it).
    """
    rules = []
    for match in _NAT_RULE_BLOCK_RE.finditer(raw_text or ""):
        name, index, body = match.group(1), match.group(2), match.group(3)
        fields = dict(_NAT_FIELD_RE.findall(body))

        from_zones = _split_zone_list(fields.get("from", ""))
        to_zones = _split_zone_list(fields.get("to", ""))
        source = fields.get("source", "").strip()
        destination = fields.get("destination", "").strip()
        translate_to = fields.get("translate-to", "").strip().strip('"')

        rules.append({
            "name": name,
            "index": index,
            "from_zones": from_zones,
            "to_zones": to_zones,
            "source": source,
            "destination": destination,
            "translate_to": translate_to,
            "source_ips": _extract_ips(source),
            "destination_ips": _extract_ips(destination),
            "translated_ips": _extract_ips(translate_to),
            "is_nat": bool(translate_to),
            "is_pat": "dynamic-ip-and-port" in translate_to.lower(),
        })
    return rules


def build_zone_nat_map(rules: list) -> dict:
    """Aggregates parsed NAT rules into
    {zone_name_lower: {'nat': bool, 'pat': bool, 'ips': [str, ...]}}.

    A zone appearing as either the 'from' or 'to' side of a translating rule
    is considered NAT/PAT-associated. Zones that never appear (or appear
    only in non-translating rules) map to {'nat': False, 'pat': False,
    'ips': []}, which callers can confidently report as "No"/"N/A" --
    since this map is only built from a rulebase we successfully retrieved
    in full.

    'ips' collects every source/destination/translated IP from every rule
    touching that zone (source IPs, destination IPs, and the actual
    translated address), deduplicated and sorted for stable output -- this
    is what feeds the natTranslationDetails report column.
    """
    zone_map = {}
    for rule in rules:
        rule_ips = rule["source_ips"] + rule["destination_ips"] + rule["translated_ips"]
        for zone in rule["from_zones"] + rule["to_zones"]:
            key = zone.strip().lower()
            if not key:
                continue
            entry = zone_map.setdefault(key, {"nat": False, "pat": False, "ips": set()})
            entry["nat"] = entry["nat"] or rule["is_nat"]
            entry["pat"] = entry["pat"] or rule["is_pat"]
            entry["ips"].update(rule_ips)

    # Convert sets to sorted lists for deterministic, JSON/CSV-friendly output.
    for entry in zone_map.values():
        entry["ips"] = sorted(entry["ips"])
    return zone_map


FIREWALL_KEYWORDS = [
    "firewall", "asa", "fortigate", "fortinet", "palo alto", "paloalto",
    "panorama", "checkpoint", "check point", "srx firewall", "ngfw",
]


def is_firewall_device(device: dict) -> bool:
    """Best-effort detection of firewall devices based on type/family/vendor metadata."""
    candidate_values = []
    for key in ["subType", "sub_type", "subTypeName", "sub_type_name", "family", "type", "deviceType", "vendor", "model"]:
        val = device.get(key)
        if val and isinstance(val, str):
            candidate_values.append(val.lower())

    attrs = device.get("attributes")
    if isinstance(attrs, dict):
        for key in ["subType", "subTypeName", "family", "type", "deviceType", "vendor", "model"]:
            val = attrs.get(key)
            if val and isinstance(val, str):
                candidate_values.append(val.lower())

    combined = " ".join(candidate_values)
    result = any(kw in combined for kw in FIREWALL_KEYWORDS)

    if DEBUG_ZONES:
        hostname_dbg = device.get("hostName") or device.get("hostname") or device.get("name") or "?"
        print(
            f"[DEBUG] is_firewall_device({hostname_dbg}) -> {result} "
            f"| candidate_values={candidate_values}"
        )

    return result


def extract_site_from_device(device: dict) -> str:
    """Extracts site location metadata from device payload, falling back to TARGET_SITE."""
    for key in ["siteName", "site", "sitePath", "location", "site_name"]:
        val = device.get(key)
        if val and isinstance(val, str) and val.strip():
            return val.strip()

    return TARGET_SITE


def clean_ip(val) -> str:
    """Strips subnet masks, CIDR notation, and whitespace to isolate raw IP for DNS queries."""
    if not val or not isinstance(val, str):
        return ""
    ip_only = val.split("/")[0].strip()
    return ip_only if ip_only.upper() != "N/A" else ""


def resolve_ptr(ip_str: str, hostname_fallback: str = "") -> tuple:
    """Performs reverse DNS lookup returning (ip_with_mask, dns_name) separately."""
    clean_ip_addr = clean_ip(ip_str)
    raw_ip_entry = str(ip_str).strip() if ip_str else "N/A"
    if not clean_ip_addr:
        return ("N/A", "N/A")

    if clean_ip_addr in DNS_CACHE:
        _, cached_dns = DNS_CACHE[clean_ip_addr]
        return (raw_ip_entry, cached_dns)

    try:
        dns_name, _, _ = socket.gethostbyaddr(clean_ip_addr)
        result = (raw_ip_entry, dns_name)
    except Exception:
        fallback_dns = hostname_fallback if hostname_fallback and hostname_fallback.upper() != "N/A" else "N/A"
        result = (raw_ip_entry, fallback_dns)

    DNS_CACHE[clean_ip_addr] = result
    return result


def enrich_device_metadata(hostname: str, raw_device: dict) -> tuple:
    """Enriches device metadata, returning a per-interface row list plus device-level attributes."""
    intf_data = {}

    site_name = extract_site_from_device(raw_device)

    device_is_firewall = is_firewall_device(raw_device)

    if not hostname:
        placeholder_intf = [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "natInterface": "N/A", "patInterface": "N/A",
            "natTranslationDetails": "N/A",
            "securityZone": "N/A"
        }]
        return placeholder_intf, "N/A", "N/A", site_name

    # Fetch device attributes, interface attributes, and (for firewalls) the
    # live NAT rulebase concurrently.
    with ThreadPoolExecutor(max_workers=3) as inner_executor:
        future_attrs = inner_executor.submit(fetch_device_attributes, hostname)
        future_intf_attrs = inner_executor.submit(fetch_all_interface_attrs, hostname)
        future_nat_policy = (
            inner_executor.submit(fetch_nat_policy_raw, hostname)
            if device_is_firewall else None
        )

        dev_attrs = future_attrs.result()
        all_intf_attrs = future_intf_attrs.result()
        nat_policy_raw = future_nat_policy.result() if future_nat_policy else ""

    # zone_nat_map is None when the NAT rulebase couldn't be retrieved (wrong
    # vendor, no permissions, API error) -- callers must fall back to the
    # interface-attribute-based guess (and ultimately N/A) in that case,
    # rather than assume "no NAT". It's {} (falsy-but-not-None) when we did
    # retrieve a rulebase and it genuinely has zero rules touching a zone.
    zone_nat_map = build_zone_nat_map(parse_nat_policy(nat_policy_raw)) if nat_policy_raw else None

    if DEBUG_ZONES and device_is_firewall:
        print(
            f"[DEBUG] {hostname}: NAT policy fetch {'succeeded' if nat_policy_raw else 'FAILED/empty'} "
            f"| zone_nat_map={zone_nat_map}"
        )

    sn_val = dev_attrs.get("sn") or dev_attrs.get("serialNumber") or "N/A"
    model_val = dev_attrs.get("model") or "N/A"

    if DEBUG_ZONES and device_is_firewall and all_intf_attrs:
        sample_intf_name = next(iter(all_intf_attrs))
        print(
            f"[DEBUG] {hostname}: sample interface '{sample_intf_name}' raw attrs = "
            f"{all_intf_attrs[sample_intf_name]}"
        )

    for intf_name, attrs in all_intf_attrs.items():
        if not intf_name:
            continue

        clean_intf = str(intf_name).strip()

        if isinstance(attrs, dict):
            speed_val = attrs.get("speed") or attrs.get("bandwidth") or attrs.get("interfaceSpeed")
            clean_speed = str(speed_val).strip() if speed_val and str(speed_val).strip() else "N/A"

            descr_val = attrs.get("descr") or attrs.get("description") or attrs.get("interfaceDescription")
            clean_descr = str(descr_val).strip() if descr_val and str(descr_val).strip() else "N/A"

            vrf_val = str(attrs.get("mplsVrf") or attrs.get("vrfName") or attrs.get("vrf") or "").strip()
            clean_vrf = vrf_val if vrf_val and vrf_val.lower() not in ["none", "null", "undefined", "n/a", "0"] else "default"

            if device_is_firewall:
                zone_val = str(
                    attrs.get("securityZone")
                    or attrs.get("zoneName")
                    or attrs.get("zone")
                    or attrs.get("nameif")
                    or ""
                ).strip()
                if not zone_val or zone_val.lower() in ["none", "null", "undefined", "n/a"]:
                    # NetBrain appears to surface the firewall zone name through
                    # the same VRF-style attribute used for routers (e.g. it's
                    # empty/"default" on physical/HA interfaces and set to the
                    # real zone name on zone-assigned subinterfaces).
                    zone_val = vrf_val
                clean_zone = (
                    zone_val
                    if zone_val and zone_val.lower() not in ["none", "null", "undefined", "n/a", "0", "default"]
                    else "N/A"
                )
            else:
                clean_zone = "N/A"

            # NetBrain only populates isNatIntf/natType/nat (and the PAT
            # equivalents) for some platforms; on others (e.g. Palo Alto)
            # the key is present but always blank, or absent entirely,
            # because NAT/PAT is a policy construct rather than an
            # interface attribute there. A blank/missing key is NOT the
            # same as "confirmed no NAT" -- treat it as unknown ("N/A")
            # on firewalls, same as securityZone already does, rather than
            # silently reporting "No". This is the fallback used when we
            # don't have (or couldn't parse) an actual NAT rulebase below.
            nat_keys_present = any(
                attrs.get(k) not in (None, "")
                for k in ("isNatIntf", "natType", "nat")
            )
            pat_keys_present = any(
                attrs.get(k) not in (None, "")
                for k in ("isPatIntf", "patType", "pat")
            )

            nat_val = attrs.get("isNatIntf") or attrs.get("natType") or attrs.get("nat")
            pat_val = attrs.get("isPatIntf") or attrs.get("patType") or attrs.get("pat")

            if device_is_firewall and not nat_keys_present:
                is_nat = "N/A"
            else:
                is_nat = "Yes" if nat_val and str(nat_val).lower() not in ["false", "0", "disabled", "no", ""] else "No"

            if device_is_firewall and not pat_keys_present:
                is_pat = "N/A"
            else:
                is_pat = "Yes" if pat_val and str(pat_val).lower() not in ["false", "0", "disabled", "no", ""] else "No"

            # Authoritative override: if we successfully retrieved and parsed
            # this firewall's real NAT rulebase (zone_nat_map is not None),
            # trust that over the interface-attribute guess above -- it's
            # policy ground truth, keyed by the interface's own zone.
            # A zone with a known-empty rulebase correctly reports "No" here,
            # since the absence of NAT is now a confirmed fact, not a guess.
            #
            # nat_ip_details: every source/destination/translated IP from
            # every NAT rule touching this interface's zone, deduped and
            # joined into one semicolon-separated line for the report
            # column. "N/A" means we don't have rulebase data for this
            # zone (not "confirmed no IPs") -- same distinction as is_nat.
            nat_ip_details = "N/A"
            if device_is_firewall and zone_nat_map is not None and clean_zone != "N/A":
                zone_entry = zone_nat_map.get(clean_zone.lower())
                is_nat = "Yes" if zone_entry and zone_entry["nat"] else "No"
                is_pat = "Yes" if zone_entry and zone_entry["pat"] else "No"
                if zone_entry and zone_entry["ips"]:
                    nat_ip_details = ";".join(zone_entry["ips"])
                elif zone_entry is not None:
                    nat_ip_details = "None"  # zone confirmed in rulebase, but no IPs to show

            if DEBUG_ZONES:
                nat_pat_candidates = {
                    k: v for k, v in attrs.items()
                    if any(tok in k.lower() for tok in ["nat", "pat"])
                }
                print(
                    f"[DEBUG] {hostname}/{clean_intf}: zone={clean_zone!r} "
                    f"nat_val={nat_val!r} -> {is_nat} | "
                    f"pat_val={pat_val!r} -> {is_pat} | "
                    f"nat/pat-like raw attrs={nat_pat_candidates}"
                )

            intf_ip = "N/A"
            ips_raw = attrs.get("ips") or attrs.get("ipAddress")
            raw_list = ips_raw if isinstance(ips_raw, list) else [ips_raw]

            for item in raw_list:
                ip_str = item.get("ipLoc") if isinstance(item, dict) else item
                mask_val = item.get("mask") or item.get("subnetMask") if isinstance(item, dict) else ""

                c_ip = clean_ip(ip_str)
                if c_ip:
                    # Construct full IP with subnet mask if available separately
                    if mask_val and "/" not in str(ip_str):
                        full_ip_with_mask = f"{ip_str}/{mask_val}"
                    else:
                        full_ip_with_mask = str(ip_str).strip()

                    resolved_ip, _ = resolve_ptr(full_ip_with_mask, hostname)
                    intf_ip = resolved_ip
                    break  # one resolved IP per interface

            intf_data[clean_intf] = {
                "name": clean_intf,
                "description": clean_descr,
                "speed": clean_speed,
                "vrf": clean_vrf,
                "nat": is_nat,
                "pat": is_pat,
                "nat_ip_details": nat_ip_details,
                "ip": intf_ip,
                "zone": clean_zone,
            }
        else:
            intf_data[clean_intf] = {
                "name": clean_intf,
                "description": "N/A",
                "speed": "N/A",
                "vrf": "default",
                "nat": "No",
                "pat": "No",
                "nat_ip_details": "N/A",
                "ip": "N/A",
                "zone": "N/A",
            }

    sorted_intfs = sorted(intf_data.keys())
    if sorted_intfs:
        interfaces_list = [
            {
                "interfaceName": intf_data[intf]["name"],
                "interfaceDescription": intf_data[intf]["description"],
                "interfaceSpeed": intf_data[intf]["speed"],
                "resolvedIP": intf_data[intf]["ip"],
                "vrfNames": intf_data[intf]["vrf"],
                "natInterface": intf_data[intf]["nat"],
                "patInterface": intf_data[intf]["pat"],
                "natTranslationDetails": intf_data[intf]["nat_ip_details"],
                "securityZone": intf_data[intf]["zone"],
            }
            for intf in sorted_intfs
        ]
    else:
        interfaces_list = [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "natInterface": "N/A", "patInterface": "N/A",
            "natTranslationDetails": "N/A",
            "securityZone": "N/A"
        }]

    return (
        interfaces_list,
        sn_val,
        model_val,
        site_name,
    )


def main():
    authenticate()

    site_devices = []
    seen_hostnames = set()
    all_discovered_columns = {
        "requestedSite",
        "serialNumber",
        "hardwareModel",
        "interfaceDescription",
        "interfaceSpeed",
        "vrfNames",
        "resolvedIP",
        "natInterface",
        "patInterface",
        "natTranslationDetails",
    }
    
    EXCLUDED_FIELDS = {
        "hostName",
        "hostname",
        "mgmtIP",
        "domain",
        "domainName",
        "dnsDomain",
    }

    print(f"Fetching global CMDB devices for target site '{TARGET_SITE}'...")
    raw_devices = fetch_all_devices()

    for device in raw_devices:
        if len(site_devices) >= LIMIT_DEVICES:
            break

        hostname = (
            device.get("hostName")
            or device.get("hostname")
            or device.get("name")
        )

        if hostname and hostname not in seen_hostnames:
            searchable_fields = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()

            if TARGET_SITE in searchable_fields:
                seen_hostnames.add(hostname)
                flat_device = {"_raw_device": device}
                flat_device["requestedSite"] = extract_site_from_device(device)

                for k, v in device.items():
                    if k in EXCLUDED_FIELDS or any(
                        ex in k.lower() for ex in ["id", "discovery", "time"]
                    ):
                        continue
                    if k == "attributes" and isinstance(v, dict):
                        for sub_k, sub_v in v.items():
                            if sub_k not in EXCLUDED_FIELDS and not any(
                                ex in sub_k.lower() for ex in ["id", "discovery", "time"]
                            ):
                                flat_device[f"attr_{sub_k}"] = sub_v
                    else:
                        flat_device[k] = v

                all_discovered_columns.update(
                    k for k in flat_device if not k.startswith("_")
                )
                site_devices.append(flat_device)

    print(f"Limiting audit to {len(site_devices)} assets. Enriching metadata ({MAX_WORKERS} workers)...")

    if site_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(
                    enrich_device_metadata,
                    dev.get("name") or dev.get("hostName") or dev.get("hostname"),
                    dev.get("_raw_device", {}),
                ): dev
                for dev in site_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    (
                        interfaces_list,
                        sn_res,
                        model_res,
                        site_res,
                    ) = future.result()

                    dev["_interfaces"] = interfaces_list
                    dev["serialNumber"] = sn_res
                    dev["hardwareModel"] = model_res
                    dev["requestedSite"] = site_res
                except Exception:
                    dev["_interfaces"] = [{
                        "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
                        "resolvedIP": "N/A", "vrfNames": "default", "natInterface": "N/A", "patInterface": "N/A",
                        "natTranslationDetails": "N/A",
                        "securityZone": "N/A"
                    }]
                    dev["serialNumber"] = "N/A"
                    dev["hardwareModel"] = "N/A"
                    dev["requestedSite"] = TARGET_SITE
                finally:
                    dev.pop("_raw_device", None)

    primary_headers = [
        "name",
        "requestedSite",
        "serialNumber",
        "hardwareModel",
        "interfaceName",
        "interfaceDescription",
        "interfaceSpeed",
        "resolvedIP",
        "vrfNames",
        "securityZone",
        "natInterface",
        "patInterface",
        "natTranslationDetails",
    ]
    extra_headers = sorted(
        [
            col
            for col in all_discovered_columns
            if col not in primary_headers and col not in EXCLUDED_FIELDS
        ]
    )
    ordered_headers = primary_headers + extra_headers

    # Expand each device into one row per interface, repeating device-level fields.
    final_rows = []
    for dev in site_devices:
        interfaces = dev.pop("_interfaces", None) or [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "natInterface": "N/A", "patInterface": "N/A",
            "natTranslationDetails": "N/A",
            "securityZone": "N/A"
        }]
        for intf_row in interfaces:
            row = {**dev, **intf_row}
            final_rows.append(row)

    output_dir = os.path.dirname(OUTPUT_FILE)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=ordered_headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(final_rows)

    print(f"Export successful: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
"""
nat_acl_extractor.py

Prompts for a comma-delimited list of host names, a username, a
password, and an object-group name (defaults to
Aruba_SDWAN_MPLS_IP). Connects to each host and runs:

    show object-group

Cisco IOS-XE (unlike ASA) has no way to filter this command to a
single group by name/id -- it always dumps every object group on
the box. So this script runs the bare command once per host, then
locates the block for the requested group name in the output and
parses just that block. IOS-XE member syntax also differs from ASA:
no 'network-object' keyword, just plain lines under the header, e.g.:

    Network object group Aruba_SDWAN_MPLS_IP
     host 10.1.1.5
     10.2.0.0 255.255.0.0
     group-object SomeNestedGroup

Each network/host entry found in that block is written to its own
CSV column. If your platform is actually ASA/Firepower (which DOES
support 'show object-group id <name>'), see the ASA_MODE flag below.

Requires: netmiko   ->   pip install netmiko
Falls back to a basic paramiko SSH session if netmiko isn't installed,
but netmiko is strongly recommended for clean command output.
"""

import re
import csv
import time
import getpass
import json
from datetime import datetime

MAX_RETRIES = 10
RETRY_DELAY_SECONDS = 5
DEFAULT_GROUP_NAME = "Aruba_SDWAN_MPLS_IP"

# Set True only if your devices are ASA/Firepower, which supports
# filtering by name/id directly on the device.
ASA_MODE = False

# IOS-XE: no per-group filter exists, always returns every group.
IOSXE_OBJGROUP_CMD = "show object-group"
# ASA/Firepower: can filter directly on-box.
ASA_OBJGROUP_CMD_TEMPLATE = "show object-group id {group_name}"

try:
    from netmiko import ConnectHandler
    HAVE_NETMIKO = True
except ImportError:
    HAVE_NETMIKO = False
    import paramiko


def get_objgroup_output_netmiko(host, username, password, command):
    device = {
        "device_type": "cisco_asa" if ASA_MODE else "cisco_xe",
        "host": host,
        "username": username,
        "password": password,
    }
    conn = ConnectHandler(**device)
    output = conn.send_command(command, read_timeout=60)
    conn.disconnect()
    return output


def get_objgroup_output_paramiko(host, username, password, command):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=username, password=password, timeout=60)
    shell = client.invoke_shell()
    time.sleep(1)
    if shell.recv_ready():
        shell.recv(65535)  # clear banner/prompt
    shell.send("terminal pager 0\n")
    time.sleep(1)
    if shell.recv_ready():
        shell.recv(65535)
    shell.send(command + "\n")
    time.sleep(3)
    output = ""
    while shell.recv_ready():
        output += shell.recv(65535).decode(errors="ignore")
        time.sleep(0.5)
    client.close()
    return output


def get_objgroup_output(host, username, password, command):
    last_exception = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            if HAVE_NETMIKO:
                return get_objgroup_output_netmiko(host, username, password, command)
            return get_objgroup_output_paramiko(host, username, password, command)
        except Exception as exc:
            last_exception = exc
            print(f"    [!] Attempt {attempt}/{MAX_RETRIES} failed for {host}: {exc}")
            if attempt < MAX_RETRIES:
                print(f"    [i] Retrying in {RETRY_DELAY_SECONDS}s ...")
                time.sleep(RETRY_DELAY_SECONDS)
    raise last_exception


def extract_group_block(full_output, group_name):
    """
    IOS-XE's 'show object-group' dumps every object group on the box,
    with no on-device filter for a single name. This finds the block
    for the requested group, i.e. everything indented under:

        Network object group <group_name>

    up to (but not including) the next top-level 'Network object
    group' / 'Service object group' header, or end of output.
    Returns the block text, or None if the group name wasn't found.
    """
    pattern = re.compile(
        rf"^Network object group {re.escape(group_name)}\s*\n"
        rf"((?:^[ \t]+.*\n?)*)",
        re.MULTILINE,
    )
    match = pattern.search(full_output)
    if not match:
        return None
    return match.group(1)


def extract_network_entries(objgroup_output, group_name, asa_mode=False):
    """
    Returns a list of dicts describing each member entry:
      {type: "host"|"network"|"nested-group", value: "..."}

    ASA syntax (asa_mode=True), e.g.:
      network-object host 10.1.1.5
      network-object 10.1.1.0 255.255.255.0
      group-object SomeNestedGroup

    IOS-XE syntax (asa_mode=False) -- no 'network-object' keyword,
    just plain lines under the group's header, e.g.:
      host 10.1.1.5
      10.2.0.0 255.255.0.0
      group-object SomeNestedGroup
    In this mode the group's block is located first via
    extract_group_block(), since the raw 'show object-group' output
    contains every group on the device.
    """
    entries = []

    if asa_mode:
        block = objgroup_output
    else:
        block = extract_group_block(objgroup_output, group_name)
        if block is None:
            return entries

    host_pattern = re.compile(
        r"^\s*(?:network-object\s+)?host\s+(\S+)", re.MULTILINE
    )
    for ip in host_pattern.findall(block):
        entries.append({"type": "host", "value": ip})

    if asa_mode:
        net_pattern = re.compile(
            r"^\s*network-object\s+(?!host\b)(\S+)\s+(\S+)", re.MULTILINE
        )
    else:
        # Plain "<ip> <mask>" lines (not preceded by 'host' or 'group-object')
        net_pattern = re.compile(
            r"^\s*(\d{1,3}(?:\.\d{1,3}){3})\s+(\d{1,3}(?:\.\d{1,3}){3})\s*$",
            re.MULTILINE,
        )
    for net_ip, mask in net_pattern.findall(block):
        entries.append({"type": "network", "value": f"{net_ip} {mask}"})

    nested_pattern = re.compile(r"^\s*group-object\s+(\S+)", re.MULTILINE)
    for nested_name in nested_pattern.findall(block):
        entries.append({
            "type": "nested-group",
            "value": f"{nested_name} (not expanded - run separately)",
        })

    return entries


def extract_all_ips(text):
    """
    Extracts every IPv4-looking address found anywhere in the command
    output, deduplicated and sorted.
    """
    ip_pattern = re.compile(r"\b(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\b")
    found = set()
    for match in ip_pattern.finditer(text):
        octets = match.groups()
        if all(0 <= int(o) <= 255 for o in octets):
            found.add(".".join(octets))
    return sorted(found, key=lambda ip: tuple(int(o) for o in ip.split(".")))


def write_results_to_csv(results, group_name):
    """
    Writes one row per network entry to a CSV file named
    objgroup-extract-<date>-<time>.csv
    Columns: Host, Object_Group, Entry_Type, Network_IP, All_IPs_In_Output

    All_IPs_In_Output contains every IPv4 address found anywhere in
    that host's command output (semicolon-separated, repeated on each
    row for that host).
    """
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"objgroup-extract-{timestamp}.csv"

    with open(filename, "w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(
            ["Host", "Object_Group", "Entry_Type", "Network_IP", "All_IPs_In_Output"]
        )

        for host, host_data in results.items():
            if "error" in host_data:
                writer.writerow([host, group_name, "", f"ERROR: {host_data['error']}", ""])
                continue

            all_ips_str = ";".join(host_data.get("all_ips", []))
            entries = host_data.get("entries", [])

            if not entries:
                writer.writerow(
                    [host, group_name, "", "No entries found in object-group", all_ips_str]
                )
                continue

            for entry in entries:
                writer.writerow(
                    [host, group_name, entry["type"], entry["value"], all_ips_str]
                )

    return filename


def main():
    hosts_input = input("Enter host names (comma separated): ")
    hosts = [h.strip() for h in hosts_input.split(",") if h.strip()]

    username = input("Username: ")
    password = getpass.getpass("Password: ")

    group_name = input(f"Object-group name [{DEFAULT_GROUP_NAME}]: ").strip()
    if not group_name:
        group_name = DEFAULT_GROUP_NAME

    if ASA_MODE:
        command = ASA_OBJGROUP_CMD_TEMPLATE.format(group_name=group_name)
    else:
        command = IOSXE_OBJGROUP_CMD

    if not HAVE_NETMIKO:
        print("[!] netmiko not installed, falling back to raw paramiko SSH.")
        print("    For reliable results, run: pip install netmiko\n")

    results = {}

    for host in hosts:
        print(f"\n[+] Connecting to {host} ...")
        try:
            output_text = get_objgroup_output(host, username, password, command)
        except Exception as exc:
            print(f"[!] Failed to connect to {host}: {exc}")
            results[host] = {"error": str(exc)}
            continue

        if "invalid input" in output_text.lower() or "does not exist" in output_text.lower():
            print(f"    [!] Device response suggests the command may be wrong on {host}:")
            print(f"        {output_text.strip()[:200]}")
        elif not ASA_MODE and f"network object group {group_name}".lower() not in output_text.lower():
            print(f"    [!] Group '{group_name}' was not found anywhere in the "
                  f"'show object-group' output for {host}. Check spelling/case.")

        all_ips = extract_all_ips(output_text)
        entries = extract_network_entries(output_text, group_name, asa_mode=ASA_MODE)

        results[host] = {"entries": entries, "all_ips": all_ips}

        if not entries:
            print(f"    No network entries found for group '{group_name}' on {host}.")
        else:
            print(f"    Found {len(entries)} entr(y/ies) in '{group_name}' on {host}:")
            for entry in entries:
                print(f"      [{entry['type']}] {entry['value']}")
        print(f"    Total unique IPs found in output: {len(all_ips)}")

    print("\n=== Summary (JSON) ===")
    print(json.dumps(results, indent=2))

    csv_filename = write_results_to_csv(results, group_name)
    print(f"\n[+] Results written to {csv_filename}")


if __name__ == "__main__":
    main()

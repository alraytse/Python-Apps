import urllib3
import requests

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configuration
NETBRAIN_URL = "https://netbrain.mckesson.com"
USERNAME = "skk30ws"
PASSWORD = "e4-97chi{'}r-$eIwxLGu"
HOSTNAME = "DDC1-ISP-GRT2"  # e.g., a real switch or router name

# 1. Authenticate to get session credentials
login_url = f"{NETBRAIN_URL}/ServicesAPI/API/V1/Session"
login_payload = {
    "username": USERNAME,
    "password": PASSWORD
}

login_resp = requests.post(login_url, json=login_payload, verify=False)
login_data = login_resp.json()

# Extract required authentication headers
session_token = login_data.get("token") or login_data.get("tokenID")
tenant_id = login_data.get("tenantId")
domain_id = login_data.get("domainId")

if not session_token:
    print(f"Authentication failed: {login_data}")
    exit(1)

# 2. Query Device Serial Number & Attributes
attr_url = f"{NETBRAIN_URL}/ServicesAPI/API/V1/CMDB/Devices/Attributes"
headers = {
    "Token": session_token,
    "tenantId": tenant_id,
    "domainId": domain_id,
    "Content-Type": "application/json"
}
params = {
    "hostname": HOSTNAME,
    "attributeNames": "sn,serialNumber,model,version"
}

device_resp = requests.get(attr_url, headers=headers, params=params, verify=False)
device_data = device_resp.json()

# Extract attributes dictionary
attributes = device_data.get("attributes", {})

# Safely extract serial number across common field keys
serial_number = (
    attributes.get("sn") 
    or attributes.get("serialNumber") 
    or attributes.get("serial_number") 
    or "N/A"
)

print(f"Device: {HOSTNAME}")
print(f"Serial Number: {serial_number}")
print(f"Model: {attributes.get('model', 'N/A')}")
print(f"Version: {attributes.get('version', 'N/A')}")
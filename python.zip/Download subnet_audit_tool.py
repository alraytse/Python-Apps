#!/usr/bin/env python3
import csv, re, getpass, ipaddress
from datetime import datetime
from netmiko import ConnectHandler


def generate_subnets(start_subnet, end_subnet):
    start_net = ipaddress.ip_network(start_subnet, strict=False)
    end_net = ipaddress.ip_network(end_subnet, strict=False)
    current = start_net.network_address
    step = start_net.num_addresses
    subnets = []
    while int(current) <= int(end_net.network_address):
        subnets.append(str(ipaddress.ip_network(f"{current}/{start_net.prefixlen}", strict=False)))
        current = ipaddress.ip_address(int(current) + step)
    return subnets


def ping_ip(conn, ip):
    try:
        out = conn.send_command(f"ping {ip}", read_timeout=30)
        m = re.search(r"Success rate is\s+(\d+)\s+percent", out, re.I)
        if m:
            pct = int(m.group(1))
            return ('Yes' if pct > 0 else 'No', pct)
        return ('Yes',100) if '!!!!!' in out else ('No',0)
    except Exception:
        return ('Error',0)


def check_recursive_route(conn, next_hop, vrf=''):
    cmd = f"show ip route vrf {vrf} {next_hop}" if vrf else f"show ip route {next_hop}"
    try:
        out = conn.send_command(cmd, read_timeout=20)
        return 'Fail' if ('Network not in table' in out or 'Route not found' in out) else 'OK'
    except Exception:
        return 'Error'


def check_arp(conn, ip):
    try:
        out = conn.send_command(f"show ip arp {ip}", read_timeout=20)
        if 'Incomplete' in out:
            return 'No'
        return 'Yes' if ip in out else 'Unknown'
    except Exception:
        return 'Unknown'


def test_ip_in_subnet(subnet):
    net = ipaddress.ip_network(subnet, strict=False)
    hosts = list(net.hosts())
    return str(hosts[0]) if hosts else None


def determine_status(r):
    if r['null0_route']=='Yes':
        return 'BLACKHOLED'
    if r['reachable']=='No':
        return 'NO_ROUTE'
    if r['recursive_route']=='Fail':
        return 'BROKEN_NEXT_HOP'
    if r['icmp_reachable']=='No':
        return 'NEXT_HOP_DOWN'
    if r['destination_ping']=='Yes':
        return 'REACHABLE'
    return 'PARTIAL'


def check_subnet(conn, subnet, vrf=''):
    r = {'reachable':'No','route_type':'','next_hop':'','null0_route':'No','icmp_reachable':'','recursive_route':'','arp_present':'','destination_ping':'','longer_prefixes_found':'No','status':'','route_info':''}
    cmd = f"show ip route vrf {vrf} {subnet}" if vrf else f"show ip route {subnet}"
    try:
        out = conn.send_command(cmd, read_timeout=30)
        r['route_info'] = out.replace('\n',' ')
        if 'not in table' in out.lower():
            r['status']='NO_ROUTE'; return r
        r['reachable']='Yes'
        m = re.search(r'Known via "([^"]+)"', out)
        if m: r['route_type']=m.group(1)
        if re.search(r'\bNull0\b', out, re.I):
            r['null0_route']='Yes'
        try:
            lp = conn.send_command((f"show ip route vrf {vrf} longer-prefixes {subnet.split('/')[0]}" if vrf else f"show ip route longer-prefixes {subnet.split('/')[0]}"), read_timeout=20)
            if lp and 'not in table' not in lp.lower():
                r['longer_prefixes_found']='Yes'
        except Exception:
            pass
        nh = re.search(r'via\s+(\d+\.\d+\.\d+\.\d+)', out)
        if nh:
            r['next_hop']=nh.group(1)
            r['recursive_route']=check_recursive_route(conn, r['next_hop'], vrf)
            r['arp_present']=check_arp(conn, r['next_hop'])
            if r['null0_route']=='No':
                icmp,pct = ping_ip(conn, r['next_hop'])
                r['icmp_reachable']=icmp
        tip = test_ip_in_subnet(subnet)
        if tip:
            dest,_ = ping_ip(conn, tip)
            r['destination_ping']=dest
        r['status']=determine_status(r)
        return r
    except Exception as e:
        r['route_info']=str(e)
        r['status']='ERROR'
        return r


def main():
    start=input('Beginning subnet/mask: ').strip()
    end=input('Ending subnet/mask: ').strip()
    hosts=input('Hosts (comma delimited): ').strip().split(',')
    vrf=input('VRF (blank=default): ').strip()
    user=input('Username: ').strip()
    pwd=getpass.getpass('Password: ')
    subnets=generate_subnets(start,end)
    results=[]
    for host in [h.strip() for h in hosts if h.strip()]:
        try:
            conn=ConnectHandler(device_type='cisco_ios',host=host,username=user,password=pwd,fast_cli=False)
            hostname=conn.find_prompt().rstrip('#>')
            for subnet in subnets:
                d=check_subnet(conn,subnet,vrf)
                d.update({'device':host,'hostname':hostname,'vrf':vrf or 'default','subnet':subnet})
                results.append(d)
            conn.disconnect()
        except Exception as e:
            print(f'Failed: {host} - {e}')
    csvfile=f"subnet_audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    fields=['device','hostname','vrf','subnet','status','reachable','route_type','next_hop','recursive_route','arp_present','null0_route','icmp_reachable','destination_ping','longer_prefixes_found','route_info']
    with open(csvfile,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader(); w.writerows(results)
    print(f'CSV saved: {csvfile}')

if __name__ == '__main__':
    main()



#!/usr/bin/env python3
"""
Aruba CX checkpoint creator with platform detection:
- Prompts for comma-separated hostnames/IPs, username, password, and change number.
- Detects ArubaOS-CX via 'show version'.
- If CX: disables paging, creates a checkpoint named <CHANGE_NUMBER>, verifies, and logs output.
- If not CX: skips with a message.

Requires:
    pip install paramiko
"""

import paramiko
import getpass
import time
from datetime import datetime
from typing import Optional, Tuple

# ---- I/O prompts ----
def prompt_inputs() -> Tuple[list, str, str, str]:
    hosts_raw = input("Hostnames/IPs (comma-separated): ").strip()
    hosts = [h.strip() for h in hosts_raw.split(",") if h.strip()]
    if not hosts:
        raise SystemExit("No hosts provided.")

    username = input("Username: ").strip()
    if not username:
        raise SystemExit("Username is required.")

    password = getpass.getpass("Password: ")
    if not password:
        raise SystemExit("Password is required.")

    change_number = input("Change number (used as checkpoint name): ").strip()
    if not change_number:
        raise SystemExit("Change number is required.")

    return hosts, username, password, change_number

# ---- SSH helpers ----
def connect_ssh(host: str, username: str, password: str, timeout: int = 15) -> Optional[Tuple[paramiko.SSHClient, paramiko.Channel]]:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=host,
            username=username,
            password=password,
            look_for_keys=False,
            allow_agent=False,
            timeout=timeout,
        )
        chan = client.invoke_shell()
        chan.settimeout(timeout)
        time.sleep(0.5)  # settle
        return client, chan
    except Exception as e:
        print(f"[{host}] SSH connection failed: {e}")
        return None

def _read_all(chan: paramiko.Channel, idle_threshold: float = 0.5, max_wait: float = 20.0) -> str:
    """
    Read from channel until there's no new data for idle_threshold seconds,
    or max_wait is reached.
    """
    output = []
    start = time.time()
    last_data_time = start
    while True:
        if chan.recv_ready():
            data = chan.recv(65535).decode(errors="ignore")
            output.append(data)
            last_data_time = time.time()
        else:
            time.sleep(0.1)
        if (time.time() - last_data_time) >= idle_threshold:
            break
        if (time.time() - start) >= max_wait:
            break
    return "".join(output)

def send_cmd(chan: paramiko.Channel, cmd: str, settle: float = 0.25) -> str:
    chan.send(cmd + "\n")
    time.sleep(settle)
    return _read_all(chan)

# ---- Platform detection (CX) ----
def is_cx(chan: paramiko.Channel) -> bool:
    """
    Determines if the device is ArubaOS-CX by parsing 'show version'.
    Returns True for CX, False otherwise.
    """
    try:
        out = send_cmd(chan, "show version")
        text = out.lower()
        # Common markers in CX 'show version' output
        if ("arubaos-cx" in text) or ("aos-cx" in text):
            return True
        # Some CX images show platform lines like "Switch 6200/6300/6400/8320/8325/8400"
        # coupled with "Software Version 10.x"
        if ("software version" in text and "10." in text and "aruba" in text):
            return True
        return False
    except Exception:
        return False

# ---- Main per-host workflow ----
def create_checkpoint_if_cx(host: str, username: str, password: str, change_number: str) -> None:
    conn = connect_ssh(host, username, password)
    if not conn:
        return
    client, chan = conn
    try:
        # Some Aruba platforms support 'enable'; harmless if not needed.
        send_cmd(chan, "enable")

        # Detect CX
        if not is_cx(chan):
            print(f"[{host}] Not detected as ArubaOS-CX. Skipping checkpoint command.")
            return

        # Disable paging for CX
        send_cmd(chan, "terminal length 0")

        # Build and execute checkpoint command
        checkpoint_cmd = f"copy running-config checkpoint {change_number}"
        output = send_cmd(chan, checkpoint_cmd)

        # Verify by listing checkpoints
        verify_out = send_cmd(chan, "show checkpoint list")

        # Save log
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        fname = f"{host}_checkpoint_{change_number}_{ts}.log"
        body = (
            f"# Host: {host}\n"
            f"# Platform: ArubaOS-CX (detected)\n"
            f"# Change number (checkpoint name): {change_number}\n"
            f"# Timestamp: {datetime.now().isoformat(timespec='seconds')}\n\n"
            f"$ {checkpoint_cmd}\n{output}\n\n"
            f"$ show checkpoint list\n{verify_out}\n"
        )
        with open(fname, "w", encoding="utf-8") as f:
            f.write(body)

        print(f"[{host}] CX checkpoint '{change_number}' attempted; log saved to {fname}")
    except Exception as e:
        print(f"[{host}] Checkpoint operation failed: {e}")
    finally:
        try:
            chan.close()
        except Exception:
            pass
        try:
            client.close()
        except Exception:
            pass

def main():
    hosts, username, password, change_number = prompt_inputs()
    for host in hosts:
        create_checkpoint_if_cx(host, username, password, change_number)

if __name__ == "__main__":
    main()

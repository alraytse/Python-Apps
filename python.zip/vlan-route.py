#!/usr/bin/env python3

import re
import getpass
import pandas as pd
from netmiko import ConnectHandler
from concurrent.futures import ThreadPoolExecutor, as_completed

# ==========================================================
# Prompt for Inputs
# ==========================================================

username = input("Username: ").strip()
password = getpass.getpass("Password: ")

switches = [
    x.strip()
    for x in input(
        "Enter comma-delimited switch list: "
    ).split(",")
    if x.strip()
]

vlan_id = input("Enter VLAN ID: ").strip()

results = []


def check_vlan(switch):
    result = {
        "Switch": switch,
        "VLAN": vlan_id,
        "SVI Exists": "No",
        "Routed": "No",
        "IP Address": "",
        "VRF": "",
        "Status": "Success"
    }

    try:
        device = {
            "device_type": "cisco_nxos",
            "host": switch,
            "username": username,
            "password": password,
            "fast_cli": False,
        }

        conn = ConnectHandler(**device)

        cmd = f"show running-config interface vlan {vlan_id}"
        output = conn.send_command(cmd)

        if "interface Vlan" in output:
            result["SVI Exists"] = "Yes"

            ip_match = re.search(
                r"ip address\s+(\S+)",
                output,
                re.IGNORECASE
            )

            if ip_match:
                result["Routed"] = "Yes"
                result["IP Address"] = ip_match.group(1)

            vrf_match = re.search(
                r"vrf member\s+(\S+)",
                output,
                re.IGNORECASE
            )

            if vrf_match:
                result["VRF"] = vrf_match.group(1)

        conn.disconnect()

    except Exception as e:
        result["Status"] = f"Failed: {str(e)}"

    return result


# ==========================================================
# Run Checks
# ==========================================================

with ThreadPoolExecutor(max_workers=10) as executor:
    futures = {
        executor.submit(check_vlan, sw): sw
        for sw in switches
    }

    for future in as_completed(futures):
        results.append(future.result())

# ==========================================================
# Save Report
# ==========================================================

df = pd.DataFrame(results)

outfile = f"vlan_{vlan_id}_routing_report.csv"
df.to_csv(outfile, index=False)

print("\n")
print("=" * 60)
print(df.to_string(index=False))
print("=" * 60)
print(f"\nReport saved: {outfile}")

# ==========================================================
# Summary
# ==========================================================

routed = df[df["Routed"] == "Yes"]

if not routed.empty:
    print("\nVLAN appears to be routed on:")
    for _, row in routed.iterrows():
        print(
            f"  {row['Switch']}  "
            f"IP={row['IP Address']}  "
            f"VRF={row['VRF']}"
        )
else:
    print("\nNo routed SVI found for this VLAN.")
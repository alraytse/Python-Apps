#!/usr/bin/env python3

"""
Prompt for device names and display them horizontally
in comma-delimited format.

Example Input:
DDC1-MAN-ASW1
DDC1-MAN-ASW2
DDC1-USON-DSW1

(blank line to finish)

Output:
DDC1-MAN-ASW1,DDC1-MAN-ASW2,DDC1-USON-DSW1
"""

def main():

    print("Enter device names (one per line).")
    print("Press Enter on a blank line when finished.\n")

    devices = []

    while True:

        device = input().strip()

        if not device:
            break

        devices.append(device)

    # Remove duplicates while preserving order
    unique_devices = list(dict.fromkeys(devices))

    print("\nComma-delimited list:\n")
    print(",".join(unique_devices))


if __name__ == "__main__":
    main()
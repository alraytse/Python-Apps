#!/usr/bin/env python3
import csv
import getpass
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from netmiko import ConnectHandler

INVENTORY_FILE = "network_inventory_report.csv"
NAT_RULES_FILE = "configured_nat_rules.csv"
NAT_INVENTORY_FILE = "nat_inventory_report.csv"
DEFAULT_WORKERS = 10

COMMANDS = [
    "show ip interface brief",
    "show ip nat translations",
    "show ip nat statistics",
    "show access-lists Viptela-Underlay-NAT",
    "show interfaces tunnel",
    "show sdwan vpn"
]

NAT_CONFIG_COMMANDS = [
    "show running-config | include ip nat",
    "show running-config | section ip nat",
    "show running-config | include overload",
    "show access-lists Viptela-Underlay-NAT"
]

NAT_RULE_FIELDS = ["Device","Platform","Rule_Type","Source","Translated_Source","Destination","Translated_Destination","Protocol","Original_Port","Translated_Port","Interface","Command","Details"]
NAT_INVENTORY_FIELDS = ["Device","Platform","Public_IP","Private_IP","NAT_Type","NAT_ACL","Outside_Interface","Protocol","Primary_External_Destination","Active_Internal_Hosts","Hits","Misses","Expired_Translations"]


def run_command(conn, command):
    try:
        return conn.send_command(command, read_timeout=120)
    except Exception:
        return ""


def connect_device(host, username, password):
    for device_type in ["cisco_nxos", "cisco_ios", "cisco_asa"]:
        try:
            conn = ConnectHandler(device_type=device_type, host=host, username=username, password=password, fast_cli=False)
            return conn, device_type
        except Exception:
            pass
    return None, None


def parse_nat_rule(line):
    data = {"Rule_Type":"PAT" if "overload" in line.lower() else "NAT","Source":"","Translated_Source":"","Destination":"","Translated_Destination":"","Protocol":"","Original_Port":"","Translated_Port":"","Interface":""}
    m = re.search(r"\b(tcp|udp|icmp)\b", line, re.I)
    if m:
        data["Protocol"] = m.group(1).upper()
    ips = re.findall(r"(?:\d{1,3}\.){3}\d{1,3}", line)
    if len(ips) > 0: data["Source"] = ips[0]
    if len(ips) > 1: data["Translated_Source"] = ips[1]
    i = re.search(r"interface\s+(\S+)", line, re.I)
    if i: data["Interface"] = i.group(1)
    return data


def collect_nat_rules(conn, hostname, platform):
    rows = []
    for cmd in NAT_CONFIG_COMMANDS:
        output = run_command(conn, cmd)
        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue
            p = parse_nat_rule(line)
            rows.append({"Device":hostname,"Platform":platform,**p,"Command":cmd,"Details":line})
    return rows


def collect_nat_inventory(conn, hostname, platform):
    trans = run_command(conn, "show ip nat translations")
    stats = run_command(conn, "show ip nat statistics")
    hits = misses = expired = nat_acl = outside = ""
    m = re.search(r"Hits:\s*(\d+)\s+Misses:\s*(\d+)", stats)
    if m:
        hits, misses = m.group(1), m.group(2)
    m = re.search(r"Expired translations:\s*(\d+)", stats)
    if m:
        expired = m.group(1)
    m = re.search(r"access-list\s+(\S+)\s+interface\s+(\S+)", stats, re.I)
    if m:
        nat_acl, outside = m.group(1), m.group(2)
    inv = {}
    pat = re.compile(r"^(icmp|tcp|udp)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)", re.I)
    for line in trans.splitlines():
        line=line.strip()
        m=pat.match(line)
        if not m: continue
        pub=m.group(2).split(':')[0]
        prv=m.group(3).split(':')[0]
        dst=m.group(4).split(':')[0]
        inv[(pub,prv)]={"Device":hostname,"Platform":platform,"Public_IP":pub,"Private_IP":prv,"NAT_Type":"PAT","NAT_ACL":nat_acl,"Outside_Interface":outside,"Protocol":m.group(1).upper(),"Primary_External_Destination":dst,"Hits":hits,"Misses":misses,"Expired_Translations":expired}
    count=len({r['Private_IP'] for r in inv.values()})
    rows=[]
    for r in inv.values():
        r['Active_Internal_Hosts']=count
        rows.append(r)
    return rows


def collect_device(host, username, password):
    conn, platform = connect_device(host, username, password)
    if not conn:
        return [], [], []
    try:
        hostname = conn.find_prompt().replace('#','').strip()
        inv=[]
        for cmd in COMMANDS:
            out=run_command(conn, cmd)
            if out:
                inv.append({"Device":hostname,"Platform":platform,"Command":cmd,"Output":out.replace('\n',' | ')})
        return inv, collect_nat_rules(conn, hostname, platform), collect_nat_inventory(conn, hostname, platform)
    finally:
        conn.disconnect()


def main():
    username=input('User ID: ')
    password=getpass.getpass('Password: ')
    hosts=[h.strip() for h in input('Enter hosts (comma separated): ').split(',') if h.strip()]
    workers_in=input(f'Workers [{DEFAULT_WORKERS}]: ').strip()
    workers=int(workers_in) if workers_in else DEFAULT_WORKERS
    inventory=[]; nat_rules=[]; nat_inventory=[]
    with ThreadPoolExecutor(max_workers=min(workers,10)) as ex:
        futures={ex.submit(collect_device,h,username,password):h for h in hosts}
        for f in as_completed(futures):
            i,nr,ni=f.result()
            inventory.extend(i); nat_rules.extend(nr); nat_inventory.extend(ni)
    with open(INVENTORY_FILE,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['Device','Platform','Command','Output']); w.writeheader(); w.writerows(inventory)
    with open(NAT_RULES_FILE,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=NAT_RULE_FIELDS); w.writeheader(); w.writerows(nat_rules)
    with open(NAT_INVENTORY_FILE,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=NAT_INVENTORY_FIELDS); w.writeheader(); w.writerows(nat_inventory)
    print('Created:', INVENTORY_FILE, NAT_RULES_FILE, NAT_INVENTORY_FILE)

if __name__ == '__main__':
    main()

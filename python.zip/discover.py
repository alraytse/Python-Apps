

#!/usr/bin/env python3
"""
Discover Cisco ASR devices starting from a seed IP using SNMP-based CDP/LLDP,
with optional Netmiko SSH fallback for neighbor discovery and device info.

Author: Alex-friendly build
"""

import argparse
import logging
import sys
import re
import json
import csv
from collections import deque
from typing import Dict, List, Optional, Tuple, Set

# --- SNMP deps ---

import asyncio
from pysnmp.hlapi.v3arch.asyncio import (
    SnmpEngine, CommunityData, UdpTransportTarget, ContextData,
    ObjectType, ObjectIdentity, get_cmd
)



# --- Netmiko deps ---
try:
    from netmiko import ConnectHandler
    from netmiko.ssh_autodetect import SSHDetect
except Exception:
    ConnectHandler = None
    SSHDetect = None

# --- Common OIDs ---
# System
OID_sysDescr     = '1.3.6.1.2.1.1.1.0'
OID_sysName      = '1.3.6.1.2.1.1.5.0'
OID_sysObjectID  = '1.3.6.1.2.1.1.2.0'

# ENTITY-MIB: entPhysicalModelName (string table)
OID_entPhysicalModelName = '1.3.6.1.2.1.47.1.1.1.1.13'

# CISCO-CDP-MIB (cdpCacheTable)
OID_cdpCacheAddress   = '1.3.6.1.4.1.9.9.23.1.2.1.1.4'
OID_cdpCacheDeviceId  = '1.3.6.1.4.1.9.9.23.1.2.1.1.6'
OID_cdpCachePlatform  = '1.3.6.1.4.1.9.9.23.1.2.1.1.16'

# LLDP-MIB
OID_lldpRemManAddrOID = '1.0.8802.1.1.2.1.4.2.1.4'

# ------------------ SNMP helpers ------------------

def build_auth(args):
    if args.snmp_version == '2c':
        return CommunityData(args.community, mpModel=1)
    else:
        from pysnmp.hlapi import (
            usmNoAuthProtocol,
            usmNoPrivProtocol,
            usmHMACMD5AuthProtocol,
            usmHMACSHAAuthProtocol,
            usmDESPrivProtocol,
            usmAESPrivProtocol,
            usmAES128PrivProtocol,
            usmAES256PrivProtocol,
        )
        auth_map = {
            'MD5': usmHMACMD5AuthProtocol,
            'SHA': usmHMACSHAAuthProtocol,
        }
        priv_map = {
            'DES': usmDESPrivProtocol,
            'AES': usmAESPrivProtocol,
            'AES128': usmAES128PrivProtocol,
            'AES256': usmAES256PrivProtocol,
        }
        auth_proto_obj = auth_map.get(args.auth, usmNoAuthProtocol)
        priv_proto_obj = priv_map.get(args.priv, usmNoPrivProtocol)
        return UsmUserData(
            args.user or '',
            args.authpass or None,
            args.privpass or None,
            authProtocol=auth_proto_obj,
            privProtocol=priv_proto_obj
        )

def snmp_get(ip: str, auth, oid: str, timeout: int, retries: int) -> Optional[str]:
    try:
        iterator = getCmd(
            SnmpEngine(),
            auth,
            UdpTransportTarget((ip, 161), timeout=timeout, retries=retries),
            ContextData(),
            ObjectType(ObjectIdentity(oid))
        )
        errorIndication, errorStatus, errorIndex, varBinds = next(iterator)
        if errorIndication or errorStatus:
            return None
        return str(varBinds[0][1])
    except Exception as e:
        logging.debug(f"SNMP GET failure on {ip} {oid}: {e}")
        return None

def snmp_walk(ip: str, auth, oid: str, timeout: int, retries: int) -> List[Tuple[str, str]]:
    results = []
    try:
        for (errorIndication, errorStatus, errorIndex, varBinds) in nextCmd(
            SnmpEngine(),
            auth,
            UdpTransportTarget((ip, 161), timeout=timeout, retries=retries),
            ContextData(),
            ObjectType(ObjectIdentity(oid)),
            lexicographicMode=False
        ):
            if errorIndication or errorStatus:
                break
            for oid_obj, val in varBinds:
                results.append((str(oid_obj), val.prettyPrint()))
    except Exception as e:
        logging.debug(f"SNMP WALK failure on {ip} {oid}: {e}")
    return results

def _parse_cdp_ipv4(octet_str: str) -> Optional[str]:
    if not octet_str:
        return None
    if re.match(r'^\d+\.\d+\.\d+\.\d+$', octet_str):
        return octet_str
    hexm = re.match(r'^0x([0-9A-Fa-f]+)$', octet_str)
    if hexm:
        hexbytes = hexm.group(1)
        if len(hexbytes) >= 8:
            b = bytes.fromhex(hexbytes[-8:])
            return '.'.join(str(x) for x in b)
    return None

def _parse_lldp_mgmt_addr(octet_str: str) -> Optional[str]:
    if not octet_str:
        return None
    if re.match(r'^\d+\.\d+\.\d+\.\d+$', octet_str):
        return octet_str
    hexm = re.match(r'^0x([0-9A-Fa-f]+)$', octet_str)
    if hexm:
        hb = hexm.group(1)
        if len(hb) >= 8:
            b = bytes.fromhex(hb[-8:])
            return '.'.join(str(x) for x in b)
    return None

def get_device_info_snmp(ip: str, auth, timeout: int, retries: int) -> Dict[str, Optional[str]]:
    info = {
        'ip': ip,
        'sysName': snmp_get(ip, auth, OID_sysName, timeout, retries),
        'sysDescr': snmp_get(ip, auth, OID_sysDescr, timeout, retries),
        'sysObjectID': snmp_get(ip, auth, OID_sysObjectID, timeout, retries),
        'model': None
    }
    ent_models = snmp_walk(ip, auth, OID_entPhysicalModelName, timeout, retries)
    candidates = [v for _, v in ent_models if v]
    if candidates:
        info['model'] = sorted(candidates, key=lambda s: len(s), reverse=True)[0]
    return info

# ------------------ Netmiko (SSH) helpers ------------------

def connect_ssh(ip: str, args):
    if ConnectHandler is None:
        logging.debug("Netmiko not available; install 'netmiko' to use SSH fallback.")
        return None
    device_type = args.ssh_device_type
    if device_type == 'auto':
        if SSHDetect is None:
            logging.debug("SSHDetect unavailable; falling back to cisco_ios.")
            device_type = 'cisco_ios'
        else:
            try:
                det = SSHDetect(
                    host=ip,
                    username=args.ssh_user,
                    password=args.ssh_pass,
                    key_file=args.ssh_key,
                    timeout=args.ssh_timeout,
                    banner_timeout=args.ssh_timeout,
                )
                device_type = det.autodetect() or 'cisco_ios'
                logging.debug(f"Autodetected device_type for {ip}: {device_type}")
            except Exception as e:
                logging.debug(f"SSH autodetect failed for {ip}: {e}; using cisco_ios")
                device_type = 'cisco_ios'

    params = {
        'device_type': device_type,
        'host': ip,
        'username': args.ssh_user,
        'password': args.ssh_pass,
        'key_file': args.ssh_key,
        'fast_cli': True,
        'timeout': args.ssh_timeout,
        'banner_timeout': args.ssh_timeout,
        'conn_timeout': args.ssh_timeout
    }
    try:
        conn = ConnectHandler(**params)
        if args.ssh_enable:
            try:
                conn.enable()
            except Exception as e:
                logging.debug(f"Enable mode failed on {ip}: {e}")
        return conn
    except Exception as e:
        logging.debug(f"SSH connection failed for {ip}: {e}")
        return None

def _ssh_cmd(conn, cmd: str) -> str:
    try:
        return conn.send_command(cmd, use_textfsm=False, read_timeout=30) or ""
    except Exception as e:
        logging.debug(f"SSH command failed '{cmd}': {e}")
        return ""

def parse_cdp_neighbors_detail(output: str) -> List[Dict[str, Optional[str]]]:
    """
    Parses 'show cdp neighbors detail' (IOS/IOS-XE/XR where available).
    Returns list of dicts: {ip, via, name, platform}
    """
    neighbors = []
    if not output:
        return neighbors

    # Each neighbor section often contains Device ID, Entry address(es), Platform
    sections = re.split(r'\n-{5,}\n|\nDevice ID:', output)
    for sec in sections:
        # IPs
        ips = set(re.findall(r'IP address:\s*([\d\.]+)', sec, flags=re.IGNORECASE))
        if not ips:
            # Some outputs: "IPv4 Address: ..."
            ips = set(re.findall(r'IPv4 Address:\s*([\d\.]+)', sec, flags=re.IGNORECASE))
        if not ips:
            continue
        name_match = re.search(r'Device ID:\s*(.+)', sec)
        plat_match = re.search(r'Platform:\s*([^,\r\n]+)', sec)
        for ip in ips:
            neighbors.append({
                'ip': ip,
                'via': 'CDP(SSH)',
                'name': name_match.group(1).strip() if name_match else None,
                'platform': plat_match.group(1).strip() if plat_match else None
            })
    return neighbors

def parse_lldp_neighbors_detail(output: str) -> List[Dict[str, Optional[str]]]:
    """
    Parses 'show lldp neighbors detail' (IOS/IOS-XE and XR).
    Returns list of dicts: {ip, via, name, platform}
    """
    neighbors = []
    if not output:
        return neighbors

    # Split per neighbor by blank lines with "Local Intf"/"Interface"
    chunks = re.split(r'\n\s*\n', output)
    for ch in chunks:
        # Management Address lines are common
        ips = set(re.findall(r'Management Address:\s*([\d\.]+)', ch, flags=re.IGNORECASE))
        if not ips:
            ips = set(re.findall(r'Mgmt Address:\s*([\d\.]+)', ch, flags=re.IGNORECASE))
        if not ips:
            continue
        name = None
        # SysName or Chassis ID sometimes present
        m_name = re.search(r'System Name:\s*(.+)', ch, flags=re.IGNORECASE)
        if not m_name:
            m_name = re.search(r'Remote System Name:\s*(.+)', ch, flags=re.IGNORECASE)
        if m_name:
            name = m_name.group(1).strip()
        # LLDP doesn't usually include platform; optional
        for ip in ips:
            neighbors.append({
                'ip': ip,
                'via': 'LLDP(SSH)',
                'name': name,
                'platform': None
            })
    return neighbors

def get_neighbors_ssh(conn) -> List[Dict[str, Optional[str]]]:
    n_all = []
    cdp_out = _ssh_cmd(conn, "show cdp neighbors detail")
    n_all.extend(parse_cdp_neighbors_detail(cdp_out))
    lldp_out = _ssh_cmd(conn, "show lldp neighbors detail")
    n_all.extend(parse_lldp_neighbors_detail(lldp_out))

    # Dedup by IP
    dedup = []
    seen = set()
    for n in n_all:
        if n['ip'] and n['ip'] not in seen:
            dedup.append(n)
            seen.add(n['ip'])
    return dedup

def get_device_info_ssh(conn, ip: str) -> Dict[str, Optional[str]]:
    """
    Best-effort device info via SSH:
    - sysName: from running-config hostname
    - model: from show inventory PID or show version platform
    - sysDescr: first lines of show version
    - sysObjectID: not available via CLI -> None
    """
    sys_descr = ""
    model = None
    name = None

    ver_out = _ssh_cmd(conn, "show version")
    inv_out = _ssh_cmd(conn, "show inventory")

    # sysDescr
    if ver_out:
        # Take first 3 lines to form a description
        lines = [l.strip() for l in ver_out.splitlines() if l.strip()]
        sys_descr = "; ".join(lines[:3])

    # model from inventory PID or platform text
    m_pid = re.search(r'PID:\s*([\w\-]+)', inv_out or "", flags=re.IGNORECASE)
    if m_pid:
        model = m_pid.group(1)
    else:
        m_plat = re.search(r'(ASR\d{3,4}\S*|ASR\s*9K\S*|ASR\s*9000\S*)', ver_out or "", flags=re.IGNORECASE)
        if m_plat:
            model = m_plat.group(1)

    # sysName
    rc_out = _ssh_cmd(conn, "show running-config | include ^hostname")
    m_host = re.search(r'hostname\s+(\S+)', rc_out or "", flags=re.IGNORECASE)
    if not m_host:
        # IOS-XR alternative
        rc_out = _ssh_cmd(conn, "show running-config | include hostname")
        m_host = re.search(r'hostname\s+(\S+)', rc_out or "", flags=re.IGNORECASE)
    if m_host:
        name = m_host.group(1)

    return {
        'ip': ip,
        'sysName': name,
        'sysDescr': sys_descr or None,
        'sysObjectID': None,
        'model': model
    }

# ------------------ Classification ------------------

_ASR_PATTERN = re.compile(
    r'\bASR\s?(1000|9K|9000|920|903|9900|9904|9010|9922|9006|9001)\b',
    re.IGNORECASE
)

def is_asr(info: Dict[str, Optional[str]]) -> bool:
    text = ' '.join([t for t in [info.get('sysDescr'), info.get('model')] if t])
    if _ASR_PATTERN.search(text or ''):
        return True
    if text and 'ASR' in text.upper():
        return True
    if (info.get('sysObjectID') or '').startswith('1.3.6.1.4.1.9'):
        return _ASR_PATTERN.search(text or '') is not None
    return False

# ------------------ Neighbor discovery (SNMP) ------------------

def get_neighbors_snmp(ip: str, auth, timeout: int, retries: int) -> List[Dict[str, Optional[str]]]:
    neighbors: List[Dict[str, Optional[str]]] = []

    # CDP
    for oid, addr_val in snmp_walk(ip, auth, OID_cdpCacheAddress, timeout, retries):
        ip_candidate = _parse_cdp_ipv4(addr_val)
        if ip_candidate:
            neighbors.append({'ip': ip_candidate, 'via': 'CDP', 'name': None, 'platform': None})

    # LLDP Mgmt Addresses
    for oid, addr_val in snmp_walk(ip, auth, OID_lldpRemManAddrOID, timeout, retries):
        ip_candidate = _parse_lldp_mgmt_addr(addr_val)
        if ip_candidate:
            neighbors.append({'ip': ip_candidate, 'via': 'LLDP', 'name': None, 'platform': None})

    # Dedup
    dedup = []
    seen = set()
    for n in neighbors:
        if n['ip'] and n['ip'] not in seen:
            dedup.append(n)
            seen.add(n['ip'])
    return dedup

# ------------------ BFS core ------------------

def discover(seed_ips: List[str], args, auth) -> Tuple[Dict[str, Dict], List[Tuple[str, str, str]]]:
    """
    BFS discovery combining SNMP and SSH according to args.
    Returns:
    - devices: map ip -> device_info dict (with ASR classification)
    - edges: list of (parent_ip, neighbor_ip, via)
    """
    devices: Dict[str, Dict] = {}
    edges: List[Tuple[str, str, str]] = []

    queue = deque([(seed, 0) for seed in seed_ips])
    visited: Set[str] = set()

    while queue:
        ip, depth = queue.popleft()
        if ip in visited:
            continue
        visited.add(ip)
        logging.info(f"Querying device {ip} at depth {depth}")

        info = {'ip': ip, 'sysName': None, 'sysDescr': None, 'sysObjectID': None, 'model': None}

        neighbors: List[Dict[str, Optional[str]]] = []

        # --- SNMP phase ---
        if not args.ssh_only:
            try:
                info_snmp = get_device_info_snmp(ip, auth, args.timeout, args.retries)
                info.update({k: v for k, v in info_snmp.items() if v})
                neighbors = get_neighbors_snmp(ip, auth, args.timeout, args.retries)
            except Exception as e:
                logging.debug(f"SNMP discovery failed on {ip}: {e}")

        # --- SSH fallback / SSH-only ---
        need_ssh = args.ssh_only or (args.ssh_fallback and not neighbors)
        conn = None
        if need_ssh:
            conn = connect_ssh(ip, args)
            if conn:
                try:
                    info_ssh = get_device_info_ssh(conn, ip)
                    # Fill missing fields only; trust SNMP when available
                    for k, v in info_ssh.items():
                        if not info.get(k) and v:
                            info[k] = v
                    ssh_neighbors = get_neighbors_ssh(conn)
                    if ssh_neighbors:
                        neighbors = ssh_neighbors  # prefer SSH neighbors when SNMP failed/empty
                finally:
                    try:
                        conn.disconnect()
                    except Exception:
                        pass
            else:
                logging.debug(f"SSH not available for {ip}")

        info['isASR'] = is_asr(info)
        devices[ip] = info

        if depth >= args.max_depth:
            continue

        # Queue neighbors
        for n in neighbors:
            nip = n.get('ip')
            if not nip:
                continue
            edges.append((ip, nip, n.get('via') or 'unknown'))
            if nip not in visited:
                queue.append((nip, depth + 1))

    return devices, edges

# ------------------ Output helpers ------------------

def save_csv(path: str, devices: Dict[str, Dict], edges: List[Tuple[str, str, str]]) -> None:
    with open(path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['type', 'ip', 'neighbor_ip', 'via', 'sysName', 'model', 'sysDescr', 'sysObjectID', 'isASR'])
        for ip, d in devices.items():
            w.writerow(['device', ip, '', '', d.get('sysName'), d.get('model'), d.get('sysDescr'), d.get('sysObjectID'), d.get('isASR')])
        for u, v, via in edges:
            w.writerow(['edge', u, v, via, '', '', '', '', ''])

# ------------------ CLI ------------------

def main():
    parser = argparse.ArgumentParser(description="Discover Cisco ASR devices via SNMP with Netmiko SSH fallback (CDP/LLDP BFS).")
    parser.add_argument('--seed', nargs='+', required=True, help='Seed IPv4 address(es) to start discovery.')

    # SNMP
    parser.add_argument('--snmp-version', choices=['2c', '3'], default='2c', help='SNMP version (default: 2c)')
    parser.add_argument('-c', '--community', default='public', help='SNMPv2c community')
    parser.add_argument('--user', help='SNMPv3 user')
    parser.add_argument('--auth', choices=['MD5', 'SHA'], default='SHA', help='SNMPv3 auth protocol')
    parser.add_argument('--authpass', help='SNMPv3 auth password')
    parser.add_argument('--priv', choices=['DES', 'AES', 'AES128', 'AES256'], default='AES', help='SNMPv3 privacy protocol')
    parser.add_argument('--privpass', help='SNMPv3 privacy password')
    parser.add_argument('--timeout', type=int, default=2, help='SNMP timeout seconds (per request)')
    parser.add_argument('--retries', type=int, default=1, help='SNMP retries')

    # SSH (Netmiko)
    parser.add_argument('--ssh-fallback', action='store_true', help='Use SSH fallback when SNMP has no neighbors.')
    parser.add_argument('--ssh-only', action='store_true', help='Discover via SSH only (skip SNMP).')
    parser.add_argument('--ssh-user', help='SSH username')
    parser.add_argument('--ssh-pass', help='SSH password')
    parser.add_argument('--ssh-key', help='SSH private key file path')
    parser.add_argument('--ssh-enable', action='store_true', help='Enter enable mode after SSH login (IOS/IOS-XE).')
    parser.add_argument('--ssh-device-type', choices=['auto', 'cisco_ios', 'cisco_xr'], default='auto', help='Netmiko device_type (default: auto)')
    parser.add_argument('--ssh-timeout', type=int, default=10, help='SSH connect timeout seconds')

    # BFS / outputs
    parser.add_argument('--max-depth', type=int, default=3, help='Max neighbor depth to explore')
    parser.add_argument('--csv', help='Save discovery results to CSV path')
    parser.add_argument('--json', help='Save discovery results to JSON path')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s'
    )

    auth = build_auth(args) if not args.ssh_only else None

    devices, edges = discover(args.seed, args, auth)

    # Print summary
    print("\n=== Devices Discovered ===")
    for ip, d in devices.items():
        flag = "ASR" if d.get('isASR') else "-"
        name = d.get('sysName') or ''
        model = d.get('model') or ''
        print(f"{ip:15} [{flag}]  {name:25}  {model}")

    print("\n=== Edges (parent -> neighbor via) ===")
    for u, v, via in edges:
        print(f"{u} -> {v}  ({via})")

    if args.csv:
        save_csv(args.csv, devices, edges)
        print(f"\nCSV written: {args.csv}")

    if args.json:
        with open(args.json, 'w') as jf:
            json.dump({'devices': devices, 'edges': edges}, jf, indent=2)
        print(f"JSON written: {args.json}")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(1)

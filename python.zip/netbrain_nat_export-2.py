#!/usr/bin/env python3
"""
netbrain_nat_export.py

Logs into a NetBrain server, pulls the list of devices in a given site
(default: "ddc1"), retrieves each device's NAT/PAT configuration via
the NetBrain DeviceRawData API (CLI passthrough), and writes the
results to a CSV file.

SECURITY NOTE:
Credentials are entered interactively at runtime (password is hidden
via getpass) and are never hardcoded or logged to disk.

Usage:
    python3 netbrain_nat_export.py
    python3 netbrain_nat_export.py --server https://netbrain.mycompany.com --site ddc1 --output nat_export.csv

Requirements:
    pip install requests --break-system-packages   # if not already installed
"""

import argparse
import csv
import getpass
import json
import sys

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def login(server, username, password, verify_ssl, force_forwarded_proto=False, debug=False):
    """Authenticate and return a session token."""
    url = f"{server}/ServicesAPI/API/V1/Session"
    body = {"username": username, "password": password}
    headers = {"Content-Type": "application/json", "Accept": "application/json"}

    # Some NetBrain deployments sit behind a reverse proxy/load balancer that
    # terminates TLS and forwards this header to the backend. If the backend
    # rejects direct HTTPS requests with "HTTPS protocol is required", try
    # sending this header explicitly.
    if force_forwarded_proto:
        headers["X-Forwarded-Proto"] = "https"
        headers["X-Forwarded-Ssl"] = "on"

    resp = requests.post(
        url, headers=headers, data=json.dumps(body), verify=verify_ssl, allow_redirects=False
    )

    if debug:
        print(f"[DEBUG] Request URL: {url}")
        print(f"[DEBUG] Request headers: {headers}")
        print(f"[DEBUG] Response status: {resp.status_code}")
        print(f"[DEBUG] Response headers: {dict(resp.headers)}")
        print(f"[DEBUG] Response body: {resp.text[:1000]}")

    if resp.status_code in (301, 302, 303, 307, 308):
        raise RuntimeError(
            f"Login was redirected (HTTP {resp.status_code}) to: "
            f"{resp.headers.get('Location')}. The request may be getting "
            f"downgraded to HTTP somewhere in the network path."
        )

    if resp.status_code != 200:
        raise RuntimeError(f"Login failed: HTTP {resp.status_code} - {resp.text}")

    data = resp.json()
    token = data.get("token")
    if not token:
        raise RuntimeError(f"Login response did not contain a token: {data}")
    return token


def logout(server, token, verify_ssl):
    """Log out and invalidate the session token."""
    url = f"{server}/ServicesAPI/API/V1/Session"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    try:
        requests.delete(url, headers=headers, verify=verify_ssl)
    except requests.RequestException:
        # Non-fatal; token will simply expire server-side.
        pass


def get_site_devices(server, token, site_path, verify_ssl):
    """Return list of devices (hostname, mgmt IP) for the given site path."""
    url = f"{server}/ServicesAPI/API/V1/CMDB/Sites/Devices"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    params = {"sitePath": site_path}

    resp = requests.get(url, headers=headers, params=params, verify=verify_ssl)
    if resp.status_code != 200:
        raise RuntimeError(f"Get site devices failed: HTTP {resp.status_code} - {resp.text}")

    data = resp.json()
    devices = data.get("devices") or data.get("Devices") or []
    return devices


def get_devices_by_hostname_prefix(server, token, prefix, verify_ssl, page_size=200):
    """
    Pull the full device inventory (paginated) and filter client-side by
    hostname prefix. This sidesteps NetBrain's Site hierarchy entirely,
    which is useful when devices follow a naming convention (e.g.
    'DDC1-B2B-FW5') rather than living under a Site object with that
    exact path.
    """
    url = f"{server}/ServicesAPI/API/V1/CMDB/Devices"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}

    all_devices = []
    skip = 0
    while True:
        params = {"version": 1, "skip": skip, "limit": page_size}
        resp = requests.get(url, headers=headers, params=params, verify=verify_ssl)
        if resp.status_code != 200:
            raise RuntimeError(f"Get devices failed: HTTP {resp.status_code} - {resp.text}")

        data = resp.json()
        batch = data.get("devices", [])
        all_devices.extend(batch)

        total = data.get("total")
        skip += page_size
        if len(batch) < page_size:
            break
        if total is not None and skip >= total:
            break

    prefix_lower = prefix.lower()
    matched = [
        d for d in all_devices
        if (d.get("name") or d.get("hostname") or "").lower().startswith(prefix_lower)
    ]
    return matched


def get_device_nat_data(server, token, hostname, verify_ssl, cmd="show running nat-policy"):
    """
    Pull raw NAT policy output from a device via the DeviceRawData API
    (CLI passthrough, dataType=2).

    For Palo Alto firewalls, "show running nat-policy" returns the
    active NAT rulebase. Adjust `cmd` for other platforms, e.g.:
      - Cisco IOS:  "show ip nat translations"
      - Cisco ASA:  "show nat"
      - Palo Alto:  "show running nat-policy"
    """
    url = f"{server}/ServicesAPI/API/V1/CMDB/Devices/DeviceRawData"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    params = {
        "hostname": hostname,
        "dataType": 2,   # 2 = CLI command
        "cmd": cmd,
    }

    resp = requests.get(url, headers=headers, params=params, verify=verify_ssl)
    if resp.status_code != 200:
        return f"ERROR: HTTP {resp.status_code} - {resp.text}"

    data = resp.json()
    return data.get("content", "")


def main():
    parser = argparse.ArgumentParser(description="Export NAT/PAT data from NetBrain to CSV")
    parser.add_argument("--server", help="NetBrain server URL, e.g. https://netbrain.mycompany.com")
    parser.add_argument("--site", default=None,
                         help="Full NetBrain site path, e.g. 'My Network/Region/DDC1'. "
                              "Only used if --hostname-prefix is not what you want.")
    parser.add_argument("--hostname-prefix", default="ddc1",
                         help="Filter devices by hostname prefix instead of Site path "
                              "(default: 'ddc1', matching names like DDC1-B2B-FW5)")
    parser.add_argument("--output", default="nat_export.csv", help="Output CSV filename")
    parser.add_argument("--cmd", default="show running nat-policy",
                         help="CLI command used to pull NAT data (default is Palo Alto's NAT policy command)")
    parser.add_argument("--insecure", action="store_true",
                         help="Skip SSL certificate verification (use only if your NetBrain server uses a self-signed cert)")
    parser.add_argument("--force-forwarded-proto", action="store_true",
                         help="Send X-Forwarded-Proto/X-Forwarded-Ssl headers (workaround for 'HTTPS protocol is required' errors behind some load balancers)")
    parser.add_argument("--debug", action="store_true",
                         help="Print raw request/response details for troubleshooting login issues")
    args = parser.parse_args()

    server = args.server or input("NetBrain server URL (e.g. https://netbrain.mycompany.com): ").strip()
    server = server.rstrip("/")

    username = input("NetBrain username: ").strip()
    password = getpass.getpass("NetBrain password: ")

    verify_ssl = not args.insecure

    print(f"\nLogging into {server} ...")
    try:
        token = login(
            server, username, password, verify_ssl,
            force_forwarded_proto=args.force_forwarded_proto,
            debug=args.debug,
        )
    except Exception as e:
        print(f"Login failed: {e}")
        sys.exit(1)
    print("Login successful.")

    try:
        if args.site:
            print(f"Retrieving devices for site '{args.site}' ...")
            devices = get_site_devices(server, token, args.site, verify_ssl)
            if not devices:
                print(f"No devices found for site '{args.site}'. Check the site name/path and try again.")
                sys.exit(1)
        else:
            print(f"Retrieving devices with hostname prefix '{args.hostname_prefix}' ...")
            devices = get_devices_by_hostname_prefix(server, token, args.hostname_prefix, verify_ssl)
            if not devices:
                print(f"No devices found with hostname prefix '{args.hostname_prefix}'.")
                sys.exit(1)
        print(f"Found {len(devices)} device(s).")

        rows = []
        for dev in devices:
            hostname = dev.get("hostname") or dev.get("name")
            mgmt_ip = dev.get("mgmtIP") or dev.get("mgmtIp") or dev.get("mgmtIP", "")
            print(f"  Pulling NAT data for {hostname} ...")
            nat_output = get_device_nat_data(server, token, hostname, verify_ssl, cmd=args.cmd)
            rows.append({
                "hostname": hostname,
                "mgmt_ip": mgmt_ip,
                "command_used": args.cmd,
                "nat_output": nat_output,
            })

        with open(args.output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["hostname", "mgmt_ip", "command_used", "nat_output"])
            writer.writeheader()
            writer.writerows(rows)

        print(f"\nDone. Wrote {len(rows)} row(s) to {args.output}")

    finally:
        logout(server, token, verify_ssl)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
check_firewall_connectivity.py

Tests basic TCP reachability (no auth, no API calls) to a list of hosts
on given ports -- useful for confirming whether the machine you're
running from actually has a network path to the firewall management
subnets before trying to run the full NAT export.

Usage examples:
    # Test all firewalls from a previous NetBrain export CSV, port 443:
    python3 check_firewall_connectivity.py --from-netbrain-csv nat_export.csv

    # Test explicit hosts on both 443 and 22:
    python3 check_firewall_connectivity.py --hosts 10.7.30.161,10.7.30.162 --ports 443,22

Requirements: none beyond the Python standard library.
"""

import argparse
import csv
import re
import socket
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

MAX_WORKERS = 20
DEFAULT_TIMEOUT = 5  # seconds


def load_hosts_from_netbrain_csv(path):
    """Read a NetBrain export CSV and return a deduped list of (name, ip)."""
    seen = {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            hostname = row.get("hostname", "")
            mgmt_ip = row.get("mgmt_ip", "")
            if not hostname or not mgmt_ip:
                continue
            if "fw" not in hostname.lower():
                continue
            base_hostname = re.sub(r"/vsys\d+$", "", hostname, flags=re.IGNORECASE)
            seen[mgmt_ip] = base_hostname
    return [(name, ip) for ip, name in seen.items()]


def check_port(host, port, timeout=DEFAULT_TIMEOUT):
    """Return (reachable: bool, detail: str) for a single host:port TCP check."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True, "open"
    except socket.timeout:
        return False, "timed out"
    except ConnectionRefusedError:
        return False, "connection refused (host reachable, port closed)"
    except OSError as e:
        return False, str(e)


def main():
    parser = argparse.ArgumentParser(description="Check TCP reachability to a list of firewalls")
    parser.add_argument("--from-netbrain-csv", default=None,
                         help="Load host list from a previous NetBrain export CSV")
    parser.add_argument("--hosts", default=None,
                         help="Comma-separated list of hostnames/IPs to test")
    parser.add_argument("--ports", default="443",
                         help="Comma-separated list of ports to test per host (default: 443)")
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT,
                         help=f"Per-connection timeout in seconds (default: {DEFAULT_TIMEOUT})")
    args = parser.parse_args()

    hosts = []
    if args.from_netbrain_csv:
        hosts = load_hosts_from_netbrain_csv(args.from_netbrain_csv)
    elif args.hosts:
        for item in args.hosts.split(","):
            item = item.strip()
            if item:
                hosts.append((item, item))
    else:
        raw = input("Hostnames/IPs (comma-separated): ").strip()
        for item in raw.split(","):
            item = item.strip()
            if item:
                hosts.append((item, item))

    if not hosts:
        print("No hosts to check.")
        sys.exit(1)

    ports = [int(p.strip()) for p in args.ports.split(",") if p.strip()]

    print(f"Checking {len(hosts)} host(s) on port(s) {ports} (timeout={args.timeout}s each) ...\n")

    jobs = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {}
        for name, ip in hosts:
            for port in ports:
                fut = executor.submit(check_port, ip, port, args.timeout)
                futures[fut] = (name, ip, port)

        results = []
        for fut in as_completed(futures):
            name, ip, port = futures[fut]
            reachable, detail = fut.result()
            results.append((name, ip, port, reachable, detail))

    # Sort for readable output: by host name, then port
    results.sort(key=lambda r: (r[0], r[2]))

    reachable_count = 0
    print(f"{'FIREWALL':<20} {'IP':<16} {'PORT':<6} {'RESULT':<10} DETAIL")
    print("-" * 80)
    for name, ip, port, reachable, detail in results:
        status = "OPEN" if reachable else "CLOSED"
        if reachable:
            reachable_count += 1
        print(f"{name:<20} {ip:<16} {port:<6} {status:<10} {detail}")

    total = len(results)
    print(f"\n{reachable_count}/{total} checks succeeded.")
    if reachable_count == 0:
        print("\nNone reachable -- this confirms a network routing issue from this machine, "
              "not a firewall-side or credential issue. You'll need to run from a host that "
              "has a route to this management network (jump host, VPN with the right route, etc.).")
    elif reachable_count < total:
        print("\nSome hosts/ports are reachable and others aren't -- this could mean partial "
              "routing, a per-device ACL, or a mix of correct/incorrect IPs. Worth comparing "
              "which specific hosts failed against your network team.")
    else:
        print("\nAll reachable! You should be able to run paloalto_nat_export.py from this "
              "machine now.")


if __name__ == "__main__":
    main()

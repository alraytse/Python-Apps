#!/usr/bin/env python3

import csv
import getpass
import ipaddress
import logging
import platform
import re
import subprocess
from netmiko import ConnectHandler

OUTPUT_CSV = "subnet_report.csv"
LOG_FILE = "subnet_audit.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    handlers=[logging.FileHandler(LOG_FILE), logging.StreamHandler()]
)


def ping_ip(ip):
    flag = '-n' if platform.system().lower() == 'windows' else '-c'
    try:
        result = subprocess.run(['ping', flag, '1', str(ip)], capture_output=True, text=True, timeout=2)
        return result.returncode == 0
    except Exception:
        return False


def subnet_reachable(subnet):
    checked = 0
    for host in subnet.hosts():
        if ping_ip(host):
            return True
        checked += 1
        if checked >= 5:
            break
    return False


def find_subnet_info(conn, subnet, device):
    next_hop = ''
    route_type = ''
    interface = ''
    vlan_id = ''
    vlan_name = ''
    vlan_description = ''
    description = ''

    try:
        route_output = conn.send_command(f'show ip route {subnet.network_address}')

        direct_match = re.search(r'directly connected,\s+via\s+(\S+)', route_output, re.I)

        if direct_match:
            route_type = 'Connected'
            interface = direct_match.group(1)
        else:
            nh_match = re.search(r'\*\s+(\d+\.\d+\.\d+\.\d+)', route_output)
            if nh_match:
                next_hop = nh_match.group(1)
                route_type = 'Remote'

                nh_output = conn.send_command(f'show ip route {next_hop}')
                int_match = re.search(r'directly connected,\s+via\s+(\S+)', nh_output, re.I)
                if int_match:
                    interface = int_match.group(1)

        vlan_match = re.search(r'Vlan(\d+)', interface, re.I)
        if vlan_match:
            vlan_id = vlan_match.group(1)

        if interface:
            try:
                desc_output = conn.send_command(f'show interface {interface} description')
                for line in desc_output.splitlines():
                    if interface.lower() in line.lower():
                        parts = line.split()
                        if len(parts) > 3:
                            description = ' '.join(parts[3:])
                        break
            except Exception:
                pass

            try:
                run_output = conn.send_command(f'show running-config interface {interface}')
                m = re.search(r'^\s*description\s+(.+)$', run_output, re.MULTILINE | re.I)
                if m:
                    vlan_description = m.group(1).strip()
            except Exception:
                pass

        if vlan_id:
            try:
                vlan_output = conn.send_command(f'show vlan id {vlan_id}')
                for line in vlan_output.splitlines():
                    if re.match(rf'^{vlan_id}\s+', line.strip()):
                        cols = line.split()
                        if len(cols) > 1:
                            vlan_name = cols[1]
                        break
            except Exception:
                pass

    except Exception:
        logging.exception(f'{device}: route lookup failed')

    return next_hop, route_type, interface, vlan_id, vlan_name, vlan_description, description


def count_arp_entries(conn, subnet, device):
    count = 0
    try:
        output = conn.send_command('show ip arp')
        for line in output.splitlines():
            for ip in re.findall(r'\d+\.\d+\.\d+\.\d+', line):
                try:
                    if ipaddress.ip_address(ip) in subnet:
                        count += 1
                except Exception:
                    pass
    except Exception:
        logging.exception(f'{device}: arp lookup failed')
    return count


def get_neighbors(conn, interface, device):
    neigh = set()
    try:
        output = conn.send_command(f'show cdp neighbors {interface} detail')
        neigh.update(re.findall(r'Device ID:\s+(\S+)', output, re.I))
    except Exception:
        pass

    if not neigh:
        try:
            output = conn.send_command(f'show lldp neighbors {interface} detail')
            neigh.update(re.findall(r'System Name:\s+(\S+)', output, re.I))
        except Exception:
            pass

    return ', '.join(sorted(neigh))


def main():
    start_subnet = input('Starting subnet/mask: ').strip()
    end_subnet = input('Ending subnet/mask: ').strip()
    hosts = input('Hostnames (comma delimited): ').strip()
    username = input('Username: ')
    password = getpass.getpass('Password: ')

    start_net = ipaddress.ip_network(start_subnet, strict=False)
    end_net = ipaddress.ip_network(end_subnet, strict=False)

    devices = [h.strip() for h in hosts.split(',') if h.strip()]
    results = []

    current = int(start_net.network_address)
    end = int(end_net.network_address)

    while current <= end:
        subnet = ipaddress.ip_network(f'{ipaddress.ip_address(current)}/{start_net.prefixlen}', strict=False)
        reachable = subnet_reachable(subnet)

        for device in devices:
            try:
                conn = ConnectHandler(device_type='cisco_ios', host=device, username=username, password=password)

                next_hop, route_type, interface, vlan_id, vlan_name, vlan_description, description = find_subnet_info(conn, subnet, device)
                arp_count = count_arp_entries(conn, subnet, device)
                neighbors = get_neighbors(conn, interface, device) if interface else ''

                results.append({
                    'Subnet': str(subnet),
                    'Switch': device,
                    'Next Hop': next_hop,
                    'Route Type': route_type,
                    'Interface': interface,
                    'VLAN ID': vlan_id,
                    'VLAN Name': vlan_name,
                    'VLAN Description': vlan_description,
                    'Description': description,
                    'Connected Devices': neighbors,
                    'ARP Count': arp_count,
                    'Reachable': reachable
                })

                conn.disconnect()

            except Exception:
                logging.exception(f'{device}: processing failed')

        current += subnet.num_addresses

    with open(OUTPUT_CSV, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=[
            'Subnet','Switch','Next Hop','Route Type','Interface',
            'VLAN ID','VLAN Name','VLAN Description','Description',
            'Connected Devices','ARP Count','Reachable'
        ])
        writer.writeheader()
        writer.writerows(results)

    print(f'CSV report saved to {OUTPUT_CSV}')


if __name__ == '__main__':
    main()

 
import os 
import time 
import json 
import csv 
import logging 
from datetime import datetime 
from concurrent.futures import ThreadPoolExecutor, as_completed 
import paramiko 
from pathlib import Path
import argparse
import hashlib
import difflib
import re
# ========= CONFIG ========= 
LOG_DIR = 'logs' 
ARTIFACTS_DIR = 'artifacts' 
os.makedirs(LOG_DIR, exist_ok=True) 
os.makedirs(ARTIFACTS_DIR, exist_ok=True) 
# Per-run timestamp tag 
RUN_TS = datetime.now().strftime('%Y%m%d_%H%M%S') 
# Configure logging with timestamp 
log_path = os.path.join(LOG_DIR, f'validation_log_{RUN_TS}.txt') 
logging.basicConfig( 
 filename=log_path, 
 level=logging.INFO, 
 format='%(asctime)s - %(levelname)s - %(message)s' 
) 
console = logging.StreamHandler() 
console.setLevel(logging.INFO) 
console.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')) 
logging.getLogger().addHandler(console) 
# Define devices and their credentials 
devices = { 
 "NEW_DDC1-MDFE1-COR1": {"host": "NEW_DDC1-MDFE1-COR1", "username": "ekk30ws", "password": "New42day123\!@#$%"}, 
 "NEW_DDC1-MDFE1-COR2": {"host": "NEW_DDC1-MDFE1-COR2", "username": "ekk30ws", "password": "New42day123\!@#$%"} 
} 
# Validate Aruba Edge Connect environment 
commands = { 
 "NEW_DDC1-MDFE1-COR1": [ 
 "show int e3/35  i rate", 
 "sleep 1", 
 "show int e3/36  i rate", 
 "sleep 1", 
 "show ip bgp sum  no-more", 
 "show ip bgp 10.50.66.58  no-more", 
 "show ip bgp 10.50.66.62  no-more", 
 "show ip bgp neighbors 10.50.66.58  no-more", 
 "show ip bgp neighbors 10.50.66.62  no-more", 
 "show ip route bgp int e3/35  no-more", 
 "show ip route bgp int e3/36  no-more", 
 "show ip route  no-more", 
 "show int e3/28  i rate", 
 "sleep 1", 
 "show ip bgp sum  no-more", 
 "show ip bgp 10.255.132.137  no-more", 
 "show ip bgp neighbors 10.255.132.137  no-more", 
 "show ip route bgp int e3/28  no-more", 
 "show ip route  no-more" 
 ], 
 "NEW_DDC1-MDFE1-COR2": [ 
 "show int e3/35  i rate", 
 "sleep 1", 
 "show int e3/36  i rate", 
 "sleep 1", 
 "show ip bgp sum  no-more", 
 "show ip bgp 10.50.66.66  no-more", 
 "show ip bgp 10.50.66.70  no-more", 
 "show ip bgp neighbors 10.50.66.66  no-more", 
 "show ip bgp neighbors 10.50.66.70  no-more", 
 "show ip route bgp int e3/35  no-more", 
 "show ip route bgp int e3/36  no-more", 
 "show ip route  no-more", 
 "show int e3/28  i rate", 
 "sleep 1", 
 "show ip bgp sum  no-more", 
 "show ip bgp 10.255.132.117  no-more", 
 "show ip bgp neighbors 10.255.132.117  no-more", 
 "show ip route bgp int e3/28  no-more", 
 "show ip route  no-more" 
 ] 
} 
# ========= ADDITIONAL TEST COMMANDS ========= 
# Validate sd-wan Viptela environment 
commands["NEW_DDC1-MDFE1-COR1"].extend([ 
 "show int e3/28  i rate", 
 "sleep 1", 
 "show ip bgp sum  no-more", 
 "show ip bgp 10.255.132.137  no-more", 
 "show ip bgp neighbors 10.255.132.137  no-more", 
 "show ip route bgp int e3/28  no-more", 
 "show ip route  no-more" 
]) 
commands["NEW_DDC1-MDFE1-COR2"].extend([ 
 "show int e3/28  i rate", 
 "sleep 1", 
 "show ip bgp sum  no-more", 
 "show ip bgp 10.255.132.117  no-more", 
 "show ip bgp neighbors 10.255.132.117  no-more", 
 "show ip route bgp int e3/28  no-more", 
 "show ip route  no-more" 
]) 
# ========= HELPERS ========= 
def safe_str(s: str) -\> str: 
 return (s or "").replace('\r', '').replace('\x1b', '') # strip CR and ANSI if any 
def connect_ssh(host, username, password, port=22, timeout=15, banner_timeout=10): 
 client = paramiko.SSHClient() 
 client.set_missing_host_key_policy(paramiko.AutoAddPolicy()) 
 # Avoid using local SSH agent or keys unless you want that behavior 
 client.connect( 
 hostname=host, 
 port=port, 
 username=username, 
 password=password, 
 timeout=timeout, 
 banner_timeout=banner_timeout, 
 allow_agent=False, 
 look_for_keys=False 
 ) 
 return client 
def run_exec(client: paramiko.SSHClient, cmd: str, read_timeout: float = 30.0): 
 """ 
 Run a single command via exec_command with a read timeout. 
 Returns (exit_status, stdout_text, stderr_text, elapsed_sec). 
 """ 
 start = time.time() 
 stdin, stdout, stderr = client.exec_command(cmd, timeout=read_timeout) 
 # Set channel timeout for reads 
 stdout.channel.settimeout(read_timeout) 
 stderr.channel.settimeout(read_timeout) 
 out = "" 
 err = "" 
 try: 
 out = stdout.read().decode(errors='replace') 
 except Exception as e: 
 err \+= f"\n[stdout timeout/read error: {e}]" 
 try: 
 err \+= stderr.read().decode(errors='replace') 
 except Exception as e: 
 err \+= f"\n[stderr timeout/read error: {e}]" 
 # Ensure we grab exit status 
 try: 
 exit_status = stdout.channel.recv_exit_status() 
 except Exception: 
 # Fallback if channel already closed unexpectedly 
 exit_status = -1 
 elapsed = time.time() - start 
 return exit_status, safe_str(out), safe_str(err), elapsed 
def execute_commands(device_name: str, device_info: dict, command_list: list, max_retries: int = 2): 
 host = device_info['host'] 
 username = device_info.get('username') 
 password = device_info.get('password') 
 port = device_info.get('port', 22) 
 if not username or not password or username == "REPLACE_ME" or password == "REPLACE_ME": 
 msg = f"[{device_name}] Missing credentials (set env DEVICE_USER/DEVICE_PASS or COR_USER/COR_PASS)." 
 logging.error(msg) 
 return {"device": device_name, "host": host, "status": "failed", "reason": msg, "results": []} 
 logging.info(f"Connecting to {device_name} ({host})") 
 attempt = 0 
 client = None 
 last_exc = None 
 while attempt \<= max_retries: 
 try: 
 client = connect_ssh(host, username, password, port=port) 
 break 
 except Exception as e: 
 last_exc = e 
 attempt \+= 1 
 logging.warning(f"[{device_name}] Connect attempt {attempt} failed: {e}") 
 time.sleep(min(2 \*\* attempt, 10)) 
 if client is None: 
 reason = f"Failed to connect to {device_name}: {last_exc}" 
 logging.error(reason) 
 return {"device": device_name, "host": host, "status": "failed", "reason": str(last_exc), "results": []} 
 per_device_artifact = os.path.join(ARTIFACTS_DIR, f"{device_name}_{RUN_TS}.txt") 
 results_csv = os.path.join(ARTIFACTS_DIR, f"{device_name}_{RUN_TS}.csv") 
 results_rows = [] 
 try: 
 with open(per_device_artifact, 'w', encoding='utf-8') as outf: 
 outf.write(f"==== Device: {device_name} ({host}) Run: {RUN_TS} ====\n") 
 for cmd in command_list: 
 if cmd.startswith("sleep"): 
 # Support "sleep N" 
 try: 
 delay = int(cmd.split()[1]) 
 except Exception: 
 delay = 1 
 logging.info(f"[{device_name}] Sleeping for {delay} seconds") 
 time.sleep(delay) 
 continue 
 ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S') 
 logging.info(f"[{device_name}] [{ts}] Executing: {cmd}") 
 exit_status, out, err, elapsed = run_exec(client, cmd, read_timeout=60.0) 
 # Log results 
 if out.strip(): 
 logging.info(f"[{device_name}] Output ({len(out)} bytes)") 
 if err.strip(): 
 logging.error(f"[{device_name}] Error: {err.strip()}") 
 # Write to per-device text artifact 
 outf.write(f"\n--- {ts} :: {cmd} ---\n") 
 if out: 
 outf.write(out if out.endswith('\n') else out \+ '\n') 
 if err: 
 outf.write(f"[stderr] {err if err.endswith('\n') else err \+ '\n'}") 
 # Collect CSV row 
 results_rows.append({ 
 "timestamp": ts, 
 "device": device_name, 
 "host": host, 
 "command": cmd, 
 "exit_status": exit_status, 
 "duration_ms": int(elapsed \* 1000), 
 "stdout_bytes": len(out), 
 "stderr_bytes": len(err) 
 }) 
 finally: 
 try: 
 client.close() 
 except Exception: 
 pass 
 logging.info(f"Disconnected from {device_name}") 
 # Write CSV summary 
 fieldnames = ["timestamp", "device", "host", "command", "exit_status", "duration_ms", "stdout_bytes", "stderr_bytes"] 
 with open(results_csv, 'w', newline='', encoding='utf-8') as fcsv: 
 writer = csv.DictWriter(fcsv, fieldnames=fieldnames) 
 writer.writeheader() 
 writer.writerows(results_rows) 
 return {"device": device_name, "host": host, "status": "ok", "results_file": per_device_artifact, "csv": results_csv} 
def run_all(devices: dict, commands: dict, max_workers: int = 4): 
 futures = [] 
 results = [] 
 with ThreadPoolExecutor(max_workers=max_workers) as pool: 
 for device_name, device_info in devices.items(): 
 cmd_list = commands.get(device_name, []) 
 futures.append(pool.submit(execute_commands, device_name, device_info, cmd_list)) 
 for fut in as_completed(futures): 
 try: 
 res = fut.result() 
 except Exception as e: 
 res = {"device": "unknown", "status": "failed", "reason": str(e), "results": []} 
 results.append(res) 
 # Save a run summary JSON 
 summary_path = os.path.join(ARTIFACTS_DIR, f"run_summary_{RUN_TS}.json") 
 with open(summary_path, 'w', encoding='utf-8') as js: 
 json.dump(results, js, indent=2) 
 logging.info(f"Run summary written to {summary_path}") 
 return results 
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Run device commands; optionally compare to baselines (text or binary)")
    sub = parser.add_subparsers(dest='cmd')

    pr = sub.add_parser('run', help='Execute device commands and optionally compare to baselines')
    pr.add_argument('--baseline-dir', help='Path to baselines (expects <device>.txt)')
    pr.add_argument('--diff-dir', default=os.path.join(ARTIFACTS_DIR, f'diffs_{RUN_TS}'), help='Where to write diff files')
    pr.add_argument('--baseline-mode', choices=['text','binary'], default='text', help='Compare mode vs baselines')
    pr.add_argument('--binary-method', choices=['auto','hash','bytes'], default='auto', help='Binary compare method')
    pr.add_argument('--ignore-ws', action='store_true', help='Ignore whitespace (text mode)')
    pr.add_argument('--ignore-case', action='store_true', help='Ignore case (text mode)')
    pr.add_argument('--no-normalize-eol', action='store_true', help='Do not normalize CRLF/LF (text mode)')
    pr.add_argument('--ignore-pattern', action='append', help='Regex to ignore lines (repeatable)')
    pr.add_argument('--no-fail-on-diff', action='store_true', help='Do not exit 1 on diffs; just log')

    cp = sub.add_parser('compare', help='Compare two files (text or binary)')
    cp.add_argument('a'); cp.add_argument('b')
    cp.add_argument('--mode', choices=['text','binary'], default='text')
    cp.add_argument('--ignore-ws', action='store_true')
    cp.add_argument('--ignore-case', action='store_true')
    cp.add_argument('--no-normalize-eol', action='store_true')
    cp.add_argument('--ignore-pattern', action='append')
    cp.add_argument('--binary-method', choices=['auto','hash','bytes'], default='auto')
    cp.add_argument('--diff-out')

    args = parser.parse_args()
    if args.cmd is None:
        args = parser.parse_args(['run'])

    if args.cmd == 'run':
        summary = run_all(devices, commands, max_workers=min(8, len(devices)))
        ok = [r for r in summary if r.get('status') == 'ok']
        fail = [r for r in summary if r.get('status') != 'ok']
        logging.info(f"Completed. Success: {len(ok)} Failed: {len(fail)}")

        exit_code = 0
        if args.baseline_dir:
            logging.info(f"Comparing artifacts to baselines in: {args.baseline_dir} [{args.baseline_mode}]")
            comp = compare_against_baseline(
                summary,
                args.baseline_dir,
                args.diff_dir,
                baseline_mode=args.baseline_mode,
                binary_method=args.binary_method,
                ignore_ws=getattr(args, 'ignore_ws', False),
                ignore_case=getattr(args, 'ignore_case', False),
                normalize_eol=not getattr(args, 'no_normalize_eol', False),
                ignore_patterns=getattr(args, 'ignore_pattern', None),
            )
            if comp['matched']:
                logging.info(f"Matched ({len(comp['matched'])}): {', '.join(comp['matched'])}")
            if comp['mismatched']:
                logging.warning('Mismatched differences written:')
                for p in comp['mismatched']:
                    logging.warning(f"  {p}")
                exit_code = 1 if not args.no_fail_on_diff else 0
            if comp['missing_baseline']:
                logging.warning('Missing baselines:')
                for p in comp['missing_baseline']:
                    logging.warning(f"  {p}")
            if comp['failed']:
                logging.error('Devices with failed collection:')
                for d in comp['failed']:
                    logging.error(f"  {d}")
        raise SystemExit(exit_code)

    elif args.cmd == 'compare':
        try:
            if args.mode == 'binary':
                ok = files_equal(args.a, args.b, method=args.binary_method)
            else:
                ok = text_equal(args.a, args.b,
                                ignore_whitespace=args.ignore_ws,
                                ignore_case=args.ignore_case,
                                normalize_line_endings=not args.no_normalize_eol,
                                ignore_patterns=args.ignore_pattern)
                if not ok and args.diff_out:
                    write_unified_diff(args.a, args.b, out_path=args.diff_out)
        except Exception as e:
            print(f"ERROR: {e}", file=sys.stderr)
            raise SystemExit(2)
        raise SystemExit(0 if ok else 1)

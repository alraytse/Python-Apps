import csv
import os
import sys
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

USERNAME = os.getenv("NETBRAIN_USER", "skk30ws")
PASSWORD = os.getenv("NETBRAIN_PASS", "L<4P6m}hEba86p0UzDQ7t")

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
OUTPUT_FILE = os.path.expanduser("~/Downloads/ddc1_network_inventory.csv")

MAX_WORKERS = 60
PAGE_LIMIT = 100
MAX_ESTIMATED_PAGES = 100

DEFAULT_VRFS = {"default", "mgmt", "management", "global", "none", "null", "all"}

session = requests.Session()
session.verify = False
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


def authenticate() -> dict:
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    print("Logging into NetBrain API...")
    res = session.post(login_url, json=login_payload, timeout=15)
    if res.status_code != 200:
        raise RuntimeError(f"Auth failed ({res.status_code}): {res.text}")

    data = res.json()
    token = data.get("token")
    if not token:
        raise RuntimeError("Token missing in response payload.")

    session.headers.update(
        {
            "Token": token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
    )

    if data.get("tenantId") and data.get("domainId"):
        session.headers.update(
            {"tenantId": data.get("tenantId"), "domainId": data.get("domainId")}
        )

    return data


def fetch_device_page(skip_value: int) -> list:
    url = f"{BASE_URL}/CMDB/Devices"
    try:
        res = session.get(
            url, params={"skip": skip_value, "limit": PAGE_LIMIT}, timeout=30
        )
        return res.json().get("devices", []) if res.status_code == 200 else []
    except requests.RequestException:
        return []


def extract_interface_type(intf) -> str:
    """Extracts interface type from string, dictionary, or nested structure."""
    if not intf:
        return ""

    if isinstance(intf, str):
        intf_name = intf.strip()
    elif isinstance(intf, dict):
        type_keys = [
            "interfaceType", "type", "intfType", "mediaType",
            "portType", "interface_type", "subType", "speed",
            "typeName", "type_name", "media_type", "port_type"
        ]

        for key in type_keys:
            val = intf.get(key)
            if val and str(val).strip() and str(val).lower() not in ["none", "null", "undefined", "n/a", "unknown"]:
                return str(val).strip()

        for parent in ["attributes", "properties", "details", "interfaceInfo", "spec", "data"]:
            sub_dict = intf.get(parent)
            if isinstance(sub_dict, dict):
                for key in type_keys:
                    val = sub_dict.get(key)
                    if val and str(val).strip() and str(val).lower() not in ["none", "null", "undefined", "n/a", "unknown"]:
                        return str(val).strip()

        intf_name = (
            intf.get("name")
            or intf.get("interfaceName")
            or intf.get("intfName")
            or intf.get("intf_name")
            or intf.get("ifName")
            or intf.get("portName")
            or ""
        )
    else:
        intf_name = str(intf).strip()

    if intf_name:
        match = re.match(r"^([a-zA-Z-]+)", str(intf_name).strip())
        if match:
            prefix = match.group(1).rstrip("-")
            if len(prefix) >= 2:
                return prefix

    return ""


def extract_vrfs_from_dict(data_obj, found_vrfs: set):
    """Recursively parses dictionary or list for VRF attributes."""
    if isinstance(data_obj, dict):
        vrf_keys = ["vrf", "vrfName", "vrf_name", "vrfs", "vrfList", "vrf_list"]
        for k in vrf_keys:
            val = data_obj.get(k)
            if val:
                if isinstance(val, str) and val.strip():
                    found_vrfs.add(val.strip())
                elif isinstance(val, list):
                    for item in val:
                        if isinstance(item, str) and item.strip():
                            found_vrfs.add(item.strip())
                        elif isinstance(item, dict):
                            extract_vrfs_from_dict(item, found_vrfs)
        for v in data_obj.values():
            if isinstance(v, (dict, list)):
                extract_vrfs_from_dict(v, found_vrfs)
    elif isinstance(data_obj, list):
        for item in data_obj:
            extract_vrfs_from_dict(item, found_vrfs)


def extract_interface_ips(intf) -> set:
    """Extracts IPv4 addresses assigned to an interface."""
    found_ips = set()
    if not intf:
        return found_ips

    if isinstance(intf, dict):
        ip_keys = [
            "ip", "ipAddress", "ip_address", "ipv4", "ipv4Address",
            "ipAddr", "address", "primaryIp", "ip_addr"
        ]
        for key in ip_keys:
            val = intf.get(key)
            if val:
                ip_matches = re.findall(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b", str(val))
                for ip in ip_matches:
                    if ip not in ["0.0.0.0", "255.255.255.255", "127.0.0.1"]:
                        found_ips.add(ip)

        for parent in ["attributes", "properties", "details", "interfaceInfo", "ipInfo"]:
            sub_dict = intf.get(parent)
            if isinstance(sub_dict, dict):
                for key in ip_keys:
                    val = sub_dict.get(key)
                    if val:
                        ip_matches = re.findall(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b", str(val))
                        for ip in ip_matches:
                            if ip not in ["0.0.0.0", "255.255.255.255", "127.0.0.1"]:
                                found_ips.add(ip)
    return found_ips


def enrich_device_metadata(device_id: str, hostname: str, device_raw: dict) -> tuple:
    types, vrfs, protocols, ip_addrs = set(), set(), set(), set()

    # Parse VRF directly from device raw attributes first
    extract_vrfs_from_dict(device_raw, vrfs)

    param_candidates = []
    if hostname:
        param_candidates.extend([
            {"dvcName": str(hostname)},
            {"hostname": str(hostname)},
            {"hostName": str(hostname)},
            {"name": str(hostname)},
            {"dvcName": str(hostname).lower()},
            {"hostname": str(hostname).lower()},
        ])
    if device_id:
        param_candidates.extend([
            {"dvcId": str(device_id)},
            {"deviceId": str(device_id)},
            {"id": str(device_id)},
        ])

    intf_urls = [
        f"{BASE_URL}/CMDB/Interfaces",
        f"{BASE_URL}/CMDB/Devices/Interfaces",
        f"{BASE_URL}/CMDB/Devices/Detail",
        f"{BASE_URL}/CMDB/VRFs",
        f"{BASE_URL}/CMDB/Devices/VRFs",
        f"{BASE_URL}/CMDB/Devices/{device_id}/Interfaces" if device_id else None,
        f"{BASE_URL}/CMDB/Devices/{hostname}/Interfaces" if hostname else None,
    ]

    for intf_url in filter(None, intf_urls):
        for params in param_candidates:
            responses = []
            try:
                r_get = session.get(intf_url, params=params, timeout=15)
                if r_get.status_code == 200:
                    responses.append(r_get.json())
            except requests.RequestException:
                pass

            try:
                r_post = session.post(intf_url, json=params, timeout=15)
                if r_post.status_code == 200:
                    responses.append(r_post.json())
            except requests.RequestException:
                pass

            for res_data in responses:
                extract_vrfs_from_dict(res_data, vrfs)

                interfaces = []
                if isinstance(res_data, list):
                    interfaces = res_data
                elif isinstance(res_data, dict):
                    interfaces = (
                        res_data.get("interfaces")
                        or res_data.get("interfaceList")
                        or res_data.get("interfaceDetails")
                        or res_data.get("data")
                        or res_data.get("intfDetails")
                        or res_data.get("items")
                        or res_data.get("result")
                        or []
                    )

                for intf in interfaces:
                    if_type = extract_interface_type(intf)
                    if if_type:
                        types.add(if_type)
                    ips = extract_interface_ips(intf)
                    ip_addrs.update(ips)

    rt_urls = [
        f"{BASE_URL}/CMDB/Devices/Routing/Protocols",
        f"{BASE_URL}/CMDB/Routing/Protocols",
        f"{BASE_URL}/CMDB/Routing",
    ]
    for rt_url in rt_urls:
        for params in param_candidates:
            try:
                res = session.get(rt_url, params=params, timeout=15)
                if res.status_code == 200:
                    res_data = res.json()
                    proto_list = (
                        res_data.get("protocols")
                        or res_data.get("protocolList")
                        or res_data.get("data")
                        or (res_data if isinstance(res_data, list) else [])
                    )
                    for proto in proto_list:
                        if isinstance(proto, dict):
                            p_name = (
                                proto.get("protocolName")
                                or proto.get("name")
                                or proto.get("type")
                                or proto.get("protocol")
                            )
                            if p_name:
                                protocols.add(str(p_name).upper())
                        elif isinstance(proto, str):
                            protocols.add(proto.upper())
                    if protocols:
                        break
            except requests.RequestException:
                pass
        if protocols:
            break

    # Clean VRFs by removing default/generic entries
    clean_vrfs = {
        v for v in vrfs 
        if str(v).strip().lower() not in DEFAULT_VRFS
    }

    return list(types), list(clean_vrfs), list(protocols), list(ip_addrs)


def main():
    authenticate()

    all_ddc1_devices = []
    seen_hostnames = set()
    all_discovered_columns = {
        "interfaceTypes",
        "vrfNames",
        "routingProtocols",
    }
    skip_offsets = [i * PAGE_LIMIT for i in range(MAX_ESTIMATED_PAGES)]

    print(f"Fetching global CMDB devices ({MAX_WORKERS} workers)...")

    EXCLUDED_FIELDS = {"hostName", "hostname"}

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(fetch_device_page, skip): skip
            for skip in skip_offsets
        }

        for future in as_completed(futures):
            devices_batch = future.result()
            for device in devices_batch:
                hostname = (
                    device.get("hostName")
                    or device.get("hostname")
                    or device.get("name")
                )

                if hostname and hostname not in seen_hostnames:
                    searchable_fields = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()

                    if "DDC1" in searchable_fields:
                        seen_hostnames.add(hostname)
                        flat_device = {
                            "_internal_id": device.get("id")
                            or device.get("deviceId"),
                            "_raw_device": device
                        }

                        for k, v in device.items():
                            if k in EXCLUDED_FIELDS or any(
                                ex in k.lower()
                                for ex in ["id", "discovery", "time"]
                            ):
                                continue
                            if k == "attributes" and isinstance(v, dict):
                                for sub_k, sub_v in v.items():
                                    if sub_k not in EXCLUDED_FIELDS and not any(
                                        ex in sub_k.lower()
                                        for ex in ["id", "discovery", "time"]
                                    ):
                                        flat_device[f"attr_{sub_k}"] = sub_v
                            else:
                                flat_device[k] = v

                        all_discovered_columns.update(
                            k for k in flat_device if not k.startswith("_")
                        )
                        all_ddc1_devices.append(flat_device)

    print(f"Found {len(all_ddc1_devices)} DDC1 assets. Enriching metadata...")

    if all_ddc1_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(
                    enrich_device_metadata,
                    dev.get("_internal_id"),
                    dev.get("name") or dev.get("hostName") or dev.get("hostname"),
                    dev.get("_raw_device", {})
                ): dev
                for dev in all_ddc1_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    types, vrfs, protos, ips = future.result()
                    dev["interfaceTypes"] = ", ".join(sorted(types)) if types else "N/A"
                    dev["vrfNames"] = (
                        ", ".join(sorted(vrfs)) if vrfs else "default"
                    )
                    dev["routingProtocols"] = (
                        ", ".join(sorted(protos)) if protos else "N/A"
                    )
                    dev["interfaceIPs"] = ", ".join(sorted(ips)) if ips else dev.get("mgmtIP", "N/A")
                except Exception:
                    dev["interfaceTypes"] = "N/A"
                    dev["vrfNames"] = "default"
                    dev["routingProtocols"] = "N/A"
                    dev["interfaceIPs"] = dev.get("mgmtIP", "N/A")
                finally:
                    dev.pop("_internal_id", None)
                    dev.pop("_raw_device", None)

    if not all_ddc1_devices:
        all_ddc1_devices.append(
            {
                "name": "No Matching DDC1 Assets Discovered",
                "mgmtIP": "N/A",
                "interfaceTypes": "N/A",
                "vrfNames": "default",
                "routingProtocols": "N/A",
            }
        )

    primary_headers = [
        "name",
        "mgmtIP",
        "interfaceIPs",
        "interfaceTypes",
        "vrfNames",
        "routingProtocols",
    ]
    extra_headers = sorted(
        [
            col
            for col in all_discovered_columns
            if col not in primary_headers and col not in EXCLUDED_FIELDS
        ]
    )
    ordered_headers = primary_headers + extra_headers

    # Expand interfaceTypes into individual boolean columns
    all_unique_types = set()
    for dev in all_ddc1_devices:
        itypes = dev.get("interfaceTypes", "")
        if itypes and itypes != "N/A":
            all_unique_types.update([t.strip() for t in itypes.split(",")])

    for itype in sorted(all_unique_types):
        col_name = f"ifType_{itype}"
        all_discovered_columns.add(col_name)
        for dev in all_ddc1_devices:
            itypes = dev.get("interfaceTypes", "")
            dev[col_name] = True if (itypes and itypes != "N/A" and itype in [t.strip() for t in itypes.split(",")]) else False

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=ordered_headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(all_ddc1_devices)

    print(f"Export successful: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
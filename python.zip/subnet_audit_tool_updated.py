#!/usr/bin/env python3
import csv,getpass,ipaddress,logging,platform,re,subprocess
from netmiko import ConnectHandler

OUTPUT_CSV="subnet_report.csv"
LOG_FILE="subnet_audit.log"

logging.basicConfig(level=logging.INFO,format="%(asctime)s | %(levelname)-8s | %(message)s",handlers=[logging.FileHandler(LOG_FILE),logging.StreamHandler()])

def ping_ip(ip):
    flag='-n' if platform.system().lower()=='windows' else '-c'
    try:
        r=subprocess.run(['ping',flag,'1',str(ip)],capture_output=True,text=True,timeout=2)
        return r.returncode==0
    except Exception:
        return False

def subnet_reachable(subnet):
    checked=0
    for host in subnet.hosts():
        if ping_ip(host): return True
        checked+=1
        if checked>=5: break
    return False

def find_subnet_info(conn,subnet,device):
    next_hop=route_type=interface=vlan_id=vlan_name=vlan_description=description=''
    try:
        route_output=conn.send_command(f'show ip route {subnet.network_address}')
        m=re.search(r'directly connected,\s+via\s+(\S+)',route_output,re.I)
        if m:
            route_type='Connected'; interface=m.group(1)
        else:
            m=re.search(r'\*\s+(\d+\.\d+\.\d+\.\d+)',route_output)
            if m:
                next_hop=m.group(1); route_type='Remote'
                nh=conn.send_command(f'show ip route {next_hop}')
                i=re.search(r'directly connected,\s+via\s+(\S+)',nh,re.I)
                if i: interface=i.group(1)

        vm=re.search(r'Vlan(\d+)',interface,re.I)
        if vm: vlan_id=vm.group(1)

        if vlan_id:
            try:
                out=conn.send_command(f'show vlan id {vlan_id}')
                for line in out.splitlines():
                    if re.match(rf'^{vlan_id}\s+',line.strip()):
                        c=line.split(); vlan_name=c[1] if len(c)>1 else ''
                        break
            except Exception: pass

        if interface:
            try:
                out=conn.send_command(f'show interface {interface} description')
                for line in out.splitlines():
                    if interface.lower() in line.lower():
                        c=line.split()
                        if len(c)>3: description=' '.join(c[3:])
                        break
            except Exception: pass

            try:
                run=conn.send_command(f'show running-config interface {interface}')
                dm=re.search(r'^\s*description\s+(.+)$',run,re.M|re.I)
                if dm: vlan_description=dm.group(1).strip()
            except Exception: pass
    except Exception:
        logging.exception(f'{device}: Route lookup failed')

    return next_hop,route_type,interface,vlan_id,vlan_name,vlan_description,description


def count_arp_entries(conn,subnet,device):
    count=0
    try:
        out=conn.send_command('show ip arp')
        for line in out.splitlines():
            for ip in re.findall(r'\d+\.\d+\.\d+\.\d+',line):
                try:
                    if ipaddress.ip_address(ip) in subnet: count+=1
                except Exception: pass
    except Exception:
        logging.exception(f'{device}: ARP lookup failed')
    return count


def get_neighbors(conn,interface,device):
    n=set()
    try:
        out=conn.send_command(f'show cdp neighbors {interface} detail')
        n.update(re.findall(r'Device ID:\s+(\S+)',out,re.I))
    except Exception: pass
    if not n:
        try:
            out=conn.send_command(f'show lldp neighbors {interface} detail')
            n.update(re.findall(r'System Name:\s+(\S+)',out,re.I))
        except Exception: pass
    return ', '.join(sorted(n))


def main():
    start_net=ipaddress.ip_network(input('Starting subnet/mask: ').strip(),strict=False)
    end_net=ipaddress.ip_network(input('Ending subnet/mask: ').strip(),strict=False)
    devices=[h.strip() for h in input('Hostnames (comma delimited): ').split(',') if h.strip()]
    username=input('Username: ')
    password=getpass.getpass('Password: ')

    results=[]
    current=int(start_net.network_address)
    end=int(end_net.network_address)

    while current<=end:
        subnet=ipaddress.ip_network(f'{ipaddress.ip_address(current)}/{start_net.prefixlen}',strict=False)
        reachable=subnet_reachable(subnet)

        for device in devices:
            try:
                conn=ConnectHandler(device_type='cisco_ios',host=device,username=username,password=password)
                next_hop,route_type,interface,vlan_id,vlan_name,vlan_description,description=find_subnet_info(conn,subnet,device)
                arp_count=count_arp_entries(conn,subnet,device)
                neighbors=get_neighbors(conn,interface,device) if interface else ''

                results.append({
                    'Subnet':str(subnet),'Switch':device,'Next Hop':next_hop,
                    'Route Type':route_type,'Interface':interface,'VLAN ID':vlan_id,
                    'VLAN Name':vlan_name,'VLAN Description':vlan_description,
                    'Description':description,'Connected Devices':neighbors,
                    'ARP Count':arp_count,'Reachable':reachable})
                conn.disconnect()
            except Exception:
                logging.exception(f'{device}: Processing failed')

        current+=subnet.num_addresses

    with open(OUTPUT_CSV,'w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['Subnet','Switch','Next Hop','Route Type','Interface','VLAN ID','VLAN Name','VLAN Description','Description','Connected Devices','ARP Count','Reachable'])
        writer.writeheader(); writer.writerows(results)

if __name__=='__main__':
    main()

import csv
import getpass
import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

USERNAME = input("Enter NetBrain Username: ").strip()
PASSWORD = getpass.getpass("Enter NetBrain Password: ").strip()

if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
OUTPUT_FILE = os.path.expanduser("~/Downloads/ddc1_ntp_report.csv")

MAX_WORKERS = 10
PAGE_LIMIT = 100
MAX_ESTIMATED_PAGES = 100

session = requests.Session()
session.verify = False
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


def authenticate() -> dict:
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    try:
        res = session.post(login_url, json=login_payload, timeout=60)
        res.raise_for_status()
    except requests.exceptions.Timeout:
        sys.exit("Error: Authentication request timed out (60s). Check VPN connection.")
    except requests.exceptions.RequestException as e:
        sys.exit(f"Auth network error: {e}")

    data = res.json()
    token = data.get("token")
    if not token:
        raise RuntimeError("Token missing in response payload.")

    session.headers.update(
        {
            "Token": token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
    )

    if data.get("tenantId") and data.get("domainId"):
        session.headers.update(
            {"tenantId": data.get("tenantId"), "domainId": data.get("domainId")}
        )

    return data


def fetch_device_page(skip_value: int) -> list:
    url = f"{BASE_URL}/CMDB/Devices"
    try:
        res = session.get(
            url, params={"skip": skip_value, "limit": PAGE_LIMIT}, timeout=30
        )
        return res.json().get("devices", []) if res.status_code == 200 else []
    except requests.RequestException:
        return []


def fetch_ntp_config(hostname: str, raw_device: dict) -> str:
    """Extracts NTP server entries from device payload attributes or parses raw config."""
    ntp_keys = ["ntpServers", "ntpServer", "ntp_servers", "ntp"]
    for key in ntp_keys:
        val = raw_device.get(key) or raw_device.get("attributes", {}).get(key)
        if val:
            if isinstance(val, list):
                return "\n".join(str(item).strip() for item in val if str(item).strip())
            elif isinstance(val, str) and val.strip():
                return val.strip()

    config_text = ""
    url = f"{BASE_URL}/CMDB/Devices/RawConfig"
    try:
        r = session.get(url, params={"hostname": hostname}, timeout=12)
        if r.status_code == 200:
            config_text = r.json().get("configText") or r.json().get("rawConfig") or ""
    except requests.RequestException:
        pass

    if config_text:
        ntp_matches = re.findall(
            r"^\s*ntp\s+(?:peer|server)\s+([a-zA-Z0-9\.\-_]+)",
            config_text,
            re.MULTILINE | re.IGNORECASE,
        )
        if ntp_matches:
            return "\n".join(sorted(list(set(ntp_matches))))

    return "N/A"


def main():
    authenticate()

    all_ddc1_devices = []
    seen_hostnames = set()
    skip_offsets = [i * PAGE_LIMIT for i in range(MAX_ESTIMATED_PAGES)]

    print(f"Fetching CMDB devices ({MAX_WORKERS} workers)...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(fetch_device_page, skip): skip
            for skip in skip_offsets
        }

        for future in as_completed(futures):
            devices_batch = future.result()
            for device in devices_batch:
                hostname = (
                    device.get("hostName")
                    or device.get("hostname")
                    or device.get("name")
                )

                if hostname and hostname not in seen_hostnames:
                    mgmt_ip = device.get("mgmtIP") or device.get("ip") or ""
                    sub_type = device.get("subType") or ""
                    searchable_fields = f"{hostname} {mgmt_ip} {sub_type}".upper()

                    if "DDC1" in searchable_fields:
                        seen_hostnames.add(hostname)
                        all_ddc1_devices.append({
                            "hostname": hostname,
                            "mgmtIP": mgmt_ip if mgmt_ip else "N/A",
                            "_raw_device": device
                        })

    print(f"Found {len(all_ddc1_devices)} DDC1 assets. Extracting NTP configurations...")

    if all_ddc1_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(
                    fetch_ntp_config,
                    dev["hostname"],
                    dev["_raw_device"]
                ): dev
                for dev in all_ddc1_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    dev["ntpServers"] = future.result()
                except Exception:
                    dev["ntpServers"] = "N/A"
                finally:
                    dev.pop("_raw_device", None)

    if not all_ddc1_devices:
        all_ddc1_devices.append(
            {
                "hostname": "No Matching DDC1 Assets Discovered",
                "mgmtIP": "N/A",
                "ntpServers": "N/A",
            }
        )

    headers = ["hostname", "mgmtIP", "ntpServers"]

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(all_ddc1_devices)

    print(f"NTP Report generated successfully: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
"""
NetBrain NAT Data Probe
========================

One-off diagnostic script. Do NOT use this for reporting -- it exists only
to pull raw data from ONE firewall so we can see what NetBrain actually
returns for NAT/PAT-related information, and use that to design a real
parser (this is a follow-up to netbrain-interface-report.py, whose
natInterface/patInterface columns come back "N/A" for Palo Alto devices
because NAT is a policy construct there, not an interface attribute).

It tries two API calls against the hostname you give it:
    1. CMDB/DataEngine/DeviceData/Configuration  - full running config
    2. CMDB/Devices/DeviceRawData                - a specific "show" command

Both responses are printed AND saved to local files so you can paste the
relevant excerpt back (not the whole config -- see note printed at the end).

Usage:
    python netbrain-nat-probe.py
"""

import getpass
import json
import sys

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"


def authenticate(session, username, password):
    res = session.post(f"{BASE_URL}/Session", json={"username": username, "password": password}, timeout=60)
    res.raise_for_status()
    data = res.json()
    token = data.get("token") or data.get("tokenID")
    if not token:
        sys.exit(f"Error: no token in login response: {data}")
    session.headers.update({"Token": token, "Content-Type": "application/json", "Accept": "application/json"})
    if "tenantId" in data and "domainId" in data:
        session.headers.update({"tenantId": str(data["tenantId"]), "domainId": str(data["domainId"])})


def get_configuration(session, hostname):
    url = f"{BASE_URL}/CMDB/DataEngine/DeviceData/Configuration"
    res = session.get(url, params={"hostname": hostname}, timeout=60)
    print(f"\n[Configuration API] status={res.status_code}")
    try:
        return res.json()
    except ValueError:
        return {"raw_text": res.text}


def get_raw_data(session, hostname, cmd):
    url = f"{BASE_URL}/CMDB/Devices/DeviceRawData"
    payload = {"hostname": hostname, "dataType": 2, "cmd": cmd}
    res = session.get(url, params=payload, timeout=60)
    print(f"\n[DeviceRawData API] cmd={cmd!r} status={res.status_code}")
    try:
        return res.json()
    except ValueError:
        return {"raw_text": res.text}


def main():
    username = input("Enter NetBrain Username: ").strip()
    password = getpass.getpass("Enter NetBrain Password: ").strip()
    hostname = input("Enter firewall hostname (e.g. ddc1-smo1-fw2): ").strip()

    if not username or not password or not hostname:
        sys.exit("Username, password, and hostname are all required.")

    session = requests.Session()
    session.verify = False
    authenticate(session, username, password)

    # Adjust this per platform if the firewall isn't Palo Alto:
    #   ASA:      "show run nat" / "show nat detail"
    #   Fortinet: "show firewall policy" / "get router info routing-table nat"
    #   Palo Alto:"show running ippool" or full config export below
    nat_cmd = "show running ippool"

    config_result = get_configuration(session, hostname)
    with open("nat_probe_configuration.json", "w") as f:
        json.dump(config_result, f, indent=2)
    print("Saved full config response -> nat_probe_configuration.json")

    raw_result = get_raw_data(session, hostname, nat_cmd)
    with open("nat_probe_rawdata.json", "w") as f:
        json.dump(raw_result, f, indent=2)
    print("Saved raw data response -> nat_probe_rawdata.json")

    print(
        "\nDon't paste the whole config back (it may contain sensitive info "
        "like passwords/community strings). Instead:\n"
        "  1. Open nat_probe_configuration.json and find the NAT-related "
        "     section (search for 'nat-rule', 'source-translation', or "
        "     'ip nat' depending on platform).\n"
        "  2. Paste just that section, plus the top-level JSON keys/shape "
        "     from nat_probe_rawdata.json (redact real IPs if needed).\n"
    )


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
netbrain_nat_export.py

Logs into a NetBrain server, pulls the list of devices in a given site
(default: "ddc1"), retrieves each device's NAT/PAT configuration via
the NetBrain DeviceRawData API (CLI passthrough), and writes the
results to a CSV file.

SECURITY NOTE:
Credentials are entered interactively at runtime (password is hidden
via getpass) and are never hardcoded or logged to disk.

Usage:
    python3 netbrain_nat_export.py
    python3 netbrain_nat_export.py --server https://netbrain.mycompany.com --site ddc1 --output nat_export.csv

Requirements:
    pip install requests --break-system-packages   # if not already installed
"""

import argparse
import csv
import getpass
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

MAX_WORKERS = 10      # concurrent threads used when pulling NAT data per device
PAGE_LIMIT = 100      # NetBrain enforces limit between 10 and 100 for CMDB/Devices
LIMIT_DEVICES = 377   # cap total number of devices processed per run


def login(server, username, password, verify_ssl, force_forwarded_proto=False, debug=False):
    """Authenticate and return a session token."""
    url = f"{server}/ServicesAPI/API/V1/Session"
    body = {"username": username, "password": password}
    headers = {"Content-Type": "application/json", "Accept": "application/json"}

    # Some NetBrain deployments sit behind a reverse proxy/load balancer that
    # terminates TLS and forwards this header to the backend. If the backend
    # rejects direct HTTPS requests with "HTTPS protocol is required", try
    # sending this header explicitly.
    if force_forwarded_proto:
        headers["X-Forwarded-Proto"] = "https"
        headers["X-Forwarded-Ssl"] = "on"

    resp = requests.post(
        url, headers=headers, data=json.dumps(body), verify=verify_ssl, allow_redirects=False
    )

    if debug:
        print(f"[DEBUG] Request URL: {url}")
        print(f"[DEBUG] Request headers: {headers}")
        print(f"[DEBUG] Response status: {resp.status_code}")
        print(f"[DEBUG] Response headers: {dict(resp.headers)}")
        print(f"[DEBUG] Response body: {resp.text[:1000]}")

    if resp.status_code in (301, 302, 303, 307, 308):
        raise RuntimeError(
            f"Login was redirected (HTTP {resp.status_code}) to: "
            f"{resp.headers.get('Location')}. The request may be getting "
            f"downgraded to HTTP somewhere in the network path."
        )

    if resp.status_code != 200:
        raise RuntimeError(f"Login failed: HTTP {resp.status_code} - {resp.text}")

    data = resp.json()
    token = data.get("token")
    if not token:
        raise RuntimeError(f"Login response did not contain a token: {data}")
    return token


def logout(server, token, verify_ssl):
    """Log out and invalidate the session token."""
    url = f"{server}/ServicesAPI/API/V1/Session"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    try:
        requests.delete(url, headers=headers, verify=verify_ssl)
    except requests.RequestException:
        # Non-fatal; token will simply expire server-side.
        pass


def get_site_devices(server, token, site_path, verify_ssl):
    """Return list of devices (hostname, mgmt IP) for the given site path."""
    url = f"{server}/ServicesAPI/API/V1/CMDB/Sites/Devices"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    params = {"sitePath": site_path}

    resp = requests.get(url, headers=headers, params=params, verify=verify_ssl)
    if resp.status_code != 200:
        raise RuntimeError(f"Get site devices failed: HTTP {resp.status_code} - {resp.text}")

    data = resp.json()
    devices = data.get("devices") or data.get("Devices") or []
    return devices


def get_tenants(server, token, verify_ssl):
    """Return list of {tenantId, tenantName} accessible to the logged-in user."""
    url = f"{server}/ServicesAPI/API/V1/CMDB/Tenants"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    resp = requests.get(url, headers=headers, verify=verify_ssl)
    if resp.status_code != 200:
        raise RuntimeError(f"Get tenants failed: HTTP {resp.status_code} - {resp.text}")
    return resp.json().get("tenants", [])


def get_domains(server, token, tenant_id, verify_ssl):
    """Return list of {domainId, domainName} for a given tenant."""
    url = f"{server}/ServicesAPI/API/V1/CMDB/Domains"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    params = {"tenantId": tenant_id}
    resp = requests.get(url, headers=headers, params=params, verify=verify_ssl)
    if resp.status_code != 200:
        raise RuntimeError(f"Get domains failed: HTTP {resp.status_code} - {resp.text}")
    return resp.json().get("domains", [])


def set_working_domain(server, token, tenant_id, domain_id, verify_ssl):
    """Switch the active session to the given tenant/domain."""
    url = f"{server}/ServicesAPI/API/V1/Session/CurrentDomain"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    body = {"tenantId": tenant_id, "domainId": domain_id}
    resp = requests.put(url, data=json.dumps(body), headers=headers, verify=verify_ssl)
    if resp.status_code != 200:
        raise RuntimeError(f"Set working domain failed: HTTP {resp.status_code} - {resp.text}")
    return resp.json()


def find_devices_across_domains(server, token, prefix, verify_ssl, debug=False):
    """
    Iterate every accessible tenant/domain, switch into each one, and check
    for devices matching the hostname prefix. Returns a list of dicts:
      {tenant, tenant_id, domain, domain_id, devices, total_devices}
    """
    results = []
    tenants = get_tenants(server, token, verify_ssl)
    if not tenants:
        return results

    for t in tenants:
        tenant_id = t.get("tenantId")
        tenant_name = t.get("tenantName")
        try:
            domains = get_domains(server, token, tenant_id, verify_ssl)
        except Exception as e:
            print(f"  Skipping tenant '{tenant_name}': could not list domains ({e})")
            continue

        for d in domains:
            domain_id = d.get("domainId")
            domain_name = d.get("domainName")
            print(f"  Checking tenant '{tenant_name}' / domain '{domain_name}' ...")
            try:
                set_working_domain(server, token, tenant_id, domain_id, verify_ssl)
                devices, all_devices = get_devices_by_hostname_prefix(server, token, prefix, verify_ssl, debug=debug)
            except Exception as e:
                print(f"    Skipped ({e})")
                continue

            results.append({
                "tenant": tenant_name,
                "tenant_id": tenant_id,
                "domain": domain_name,
                "domain_id": domain_id,
                "devices": devices,
                "total_devices": len(all_devices),
            })
            if devices:
                print(f"    -> {len(devices)} matching device(s) found here (domain has {len(all_devices)} total).")

    return results


def get_devices_by_hostname_prefix(server, token, prefix, verify_ssl, page_size=PAGE_LIMIT, debug=False):
    """
    Pull the full device inventory (paginated) and filter client-side by
    hostname prefix. This sidesteps NetBrain's Site hierarchy entirely,
    which is useful when devices follow a naming convention (e.g.
    'DDC1-B2B-FW5') rather than living under a Site object with that
    exact path.
    """
    url = f"{server}/ServicesAPI/API/V1/CMDB/Devices"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}

    all_devices = []
    skip = 0
    page_num = 0
    while True:
        params = {"version": 1, "skip": skip, "limit": page_size}
        resp = requests.get(url, headers=headers, params=params, verify=verify_ssl)
        if resp.status_code != 200:
            raise RuntimeError(f"Get devices failed: HTTP {resp.status_code} - {resp.text}")

        data = resp.json()

        if debug and page_num == 0:
            print(f"[DEBUG] Raw response keys: {list(data.keys())}")
            print(f"[DEBUG] Raw response (first 1500 chars): {json.dumps(data)[:1500]}")

        batch = data.get("devices", [])
        all_devices.extend(batch)

        total = data.get("total")
        if debug:
            print(f"[DEBUG] Page {page_num}: got {len(batch)} device(s), reported total={total}")

        skip += page_size
        page_num += 1
        if len(batch) < page_size:
            break
        if total is not None and skip >= total:
            break

    if debug and all_devices:
        print(f"[DEBUG] Sample device record: {json.dumps(all_devices[0])}")

    prefix_lower = prefix.lower()
    matched = [
        d for d in all_devices
        if (d.get("name") or d.get("hostname") or "").lower().startswith(prefix_lower)
    ]
    return matched, all_devices


def get_device_nat_data(server, token, hostname, verify_ssl, cmd="show running nat-policy"):
    """
    Pull raw NAT policy output from a device via the DeviceRawData API
    (CLI passthrough, dataType=2).

    For Palo Alto firewalls, "show running nat-policy" returns the
    active NAT rulebase. Adjust `cmd` for other platforms, e.g.:
      - Cisco IOS:  "show ip nat translations"
      - Cisco ASA:  "show nat"
      - Palo Alto:  "show running nat-policy"
    """
    url = f"{server}/ServicesAPI/API/V1/CMDB/Devices/DeviceRawData"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Token": token}
    params = {
        "hostname": hostname,
        "dataType": 2,   # 2 = CLI command
        "cmd": cmd,
    }

    resp = requests.get(url, headers=headers, params=params, verify=verify_ssl)
    if resp.status_code != 200:
        return f"ERROR: HTTP {resp.status_code} - {resp.text}"

    data = resp.json()
    return data.get("content", "")


def main():
    parser = argparse.ArgumentParser(description="Export NAT/PAT data from NetBrain to CSV")
    parser.add_argument("--server", help="NetBrain server URL, e.g. https://netbrain.mycompany.com")
    parser.add_argument("--site", default=None,
                         help="Full NetBrain site path, e.g. 'My Network/Region/DDC1'. "
                              "Only used if --hostname-prefix is not what you want.")
    parser.add_argument("--hostname-prefix", default="ddc1",
                         help="Filter devices by hostname prefix instead of Site path "
                              "(default: 'ddc1', matching names like DDC1-B2B-FW5)")
    parser.add_argument("--output", default="nat_export.csv", help="Output CSV filename")
    parser.add_argument("--cmd", default="show running nat-policy",
                         help="CLI command used to pull NAT data (default is Palo Alto's NAT policy command)")
    parser.add_argument("--insecure", action="store_true",
                         help="Skip SSL certificate verification (use only if your NetBrain server uses a self-signed cert)")
    parser.add_argument("--force-forwarded-proto", action="store_true",
                         help="Send X-Forwarded-Proto/X-Forwarded-Ssl headers (workaround for 'HTTPS protocol is required' errors behind some load balancers)")
    parser.add_argument("--debug", action="store_true",
                         help="Print raw request/response details for troubleshooting login issues")
    parser.add_argument("--list-domains", action="store_true",
                         help="List accessible tenants/domains and exit (use this to find where DDC1 devices live)")
    parser.add_argument("--tenant", default=None,
                         help="Tenant name or ID to select before querying devices (multi-tenant deployments)")
    parser.add_argument("--domain", default=None,
                         help="Domain name or ID to select before querying devices (multi-domain deployments)")
    parser.add_argument("--no-domain-scan", action="store_true",
                         help="Skip auto-scanning all tenants/domains; just search the current default domain")
    args = parser.parse_args()

    server = args.server or input("NetBrain server URL (e.g. https://netbrain.mycompany.com): ").strip()
    server = server.rstrip("/")

    username = input("NetBrain username: ").strip()
    password = getpass.getpass("NetBrain password: ")

    verify_ssl = not args.insecure

    print(f"\nLogging into {server} ...")
    try:
        token = login(
            server, username, password, verify_ssl,
            force_forwarded_proto=args.force_forwarded_proto,
            debug=args.debug,
        )
    except Exception as e:
        print(f"Login failed: {e}")
        sys.exit(1)
    print("Login successful.")

    if args.list_domains:
        print("\nAccessible tenants/domains:")
        try:
            tenants = get_tenants(server, token, verify_ssl)
            for t in tenants:
                print(f"  Tenant: {t.get('tenantName')}  (id: {t.get('tenantId')})")
                domains = get_domains(server, token, t.get("tenantId"), verify_ssl)
                for d in domains:
                    print(f"    Domain: {d.get('domainName')}  (id: {d.get('domainId')})")
        except Exception as e:
            print(f"Failed to list tenants/domains: {e}")
        finally:
            logout(server, token, verify_ssl)
        sys.exit(0)

    if args.tenant or args.domain:
        try:
            tenants = get_tenants(server, token, verify_ssl)
            tenant_match = next(
                (t for t in tenants if args.tenant and (t.get("tenantId") == args.tenant or t.get("tenantName") == args.tenant)),
                tenants[0] if tenants else None,
            )
            if not tenant_match:
                raise RuntimeError("No accessible tenant found.")
            domains = get_domains(server, token, tenant_match.get("tenantId"), verify_ssl)
            domain_match = next(
                (d for d in domains if args.domain and (d.get("domainId") == args.domain or d.get("domainName") == args.domain)),
                None,
            )
            if not domain_match:
                raise RuntimeError(
                    f"Domain '{args.domain}' not found under tenant '{tenant_match.get('tenantName')}'. "
                    f"Available domains: {[d.get('domainName') for d in domains]}"
                )
            print(f"Switching to tenant '{tenant_match.get('tenantName')}', domain '{domain_match.get('domainName')}' ...")
            set_working_domain(server, token, tenant_match.get("tenantId"), domain_match.get("domainId"), verify_ssl)
        except Exception as e:
            print(f"Failed to set working domain: {e}")
            sys.exit(1)

    auto_selected_devices = None

    if not args.site and not args.tenant and not args.domain and not args.no_domain_scan:
        print(f"\nNo --tenant/--domain specified. Searching all accessible tenants/domains "
              f"for devices matching hostname prefix '{args.hostname_prefix}' ...")
        try:
            scan_results = find_devices_across_domains(server, token, args.hostname_prefix, verify_ssl, debug=args.debug)
        except Exception as e:
            print(f"Domain scan failed: {e}")
            logout(server, token, verify_ssl)
            sys.exit(1)

        hits = [r for r in scan_results if r["devices"]]

        if not hits:
            print(f"\nNo devices matching '{args.hostname_prefix}' were found in any accessible tenant/domain.")
            print("Summary of what was checked:")
            for r in scan_results:
                print(f"  {r['tenant']} / {r['domain']}: {r['total_devices']} total device(s)")
            logout(server, token, verify_ssl)
            sys.exit(1)

        if len(hits) == 1:
            chosen = hits[0]
            print(f"\nFound matches in exactly one domain: '{chosen['tenant']}' / '{chosen['domain']}'. Using it.")
        else:
            print(f"\nFound matches in {len(hits)} different domains:")
            for i, r in enumerate(hits, start=1):
                print(f"  [{i}] {r['tenant']} / {r['domain']}  ({len(r['devices'])} matching device(s))")
            choice = input(f"Select which domain to use [1-{len(hits)}]: ").strip()
            try:
                chosen = hits[int(choice) - 1]
            except (ValueError, IndexError):
                print("Invalid selection.")
                logout(server, token, verify_ssl)
                sys.exit(1)

        print(f"Re-selecting domain '{chosen['tenant']}' / '{chosen['domain']}' ...")
        set_working_domain(server, token, chosen["tenant_id"], chosen["domain_id"], verify_ssl)
        auto_selected_devices = chosen["devices"]

    try:
        if args.site:
            print(f"Retrieving devices for site '{args.site}' ...")
            devices = get_site_devices(server, token, args.site, verify_ssl)
            if not devices:
                print(f"No devices found for site '{args.site}'. Check the site name/path and try again.")
                sys.exit(1)
        elif auto_selected_devices is not None:
            devices = auto_selected_devices
        else:
            print(f"Retrieving devices with hostname prefix '{args.hostname_prefix}' ...")
            devices, all_devices = get_devices_by_hostname_prefix(server, token, args.hostname_prefix, verify_ssl, debug=args.debug)
            print(f"Total devices visible in this domain: {len(all_devices)}")
            if not devices:
                sample = [(d.get("name") or d.get("hostname")) for d in all_devices[:10]]
                print(f"No devices found with hostname prefix '{args.hostname_prefix}'.")
                print(f"Sample of hostnames actually visible (first 10): {sample}")
                sys.exit(1)
        print(f"Found {len(devices)} device(s).")

        if LIMIT_DEVICES is not None and len(devices) > LIMIT_DEVICES:
            print(f"Capping processing to LIMIT_DEVICES={LIMIT_DEVICES} (out of {len(devices)} found).")
            devices = devices[:LIMIT_DEVICES]

        rows = [None] * len(devices)

        def process_device(index, dev):
            hostname = dev.get("hostname") or dev.get("name")
            mgmt_ip = dev.get("mgmtIP") or dev.get("mgmtIp") or ""
            nat_output = get_device_nat_data(server, token, hostname, verify_ssl, cmd=args.cmd)
            return index, {
                "hostname": hostname,
                "mgmt_ip": mgmt_ip,
                "command_used": args.cmd,
                "nat_output": nat_output,
            }

        print(f"Pulling NAT data for {len(devices)} device(s) using {MAX_WORKERS} worker thread(s) ...")
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = [executor.submit(process_device, i, dev) for i, dev in enumerate(devices)]
            completed = 0
            for future in as_completed(futures):
                index, row = future.result()
                rows[index] = row
                completed += 1
                print(f"  [{completed}/{len(devices)}] {row['hostname']} done")

        with open(args.output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["hostname", "mgmt_ip", "command_used", "nat_output"])
            writer.writeheader()
            writer.writerows(rows)

        print(f"\nDone. Wrote {len(rows)} row(s) to {args.output}")

    finally:
        logout(server, token, verify_ssl)


if __name__ == "__main__":
    main()

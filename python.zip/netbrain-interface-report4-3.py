"""
NetBrain Interface Report
==========================

Generates a per-interface CSV audit report for devices at a given NetBrain
site, using the NetBrain REST API (CMDB/Devices and CMDB/Interfaces
endpoints).

Interface
---------
Inputs (interactive prompts):
    NetBrain Username   - str, required. NetBrain login username.
    NetBrain Password   - str, required (hidden input). NetBrain login password.
    Target Site         - str, optional. Site code to filter devices by
                           (matched against hostname, mgmt IP, and subtype).
                           Defaults to "DDC1" if left blank.

Configuration (constants, edit in source to change):
    BASE_URL       - NetBrain Services API base URL.
    MAX_WORKERS    - Thread pool size for concurrent device enrichment (default 10).
    PAGE_LIMIT     - Page size when paginating the CMDB Devices endpoint (default 100).
    LIMIT_DEVICES  - Max number of matching devices to process (default 375).

Output:
    A CSV file written to:
        ~/Downloads/{TARGET_SITE}.netbrain.interface.report.{TIMESTAMP}.csv
    One row per device interface, with columns including:
        name, requestedSite, serialNumber, hardwareModel,
        interfaceName, interfaceDescription, interfaceSpeed, resolvedIP,
        vrfNames, hasNAT, hasPAT, plus any additional device attributes
        discovered from the API response.

Usage:
    python netbrain-interface-report.py

Requires network access to the NetBrain API host and valid NetBrain
credentials. SSL certificate verification is disabled for API requests.
"""

import csv
import getpass
import os
import socket
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import requests
import urllib3

# Disable insecure HTTPS warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------------------
# Interactive Inputs & Configuration
# ---------------------------------------------------------------------------
USERNAME = input("Enter NetBrain Username: ").strip()
PASSWORD = getpass.getpass("Enter NetBrain Password: ").strip()

site_input = input("Enter Target Site [default: DDC1]: ").strip().upper()
TARGET_SITE = site_input if site_input else "DDC1"

if not USERNAME or not PASSWORD:
    sys.exit("Error: Username and Password cannot be empty.")

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
OUTPUT_FILE = os.path.expanduser(
    f"~/Downloads/{TARGET_SITE}.netbrain.interface.report.{TIMESTAMP}.csv"
)

MAX_WORKERS = 10
PAGE_LIMIT = 100
LIMIT_DEVICES = 377 # Cap processing to 3 devices

session = requests.Session()
session.verify = False

# Optimize HTTP connection pool
adapter = requests.adapters.HTTPAdapter(
    pool_connections=50, 
    pool_maxsize=50, 
    max_retries=2
)
session.mount("https://", adapter)
session.mount("http://", adapter)

DNS_CACHE = {}


def authenticate() -> dict:
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    try:
        res = session.post(login_url, json=login_payload, timeout=60)
        res.raise_for_status()
    except requests.exceptions.RequestException as e:
        sys.exit(f"Auth error: {e}")

    data = res.json()
    token = data.get("token") or data.get("tokenID")
    if not token:
        sys.exit("Error: Token missing in response payload.")

    session.headers.update({
        "Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json"
    })

    if "tenantId" in data and "domainId" in data:
        session.headers.update({
            "tenantId": str(data["tenantId"]),
            "domainId": str(data["domainId"])
        })
    return data


def fetch_all_devices() -> list:
    """Dynamically paginates through NetBrain CMDB devices until limit or end is reached."""
    all_devices = []
    skip = 0

    while True:
        url = f"{BASE_URL}/CMDB/Devices"
        try:
            res = session.get(url, params={"skip": skip, "limit": PAGE_LIMIT}, timeout=30)
            if res.status_code != 200:
                break
            
            devices = res.json().get("devices", [])
            if not devices:
                break

            all_devices.extend(devices)
            skip += PAGE_LIMIT
            
            if len(devices) < PAGE_LIMIT:
                break
        except requests.RequestException:
            break

    return all_devices


def fetch_device_attributes(hostname: str) -> dict:
    """Queries CMDB Device Attributes passing attributeNames=sn,model."""
    url = f"{BASE_URL}/CMDB/Devices/Attributes"
    params = {
        "hostname": hostname,
        "attributeNames": "sn,serialNumber,model"
    }
    try:
        res = session.get(url, params=params, timeout=15)
        if res.status_code == 200:
            return res.json().get("attributes", {})
    except requests.RequestException:
        pass
    return {}


def fetch_all_interface_attrs(hostname: str) -> dict:
    """Retrieves all interface attributes for a given hostname in a single API call."""
    url = f"{BASE_URL}/CMDB/Interfaces/Attributes"
    try:
        r = session.get(url, params={"hostname": hostname}, timeout=15)
        if r.status_code == 200:
            return r.json().get("attributes", {})
    except requests.RequestException:
        pass
    return {}


def extract_site_from_device(device: dict) -> str:
    """Extracts site location metadata from device payload, falling back to TARGET_SITE."""
    for key in ["siteName", "site", "sitePath", "location", "site_name"]:
        val = device.get(key)
        if val and isinstance(val, str) and val.strip():
            return val.strip()

    return TARGET_SITE


def clean_ip(val) -> str:
    """Strips subnet masks, CIDR notation, and whitespace to isolate raw IP for DNS queries."""
    if not val or not isinstance(val, str):
        return ""
    ip_only = val.split("/")[0].strip()
    return ip_only if ip_only.upper() != "N/A" else ""


def resolve_ptr(ip_str: str, hostname_fallback: str = "") -> tuple:
    """Performs reverse DNS lookup returning (ip_with_mask, dns_name) separately."""
    clean_ip_addr = clean_ip(ip_str)
    raw_ip_entry = str(ip_str).strip() if ip_str else "N/A"
    if not clean_ip_addr:
        return ("N/A", "N/A")

    if clean_ip_addr in DNS_CACHE:
        _, cached_dns = DNS_CACHE[clean_ip_addr]
        return (raw_ip_entry, cached_dns)

    try:
        dns_name, _, _ = socket.gethostbyaddr(clean_ip_addr)
        result = (raw_ip_entry, dns_name)
    except Exception:
        fallback_dns = hostname_fallback if hostname_fallback and hostname_fallback.upper() != "N/A" else "N/A"
        result = (raw_ip_entry, fallback_dns)

    DNS_CACHE[clean_ip_addr] = result
    return result


def enrich_device_metadata(hostname: str, raw_device: dict) -> tuple:
    """Enriches device metadata, returning a per-interface row list plus device-level attributes."""
    intf_data = {}

    site_name = extract_site_from_device(raw_device)

    if not hostname:
        placeholder_intf = [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "hasNAT": "No", "hasPAT": "No"
        }]
        return placeholder_intf, "N/A", "N/A", site_name

    # Fetch device attributes and interface attributes concurrently
    with ThreadPoolExecutor(max_workers=2) as inner_executor:
        future_attrs = inner_executor.submit(fetch_device_attributes, hostname)
        future_intf_attrs = inner_executor.submit(fetch_all_interface_attrs, hostname)

        dev_attrs = future_attrs.result()
        all_intf_attrs = future_intf_attrs.result()

    sn_val = dev_attrs.get("sn") or dev_attrs.get("serialNumber") or "N/A"
    model_val = dev_attrs.get("model") or "N/A"

    for intf_name, attrs in all_intf_attrs.items():
        if not intf_name:
            continue

        clean_intf = str(intf_name).strip()

        if isinstance(attrs, dict):
            speed_val = attrs.get("speed") or attrs.get("bandwidth") or attrs.get("interfaceSpeed")
            clean_speed = str(speed_val).strip() if speed_val and str(speed_val).strip() else "N/A"

            descr_val = attrs.get("descr") or attrs.get("description") or attrs.get("interfaceDescription")
            clean_descr = str(descr_val).strip() if descr_val and str(descr_val).strip() else "N/A"

            vrf_val = str(attrs.get("mplsVrf") or attrs.get("vrfName") or attrs.get("vrf") or "").strip()
            clean_vrf = vrf_val if vrf_val and vrf_val.lower() not in ["none", "null", "undefined", "n/a", "0"] else "default"

            nat_val = attrs.get("isNatIntf") or attrs.get("natType") or attrs.get("nat")
            has_nat = "Yes" if nat_val and str(nat_val).lower() not in ["false", "0", "disabled", "no", ""] else "No"

            pat_val = attrs.get("isPatIntf") or attrs.get("patType") or attrs.get("pat")
            has_pat = "Yes" if pat_val and str(pat_val).lower() not in ["false", "0", "disabled", "no", ""] else "No"

            intf_ip = "N/A"
            ips_raw = attrs.get("ips") or attrs.get("ipAddress")
            raw_list = ips_raw if isinstance(ips_raw, list) else [ips_raw]

            for item in raw_list:
                ip_str = item.get("ipLoc") if isinstance(item, dict) else item
                mask_val = item.get("mask") or item.get("subnetMask") if isinstance(item, dict) else ""

                c_ip = clean_ip(ip_str)
                if c_ip:
                    # Construct full IP with subnet mask if available separately
                    if mask_val and "/" not in str(ip_str):
                        full_ip_with_mask = f"{ip_str}/{mask_val}"
                    else:
                        full_ip_with_mask = str(ip_str).strip()

                    resolved_ip, _ = resolve_ptr(full_ip_with_mask, hostname)
                    intf_ip = resolved_ip
                    break  # one resolved IP per interface

            intf_data[clean_intf] = {
                "name": clean_intf,
                "description": clean_descr,
                "speed": clean_speed,
                "vrf": clean_vrf,
                "nat": has_nat,
                "pat": has_pat,
                "ip": intf_ip,
            }
        else:
            intf_data[clean_intf] = {
                "name": clean_intf,
                "description": "N/A",
                "speed": "N/A",
                "vrf": "default",
                "nat": "No",
                "pat": "No",
                "ip": "N/A",
            }

    sorted_intfs = sorted(intf_data.keys())
    if sorted_intfs:
        interfaces_list = [
            {
                "interfaceName": intf_data[intf]["name"],
                "interfaceDescription": intf_data[intf]["description"],
                "interfaceSpeed": intf_data[intf]["speed"],
                "resolvedIP": intf_data[intf]["ip"],
                "vrfNames": intf_data[intf]["vrf"],
                "hasNAT": intf_data[intf]["nat"],
                "hasPAT": intf_data[intf]["pat"],
            }
            for intf in sorted_intfs
        ]
    else:
        interfaces_list = [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "hasNAT": "No", "hasPAT": "No"
        }]

    return (
        interfaces_list,
        sn_val,
        model_val,
        site_name,
    )


def main():
    authenticate()

    site_devices = []
    seen_hostnames = set()
    all_discovered_columns = {
        "requestedSite",
        "serialNumber",
        "hardwareModel",
        "interfaceDescription",
        "interfaceSpeed",
        "vrfNames",
        "resolvedIP",
        "hasNAT",
        "hasPAT",
    }
    
    EXCLUDED_FIELDS = {
        "hostName",
        "hostname",
        "mgmtIP",
        "domain",
        "domainName",
        "dnsDomain",
    }

    print(f"Fetching global CMDB devices for target site '{TARGET_SITE}'...")
    raw_devices = fetch_all_devices()

    for device in raw_devices:
        if len(site_devices) >= LIMIT_DEVICES:
            break

        hostname = (
            device.get("hostName")
            or device.get("hostname")
            or device.get("name")
        )

        if hostname and hostname not in seen_hostnames:
            searchable_fields = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()

            if TARGET_SITE in searchable_fields:
                seen_hostnames.add(hostname)
                flat_device = {"_raw_device": device}
                flat_device["requestedSite"] = extract_site_from_device(device)

                for k, v in device.items():
                    if k in EXCLUDED_FIELDS or any(
                        ex in k.lower() for ex in ["id", "discovery", "time"]
                    ):
                        continue
                    if k == "attributes" and isinstance(v, dict):
                        for sub_k, sub_v in v.items():
                            if sub_k not in EXCLUDED_FIELDS and not any(
                                ex in sub_k.lower() for ex in ["id", "discovery", "time"]
                            ):
                                flat_device[f"attr_{sub_k}"] = sub_v
                    else:
                        flat_device[k] = v

                all_discovered_columns.update(
                    k for k in flat_device if not k.startswith("_")
                )
                site_devices.append(flat_device)

    print(f"Limiting audit to {len(site_devices)} assets. Enriching metadata ({MAX_WORKERS} workers)...")

    if site_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(
                    enrich_device_metadata,
                    dev.get("name") or dev.get("hostName") or dev.get("hostname"),
                    dev.get("_raw_device", {}),
                ): dev
                for dev in site_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    (
                        interfaces_list,
                        sn_res,
                        model_res,
                        site_res,
                    ) = future.result()

                    dev["_interfaces"] = interfaces_list
                    dev["serialNumber"] = sn_res
                    dev["hardwareModel"] = model_res
                    dev["requestedSite"] = site_res
                except Exception:
                    dev["_interfaces"] = [{
                        "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
                        "resolvedIP": "N/A", "vrfNames": "default", "hasNAT": "No", "hasPAT": "No"
                    }]
                    dev["serialNumber"] = "N/A"
                    dev["hardwareModel"] = "N/A"
                    dev["requestedSite"] = TARGET_SITE
                finally:
                    dev.pop("_raw_device", None)

    primary_headers = [
        "name",
        "requestedSite",
        "serialNumber",
        "hardwareModel",
        "interfaceName",
        "interfaceDescription",
        "interfaceSpeed",
        "resolvedIP",
        "vrfNames",
        "hasNAT",
        "hasPAT",
    ]
    extra_headers = sorted(
        [
            col
            for col in all_discovered_columns
            if col not in primary_headers and col not in EXCLUDED_FIELDS
        ]
    )
    ordered_headers = primary_headers + extra_headers

    # Expand each device into one row per interface, repeating device-level fields.
    final_rows = []
    for dev in site_devices:
        interfaces = dev.pop("_interfaces", None) or [{
            "interfaceName": "N/A", "interfaceDescription": "N/A", "interfaceSpeed": "N/A",
            "resolvedIP": "N/A", "vrfNames": "default", "hasNAT": "No", "hasPAT": "No"
        }]
        for intf_row in interfaces:
            row = {**dev, **intf_row}
            final_rows.append(row)

    output_dir = os.path.dirname(OUTPUT_FILE)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=ordered_headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(final_rows)

    print(f"Export successful: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
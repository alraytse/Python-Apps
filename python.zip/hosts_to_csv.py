#!/usr/bin/env python3
"""
Prompts the user for host names separated by spaces,
then prints them back separated by commas.
"""

def main():
    hosts_input = input("Enter host names separated by spaces: ")
    hosts = hosts_input.split()  # splits on any whitespace, ignores extra spaces
    result = ",".join(hosts)
    print(result)


if __name__ == "__main__":
    main()

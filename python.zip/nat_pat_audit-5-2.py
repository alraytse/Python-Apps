#!/usr/bin/env python3
"""
nat_pat_audit.py

Connects to one or more Cisco IOS routers over SSH and pulls back
NAT / PAT related configuration and state:

    1. Static NAT            - ip nat inside source static <local> <global>
    2. Dynamic NAT            - ip nat pool / ip nat inside source list <acl> pool <pool>
    3. PAT (NAT Overload)     - ip nat inside source list <acl> interface <intf> overload
    4. Static PAT (PF)        - ip nat inside source static tcp/udp <local> <lport> <global> <gport>
    5. Inside/Outside intf    - interface ... ip nat inside / ip nat outside
    6. Live state             - show ip nat translations / show ip nat statistics

Output: a single CSV file named nat-pat-<YYYYMMDD>-<HHMMSS>.csv containing
one row per finding, across all routers queried.

Requires: netmiko
    pip install netmiko --break-system-packages

Usage:
    python3 nat_pat_audit.py
    (You'll be prompted for hostnames, username, and password.)
"""

import csv
import getpass
import re
import sys
from datetime import datetime

try:
    from netmiko import ConnectHandler
    from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException
except ImportError:
    print("This script requires netmiko. Install it with:")
    print("    pip install netmiko --break-system-packages")
    sys.exit(1)


# --------------------------------------------------------------------------
# Prompting
# --------------------------------------------------------------------------

def prompt_for_hosts():
    raw = input("Enter router hostname(s) or IP(s) (comma-delimited): ").strip()
    hosts = [h.strip() for h in raw.split(",") if h.strip()]
    if not hosts:
        print("No hosts provided. Exiting.")
        sys.exit(1)
    return hosts


def prompt_for_credentials():
    username = input("Enter username: ").strip()
    password = getpass.getpass("Enter password: ")
    enable_secret = getpass.getpass("Enter enable/secret password (press Enter to reuse login password): ")
    if not enable_secret:
        enable_secret = password
    return username, password, enable_secret


# --------------------------------------------------------------------------
# Parsing helpers
# --------------------------------------------------------------------------

def categorize_nat_lines(running_config):
    """
    Walk the running-config text and bucket every NAT-relevant line
    into the categories described in the module docstring. Also captures
    ACL permit entries and interface IP addresses so that PAT/overload
    statements referencing an ACL + interface can be resolved into their
    actual source networks and NAT (outside interface) IP address.
    """
    results = {
        "static_nat": [],
        "dynamic_nat_pools": [],
        "dynamic_nat_bindings": [],
        "pat_overload": [],
        "static_pat": [],
        "acls_referenced": [],
        "nat_inside_outside": [],
        "acl_entries": {},      # acl id/name -> [source description, ...]
        "interface_ips": {},    # interface name -> primary IP address
    }

    lines = running_config.splitlines()
    current_interface = None
    current_named_acl = None

    def describe_acl_source(rest):
        """Turn the tail of a permit/deny line into a readable source string."""
        rest = rest.strip()
        if rest.startswith("host "):
            return rest  # "host 192.168.1.5"
        if rest.startswith("any"):
            return "any"
        parts = rest.split()
        if len(parts) >= 2:
            network, wildcard = parts[0], parts[1]
            return f"{network} {wildcard}"
        return rest

    for line in lines:
        stripped = line.strip()

        # Top-level "interface X" starts a new interface stanza.
        intf_match = re.match(r"^interface\s+(\S+)", stripped)
        if intf_match:
            current_interface = intf_match.group(1)
            current_named_acl = None
            continue

        # Top-level named ACL block: "ip access-list standard|extended NAME"
        named_acl_match = re.match(r"^ip access-list\s+(?:standard|extended)\s+(\S+)", stripped)
        if named_acl_match:
            current_named_acl = named_acl_match.group(1)
            current_interface = None
            results["acls_referenced"].append(stripped)
            results["acl_entries"].setdefault(current_named_acl, [])
            continue

        # Inside a named ACL block: indented "permit ..." / "deny ..." lines.
        if current_named_acl:
            permit_match = re.match(r"^(permit)\s+(.*)$", stripped)
            if permit_match:
                source_desc = describe_acl_source(permit_match.group(2))
                results["acl_entries"][current_named_acl].append(source_desc)
                continue
            if re.match(r"^(deny)\s+", stripped):
                continue  # deny entries aren't NAT sources; skip
            if stripped == "" :
                continue
            # Any other line ends the ACL block context.
            current_named_acl = None

        # Interface IP address (skip "secondary" so we keep the primary IP).
        if current_interface:
            ip_match = re.match(r"^ip address\s+(\S+)\s+(\S+)(?!.*secondary)", stripped)
            if ip_match and "secondary" not in stripped:
                results["interface_ips"].setdefault(current_interface, ip_match.group(1))

        if stripped.startswith("ip nat inside") and "source" not in stripped:
            results["nat_inside_outside"].append((current_interface, "inside"))
        elif stripped.startswith("ip nat outside"):
            results["nat_inside_outside"].append((current_interface, "outside"))

        # Static PAT: ip nat inside source static tcp|udp <local> <lport> <global> <gport> [extendable]
        elif re.match(r"^ip nat inside source static (tcp|udp)\s", stripped):
            results["static_pat"].append(stripped)

        # Static NAT: ip nat inside source static <local> <global>
        elif re.match(r"^ip nat inside source static\s+\S+\s+\S+", stripped):
            results["static_nat"].append(stripped)

        # PAT / NAT overload: ip nat inside source list <acl> interface <intf> overload
        elif "ip nat inside source list" in stripped and "overload" in stripped:
            results["pat_overload"].append(stripped)

        # Dynamic NAT binding: ip nat inside source list <acl> pool <pool> (no overload)
        elif "ip nat inside source list" in stripped and "pool" in stripped:
            results["dynamic_nat_bindings"].append(stripped)

        # NAT pool definition: ip nat pool <name> <start> <end> netmask <mask>
        elif stripped.startswith("ip nat pool"):
            results["dynamic_nat_pools"].append(stripped)

        # Numbered ACL, single-line form: "access-list 1 permit 192.168.1.0 0.0.0.255"
        elif re.match(r"^access-list\s+\d+\s+(permit|deny)\s", stripped):
            results["acls_referenced"].append(stripped)
            acl_match = re.match(r"^access-list\s+(\d+)\s+(permit|deny)\s+(.*)$", stripped)
            if acl_match:
                acl_id, action, rest = acl_match.groups()
                results["acl_entries"].setdefault(acl_id, [])
                if action == "permit":
                    results["acl_entries"][acl_id].append(describe_acl_source(rest))

    return results


def resolve_pat_overload_sources(pat_overload_lines, acl_entries, interface_ips):
    """
    For each "ip nat inside source list <acl> interface <intf> overload" line,
    resolve <acl> into its actual permitted source networks and <intf> into
    its real IP address, e.g.:

        ACL 1 sources [192.168.1.0 0.0.0.255, 192.168.2.0 0.0.0.255]
        -> PAT via GigabitEthernet0/0/4 (203.0.113.5)
    """
    resolved = []
    for line in pat_overload_lines:
        m = re.search(r"ip nat inside source list\s+(\S+)\s+interface\s+(\S+)\s+overload", line)
        if not m:
            resolved.append({
                "acl_id": "", "sources": "", "nat_interface": "", "nat_interface_ip": "",
                "detail": line,
            })
            continue
        acl_id, intf = m.groups()
        sources = acl_entries.get(acl_id, [])
        sources_str = "; ".join(sources) if sources else "(ACL entries not found in captured config)"
        intf_ip = interface_ips.get(intf, "(IP not found in captured config)")
        resolved.append({
            "acl_id": acl_id,
            "sources": sources_str,
            "nat_interface": intf,
            "nat_interface_ip": intf_ip,
            "detail": line,
        })
    return resolved


IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")


def extract_all_acl_ips(acl_entries):
    """
    Walk every captured ACL's source descriptions (e.g. "host 192.168.1.5",
    "192.168.2.0 0.0.0.255", "any") and pull out the actual network/host
    IPv4 address from each entry -- the wildcard mask that may follow a
    network address is intentionally excluded since it isn't itself an
    address in use.

    Returns a comma-delimited string of unique IPs, in first-seen order.
    """
    seen = []
    for sources in acl_entries.values():
        for source_desc in sources:
            source_desc = source_desc.strip()
            if source_desc == "any":
                continue
            if source_desc.startswith("host "):
                candidate = source_desc[len("host "):].strip()
            else:
                # "<network> <wildcard>" form - only the network address
                # (first token) is a real IP; the wildcard mask is not.
                candidate = source_desc.split()[0] if source_desc.split() else ""
            if IPV4_RE.fullmatch(candidate) and candidate not in seen:
                seen.append(candidate)
    return ", ".join(seen)


def parse_nat_translations(raw):
    """
    Parse 'show ip nat translations' output into structured rows.

    Typical Cisco IOS output:
        Pro Inside global      Inside local       Outside local      Outside global
        tcp 203.0.113.5:1024   192.168.1.10:1024  198.51.100.9:80    198.51.100.9:80
        --- 203.0.113.5        192.168.1.10       ---                ---

    Field meanings (Cisco NAT terminology):
      - Inside local    = ORIGINAL packet SOURCE address (private IP the
                           inside host actually used, before translation)
      - Inside global   = source address as it appears on the wire after NAT/PAT
      - Outside local   = ORIGINAL packet DESTINATION address as addressed
                           by the inside host (before any outside-NAT rewrite).
                           In setups with no outside NAT, this is identical
                           to Outside global.
      - Outside global  = the real, globally-routable destination address
                           of the outside host.
    """
    parsed = []
    for line in raw.strip().splitlines():
        stripped = line.strip()
        if not stripped or stripped.lower().startswith("pro "):
            continue  # skip blank lines and the header row

        fields = stripped.split()
        if len(fields) < 5:
            # Doesn't match the expected 5-column layout (e.g. a wrapped
            # verbose line); keep it as an unparsed row so nothing is lost.
            parsed.append({
                "protocol": "",
                "inside_global": "",
                "inside_local": "",
                "outside_local": "",
                "outside_global": "",
                "raw": stripped,
            })
            continue

        protocol, inside_global, inside_local, outside_local, outside_global = fields[:5]
        parsed.append({
            "protocol": protocol,
            "inside_global": inside_global,
            "inside_local": inside_local,     # original packet source address
            "outside_local": outside_local,   # original packet destination address (as addressed by inside host)
            "outside_global": outside_global,  # real destination address on the outside network
            "raw": stripped,
        })
    return parsed


CSV_FIELDS = [
    "hostname",
    "timestamp",
    "category",
    "detail",
    "protocol",
    "inside_global",
    "original_source_inside_local",
    "original_destination_outside_local",
    "outside_global",
    "acl_id",
    "acl_sources",
    "nat_interface_ip",
    "nat_interface",
]

CATEGORY_LABELS = {
    "static_nat": "Static NAT",
    "dynamic_nat_pools": "Dynamic NAT Pool",
    "dynamic_nat_bindings": "Dynamic NAT Binding",
    "pat_overload": "PAT (NAT Overload)",
    "static_pat": "Static PAT (Port Forwarding)",
    "acls_referenced": "Referenced ACL",
}


def build_rows(hostname, categorized, nat_translations, nat_statistics, raw_error=None):
    """
    Convert one host's findings into a flat list of dict rows suitable
    for csv.DictWriter, using the CSV_FIELDS columns.
    """
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rows = []

    if raw_error:
        rows.append({
            "hostname": hostname,
            "timestamp": ts,
            "category": "ERROR",
            "detail": raw_error,
        })
        return rows

    # Config-derived categories
    for key, label in CATEGORY_LABELS.items():
        items = categorized.get(key, [])
        if not items:
            rows.append({"hostname": hostname, "timestamp": ts, "category": label, "detail": "(none found)"})
        else:
            for item in items:
                rows.append({"hostname": hostname, "timestamp": ts, "category": label, "detail": item})

    # Every IP address found across all captured ACL entries, as one
    # comma-delimited list (deduplicated, in first-seen order).
    acl_entries = categorized.get("acl_entries", {})
    acl_ip_list = extract_all_acl_ips(acl_entries)
    rows.append({
        "hostname": hostname,
        "timestamp": ts,
        "category": "ACL IP Addresses (comma-delimited)",
        "detail": acl_ip_list if acl_ip_list else "(none found)",
    })

    # PAT / overload lines resolved into actual ACL source networks + NAT interface IP
    pat_lines = categorized.get("pat_overload", [])
    interface_ips = categorized.get("interface_ips", {})
    resolved_pats = resolve_pat_overload_sources(pat_lines, acl_entries, interface_ips)
    if not resolved_pats:
        rows.append({
            "hostname": hostname, "timestamp": ts,
            "category": "PAT Overload - Resolved Sources", "detail": "(none found)",
            "acl_id": "", "acl_sources": "", "nat_interface": "", "nat_interface_ip": "",
        })
    else:
        for r in resolved_pats:
            rows.append({
                "hostname": hostname,
                "timestamp": ts,
                "category": "PAT Overload - Resolved Sources",
                "detail": r["detail"],
                "acl_id": r["acl_id"],
                "acl_sources": r["sources"],
                "nat_interface": r["nat_interface"],
                "nat_interface_ip": r["nat_interface_ip"],
            })

    # Interface inside/outside role
    intf_roles = categorized.get("nat_inside_outside", [])
    if not intf_roles:
        rows.append({"hostname": hostname, "timestamp": ts, "category": "Interface NAT Role", "detail": "(none found)"})
    else:
        for intf, role in intf_roles:
            detail = f"{intf or '<unknown interface>'}: ip nat {role}"
            rows.append({"hostname": hostname, "timestamp": ts, "category": "Interface NAT Role", "detail": detail})

    # Live translations - parsed into columns so "Inside local" (original packet
    # SOURCE) and "Outside local" (original packet DESTINATION, as addressed by
    # the inside host) are their own fields, not buried in raw text.
    translation_entries = parse_nat_translations(nat_translations or "")
    if not translation_entries:
        rows.append({
            "hostname": hostname, "timestamp": ts,
            "category": "NAT Translation", "detail": "(empty)",
            "protocol": "", "inside_global": "",
            "original_source_inside_local": "",
            "original_destination_outside_local": "",
            "outside_global": "",
        })
    else:
        for entry in translation_entries:
            rows.append({
                "hostname": hostname,
                "timestamp": ts,
                "category": "NAT Translation",
                "detail": entry["raw"],
                "protocol": entry["protocol"],
                "inside_global": entry["inside_global"],
                "original_source_inside_local": entry["inside_local"],
                "original_destination_outside_local": entry["outside_local"],
                "outside_global": entry["outside_global"],
            })

    # show ip nat statistics has no tabular structure worth parsing - keep as text lines
    for line in (nat_statistics or "").strip().splitlines() or ["(empty)"]:
        rows.append({"hostname": hostname, "timestamp": ts, "category": "show ip nat statistics", "detail": line})

    return rows


# --------------------------------------------------------------------------
# Main collection routine
# --------------------------------------------------------------------------

def collect_from_host(host, username, password, enable_secret):
    device = {
        "device_type": "cisco_ios",
        "host": host,
        "username": username,
        "password": password,
        "secret": enable_secret,
        "fast_cli": False,
    }

    try:
        conn = ConnectHandler(**device)
        try:
            conn.enable()
        except Exception:
            # Device may already be at privileged exec, or has no enable secret set.
            pass

        running_config = conn.send_command("show running-config", read_timeout=60)
        nat_translations = conn.send_command("show ip nat translations")
        nat_statistics = conn.send_command("show ip nat statistics")
        conn.disconnect()

        categorized = categorize_nat_lines(running_config)
        return build_rows(host, categorized, nat_translations, nat_statistics)

    except (NetmikoAuthenticationException, NetmikoTimeoutException) as e:
        return build_rows(host, {}, "", "", raw_error=str(e))
    except Exception as e:
        return build_rows(host, {}, "", "", raw_error=str(e))


def main():
    print("=== NAT / PAT Configuration Audit ===\n")
    hosts = prompt_for_hosts()
    username, password, enable_secret = prompt_for_credentials()

    all_rows = []
    for host in hosts:
        print(f"\nConnecting to {host} ...")
        rows = collect_from_host(host, username, password, enable_secret)
        for r in rows:
            print(f"  [{r['category']}] {r['detail']}")
        all_rows.extend(rows)

    # nat-pat-<date>-<time>.csv, e.g. nat-pat-20260924-153012.csv
    now = datetime.now()
    date_part = now.strftime("%Y%m%d")
    time_part = now.strftime("%H%M%S")
    out_path = f"nat-pat-{date_part}-{time_part}.csv"

    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"\nCSV report saved to: {out_path}")


if __name__ == "__main__":
    main()

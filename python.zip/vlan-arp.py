#!/usr/bin/env python3

import pandas as pd


def find_column(df, keywords):
    """
    Find a column containing one of the supplied keywords.
    """
    for col in df.columns:
        col_lower = col.strip().lower()

        for keyword in keywords:
            if keyword.lower() in col_lower:
                return col

    return None


def process_file(filename):

    try:
        df = pd.read_csv(filename)

        vlan_col = find_column(
            df,
            ["vlan"]
        )

        arp_col = find_column(
            df,
            [
                "arp count",
                "arp_count",
                "arp"
            ]
        )

        mac_col = find_column(
            df,
            [
                "dynamic mac count",
                "dynamic mac",
                "mac count",
                "dynamic_mac_count"
            ]
        )

        root_col = find_column(
            df,
            [
                "root bridge",
                "rootbridge"
            ]
        )

        if not vlan_col:
            raise ValueError(
                "VLAN column not found"
            )

        if not arp_col:
            raise ValueError(
                "ARP Count column not found"
            )

        if not mac_col:
            raise ValueError(
                "Dynamic MAC Count column not found"
            )

        if not root_col:
            raise ValueError(
                "Root Bridge column not found"
            )

        df[arp_col] = pd.to_numeric(
            df[arp_col],
            errors="coerce"
        ).fillna(0)

        df[mac_col] = pd.to_numeric(
            df[mac_col],
            errors="coerce"
        ).fillna(0)

        filtered_df = df[
            (df[arp_col] == 0)
            &
            (df[mac_col] == 0)
            &
            (
                df[root_col]
                .astype(str)
                .str.strip()
                .str.lower()
                .isin(
                    [
                        "no",
                        "n",
                        "false"
                    ]
                )
            )
        ].copy()

        filtered_df["Decom Candidate"] = "YES"

        return filtered_df[
            [
                vlan_col,
                arp_col,
                mac_col,
                root_col,
                "Decom Candidate"
            ]
        ]

    except Exception as e:

        print(
            f"\nError processing "
            f"{filename}: {e}"
        )

        return pd.DataFrame()


def main():

    print("\nVLAN Decommission Candidate Report")
    print("=" * 80)

    file1 = input(
        "\nEnter first CSV file: "
    ).strip()

    file2 = input(
        "Enter second CSV file: "
    ).strip()

    df1 = process_file(file1)
    df2 = process_file(file2)

    print("\n" + "=" * 80)
    print(f"RESULTS FROM: {file1}")
    print("=" * 80)

    if not df1.empty:
        print(df1.to_string(index=False))
    else:
        print("No matching VLANs found.")

    print("\n" + "=" * 80)
    print(f"RESULTS FROM: {file2}")
    print("=" * 80)

    if not df2.empty:
        print(df2.to_string(index=False))
    else:
        print("No matching VLANs found.")

    combined = pd.concat(
        [df1, df2],
        ignore_index=True
    ).drop_duplicates()

    print("\n" + "=" * 80)
    print("COMBINED DECOMMISSION CANDIDATES")
    print("=" * 80)

    if not combined.empty:

        print(
            combined.to_string(
                index=False
            )
        )

        output_file = (
            "vlan_cleanup_candidates.csv"
        )

        combined.to_csv(
            output_file,
            index=False
        )

        print(
            f"\nReport saved: "
            f"{output_file}"
        )

        print(
            f"Total Candidates: "
            f"{len(combined)}"
        )

    else:

        print(
            "No VLANs found matching "
            "all criteria."
        )

    print("\nCriteria Applied")
    print("-" * 80)
    print("ARP Count = 0")
    print("Dynamic MAC Count = 0")
    print("Root Bridge = No")
    print("Decom Candidate = YES")


if __name__ == "__main__":
    main()
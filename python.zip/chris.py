
#!/usr/bin/env python3
"""
Interface Summary Collector
- Prompts for hostname/IP, username, password (optional enable secret)
- Lets you pick between:
    1) Nexus 5K LSW1 (MON2-MDFA1-LSW1)
    2) Cisco 5609 DSW1 (legacy set)
    3) Cisco MON2-MDFA1-DSW1 (new set you provided)
- Runs 'show interface <intf> | include minute|protocol|Description' for specified interfaces
- Writes results to a timestamped text file named with hostname and datetime
"""

from netmiko import ConnectHandler
import getpass
from datetime import datetime
import re
import sys

def sanitize_filename(name: str) -> str:
    """Sanitize hostname for safe filename usage."""
    return re.sub(r"[^A-Za-z0-9_.-]", "_", name.strip())

# --- Interface inventories with contextual descriptions ---
# 1) LSW1: MON2-MDFA1-LSW1 (Nexus 5K)
NEXUS_5K_LSW1 = {
    "Eth100/1/21": "MKSC-PHSVPN-FW1 management",
    "Eth100/1/22": "MKSC-PHSFW-INT management",
    "Eth100/1/36": "MKSC-DOB-NFLDADJ 10.80.242.70 old admin login",
    "Eth101/1/3":  "MKSC-PTS-ASA management",
    "Eth101/1/4":  "MKSC-PTS-VPN2 management",
    "Eth101/1/5":  "MKSC-PTS-VP Management",
    "Eth101/1/37": "PHS VPN Router Project OZ",
    # Added per your request:
    "Eth105/1/9":  "MON2-IDFA1-PAL2 Management IP 10.80.253.101",
    "Eth105/1/15": "MON2-IDFA1-PAL2 Data E1   10.80.150.211",
    "Eth107/1/3":  "MKSC-DOB-SSLVPN Juniper SA4500 External",
}

# 2) DSW1: Cisco 5609 (legacy set kept for convenience)
CISCO_5609_DSW1 = {
    "Gi1/8/31": "MKSC-PHSVPN-EXT port 0 INT",
    "Gi1/8/32": "MKSC-PHSVPN-EXT port 7 LANFAIL",
    "Gi1/8/34": "MKSC-IBMFW-MCI Management - Vlan 253",
    "Gi1/8/35": "MKSC-IBMFW-MCI port 3 trunk vlan 112 & 114",
    "Gi1/8/36": "MKSC-IBMFW-MCI port 2 DEMO",
    "Gi1/8/37": "MKSC-IBMFW-MCI port 1 McK zone",
    "Gi1/8/38": "MKSC-IBMFW-MCI port 0 Internet Verizon",
    "Gi2/8/7":  "Juniper SSLVPN Dobrin",
    "Gi2/8/21": "internet access for MKSC-PTS-VPN",
    "Gi2/8/24": "MKSC-PTS-ASA-ACTIVE failover interface",
}

# 3) MON2-MDFA1-DSW1 (new set you provided)
MON2_MDFA1_DSW1 = {
    "Gi1/8/22": "MKSC-DOB-PHSFW-INT Failover",
    "Gi1/8/31": "MKSC-PHSVPN-EXT port 0 INT",
    "Gi1/8/32": "MKSC-PHSVPN-EXT port 7 LANFAIL",
    "Gi1/8/34": "MKSC-IBMFW-MCI Management - Vlan 253",
    "Gi1/8/35": "MKSC-IBMFW-MCI port 3 trunk vlan 112 & 114",
    "Gi1/8/36": "MKSC-IBMFW-MCI port 2 DEMO",
    "Gi1/8/37": "MKSC-IBMFW-MCI port 1 McK zone",
    "Gi1/8/38": "MKSC-IBMFW-MCI port 0 Internet Verizon",
    "Gi2/8/7":  "Juniper SSLVPN Dobrin",
    "Gi2/8/21": "internet access for MKSC-PTS-VPN",
    "Gi2/8/24": "MKSC-PTS-ASA-ACTIVE failover interface",
    "Gi1/8/19": "Mksc-dob-phsfw-int port 1",
    "Gi1/8/21": "Mksc-dob-phsfw-int port 0",
}

def main():
    print("Select device inventory:")
    print("  1) Nexus 5K LSW1 (MON2-MDFA1-LSW1)")
    print("  2) Cisco 5609 DSW1 (legacy)")
    print("  3) Cisco MON2-MDFA1-DSW1 (new)")
    choice = input("Enter 1, 2, or 3: ").strip()

    if choice == "1":
        inventory_name = "Nexus_5K_LSW1_MON2_MDFA1_LSW1"
        device_type = "cisco_nxos"   # NX-OS
        interfaces = NEXUS_5K_LSW1
    elif choice == "2":
        inventory_name = "Cisco_5609_DSW1"
        device_type = "cisco_ios"    # IOS/IOS-XE
        interfaces = CISCO_5609_DSW1
    elif choice == "3":
        inventory_name = "Cisco_MON2_MDFA1_DSW1"
        device_type = "cisco_ios"    # IOS/IOS-XE
        interfaces = MON2_MDFA1_DSW1
    else:
        print("Invalid selection. Exiting.")
        sys.exit(1)

    hostname = input("Enter device hostname or IP: ").strip()
    if not hostname:
        print("Hostname/IP is required. Exiting.")
        sys.exit(1)

    username = input("Enter username: ").strip()
    if not username:
        print("Username is required. Exiting.")
        sys.exit(1)

    password = getpass.getpass("Enter password: ")
    secret = getpass.getpass("Enter enable/secret (press Enter if not required): ")

    # Netmiko device parameters
    device = {
        "device_type": device_type,
        "host": hostname,
        "username": username,
        "password": password,
        "timeout": 60,
        "conn_timeout": 30,
    }
    if secret:
        device["secret"] = secret

    try:
        print(f"\nConnecting to {hostname} ({inventory_name})...")
        net_connect = ConnectHandler(**device)
        print("Connected successfully!")

        # Enable mode if secret provided (for IOS/IOS-XE devices)
        if secret and device_type.startswith("cisco_ios"):
            try:
                net_connect.enable()
            except Exception as e_en:
                print(f"Warning: enable mode failed: {e_en}")

        # Disable paging
        try:
            net_connect.send_command("terminal length 0")
        except Exception:
            pass  # NX-OS/IOS generally support this, ignore if not

        # Prepare output file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_host = sanitize_filename(hostname)
        filename = f"{safe_host}_{inventory_name}_summary_{timestamp}.txt"

        print("\nCollecting interface summaries...")
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"Device: {hostname}\nInventory: {inventory_name}\nChecked at: {timestamp}\n")
            f.write("Command filter: include minute | protocol | Description\n")
            f.write("-" * 70 + "\n")

            for intf, note in interfaces.items():
                cmd = f"show interface {intf} | include minute|protocol|Description"
                try:
                    output = net_connect.send_command(cmd, strip_prompt=True, strip_command=True)
                except Exception as cmd_err:
                    output = f"[ERROR running '{cmd}']: {cmd_err}"

                # Console output
                print(f"\nInterface: {intf}  ({note})")
                print(output if output.strip() else "(no matching lines)")
                print("-" * 50)

                # File output
                f.write(f"\nInterface: {intf}\nNote: {note}\n")
                f.write(output if output.strip() else "(no matching lines)")
                f.write("\n" + "-" * 50 + "\n")

        net_connect.disconnect()
        print(f"\nAll interfaces checked successfully!")
        print(f"Results saved to: {filename}")

    except Exception as e:
        print(f"\nError occurred: {e}")

if __name__ == "__main__":
    main()

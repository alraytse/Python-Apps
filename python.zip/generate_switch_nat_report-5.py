#!/usr/bin/env python3
"""Collect Cisco NAT/PAT statistics and configured NAT into the
switch_nat_report CSV format.

Live collection with prompts:
    python generate_switch_nat_report.py --output switch_nat_report.csv
    # Prompts for User ID, Password, and comma-delimited devices.

Live collection from an inventory file:
    python generate_switch_nat_report.py --inventory inventory.csv \
        --output switch_nat_report.csv

Offline parsing of saved command output:
    python generate_switch_nat_report.py --raw-dir command_outputs \
        --output switch_nat_report.csv

Inventory CSV columns:
    Device,Host,Username,Password,Port,Device_Type,Timeout

Timeout is optional; it overrides --timeout in seconds for that device only,
which is useful for individual hosts that are slow or flaky over SSH.
Password may be omitted from the inventory and supplied with --password-env
or interactively. Keep credentials out of source control.

By default this collects "show ip nat statistics" only. Add
--include-nat-config to also report what is CONFIGURED, resolved down to
plain Source -> NAT rows, e.g.:
    any        -> 143.112.197.41
    10.1.1.1   -> 143.112.197.41
This adds "show running-config nat" plus, for any list-based statement it
finds, "show ip access-lists <acl>" and "show running-config interface
<intf>" to resolve the ACL and the overloaded interface's IP.

    In --raw-dir (offline) mode, add matching files alongside the existing
    ones, named the same way (<Device>__<command with spaces as _>.txt):
        <Device>__show_running-config_nat.txt
        <Device>__show_ip_access-lists_<ACL_NAME>.txt   (one per referenced ACL)
        <Device>__show_running-config_interface_<INTF>.txt  (one per referenced interface)
        <Device>__show_object-group_name_<GROUP_NAME>.txt  (one per object-group
            referenced by "permit ip object-group <name> any" in an ACL, plus
            one per any group it nests via "group-object <name>")
    ACL/interface/object-group files are optional; if missing, that entry's
    NAT (or Object_Group_Hosts) column is reported as unresolved (e.g.
    "pool:POOL1 (unresolved)" or "(unresolved: GROUP_NAME)") rather than
    failing the whole run.

    When an ACL's source is an object-group (Cisco's "Object Groups for
    ACLs", on ASA and IOS/IOS-XE), its members are resolved via "show
    object-group name <name>" and listed in the Object_Group_Hosts column,
    semicolon-separated (hosts, networks as CIDR, and FQDNs). Nested groups
    ("group-object <name>") are followed automatically.
"""

from __future__ import annotations

import argparse
import csv
import getpass
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

try:
    from typing import TypedDict
except ImportError:  # pragma: no cover - Python 3.7 compatibility
    from typing_extensions import TypedDict

OUTPUT_FIELDS = [
    "Device",
    "Platform",
    "Record_Type",
    "Inside_Local",
    "Inside_Global",
    "Outside_Local",
    "Outside_Global",
    "Object_Group_Hosts",
    "Details",
]

STATISTICS_COMMAND = "show ip nat statistics"

# --- Configured NAT (as opposed to the live translation table) -----------
# "show ip nat translations" only lists sessions that are currently active.
# The commands/regexes below instead read what is actually *configured*:
# static one-to-one entries, and list(ACL)+pool/interface statements, with
# the referenced ACL and interface resolved so the report can show a plain
# Source -> NAT mapping (e.g. "any" or "10.1.1.1" -> "143.112.197.41").
NAT_CONFIG_COMMAND = "show running-config nat"
ACCESS_LIST_COMMAND_TEMPLATE = "show ip access-lists {acl}"
INTERFACE_COMMAND_TEMPLATE = "show running-config interface {intf}"
OBJECT_GROUP_COMMAND_TEMPLATE = "show object-group name {name}"

STATIC_NAT_RE = re.compile(
    r"^ip nat (?:inside|outside) source static\s+(?P<local>\S+)\s+(?P<global>\S+)",
    re.IGNORECASE,
)
POOL_DEF_RE = re.compile(
    r"^ip nat pool\s+(?P<name>\S+)\s+(?P<start>\S+)\s+(?P<end>\S+)",
    re.IGNORECASE,
)
LIST_POOL_RE = re.compile(
    r"^ip nat (?:inside|outside) source list\s+(?P<acl>\S+)\s+pool\s+(?P<pool>\S+)"
    r"(?P<overload>\s+overload)?",
    re.IGNORECASE,
)
LIST_INTERFACE_RE = re.compile(
    r"^ip nat (?:inside|outside) source list\s+(?P<acl>\S+)\s+interface\s+(?P<intf>\S+)"
    r"(?P<overload>\s+overload)?",
    re.IGNORECASE,
)
# NX-OS numbered ACL entry, e.g. "10 permit ip 10.1.1.0/24 any"
ACL_ENTRY_NXOS_RE = re.compile(
    r"^\s*\d+\s+(?P<action>permit|deny)\s+ip\s+(?P<src>any|host\s+\S+|\S+)\s+any",
    re.IGNORECASE,
)
# IOS-style ACL entry, e.g. "permit ip 10.1.1.0 0.0.0.255 any" or "permit ip host 10.1.1.1 any"
ACL_ENTRY_IOS_RE = re.compile(
    r"^\s*(?P<action>permit|deny)\s+ip\s+"
    r"(?:host\s+(?P<host>\S+)|(?P<any>any)|(?P<net>\d{1,3}(?:\.\d{1,3}){3})\s+(?P<wildcard>\d{1,3}(?:\.\d{1,3}){3}))"
    r"\s+any",
    re.IGNORECASE,
)
INTERFACE_IP_RE = re.compile(
    r"^\s*ip address\s+(?P<ip>\d{1,3}(?:\.\d{1,3}){3})",
    re.IGNORECASE | re.MULTILINE,
)

# ACL line whose source is an object-group rather than a plain address,
# e.g. "permit ip object-group Viptela_SDWAN_MPLS_IP any" (IOS/NX-OS), or
# "access-list ACLNAME extended permit ip object-group NAME any" (ASA).
ACL_ENTRY_OBJGRP_RE = re.compile(
    r"^(?:access-list\s+\S+\s+extended\s+)?"
    r"(?P<action>permit|deny)\s+ip\s+object-group\s+(?P<name>\S+)\s+any\b",
    re.IGNORECASE,
)

# "show object-group name <name>" member lines.
# ASA-style: "network-object host 10.1.1.5" / "network-object 10.2.0.0 255.255.255.0"
# IOS-style:  "10 host 10.1.1.5" / "20 10.2.0.0 255.255.255.0"
OBJGRP_HOST_RE = re.compile(
    r"^\s*(?:\d+\s+)?(?:network-object\s+)?host\s+(?P<ip>\d{1,3}(?:\.\d{1,3}){3})\s*$",
    re.IGNORECASE,
)
OBJGRP_NET_RE = re.compile(
    r"^\s*(?:\d+\s+)?(?:network-object\s+)?"
    r"(?P<net>\d{1,3}(?:\.\d{1,3}){3})\s+(?P<mask>\d{1,3}(?:\.\d{1,3}){3})\s*$",
    re.IGNORECASE,
)
OBJGRP_FQDN_RE = re.compile(
    r"^\s*(?:\d+\s+)?(?:network-object\s+)?fqdn\s+(?:v4\s+|v6\s+)?(?P<fqdn>\S+)\s*$",
    re.IGNORECASE,
)
# Nested reference to another object-group.
OBJGRP_NESTED_RE = re.compile(
    r"^\s*(?:\d+\s+)?group-object\s+(?P<name>\S+)\s*$",
    re.IGNORECASE,
)

PROMPT_RE = re.compile(r"^[\w.@:/-]+(?:#|>)$")


class InventoryRow(TypedDict, total=False):
    Device: str
    Host: str
    Username: str
    Password: str
    Port: str
    Device_Type: str
    Timeout: str


def make_row(
    device: str,
    record_type: str,
    command: str,
    details: str,
    inside_local: str = "",
    inside_global: str = "",
    outside_local: str = "",
    outside_global: str = "",
    object_group_hosts: str = "",
) -> Dict[str, str]:
    return {
        "Device": device,
        "Platform": "cisco_nxos",
        "Record_Type": record_type,
        "Inside_Local": inside_local,
        "Inside_Global": inside_global,
        "Outside_Local": outside_local,
        "Outside_Global": outside_global,
        "Object_Group_Hosts": object_group_hosts,
        "Details": details,
    }


CONTROL_CHAR_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def clean_line(raw_line: str) -> str:
    """Strip stray control/backspace characters left by --More-- pager erase
    sequences, then strip surrounding whitespace."""
    return CONTROL_CHAR_RE.sub("", raw_line).strip()


def is_noise(line: str, command: str) -> bool:
    """Return True for blank lines, command echoes, prompts, and pager text."""
    stripped = line.strip()
    if not stripped:
        return True
    if stripped == command:
        return True
    if PROMPT_RE.fullmatch(stripped):
        return True
    # Some platforms leave partial erase sequences around "--More--" instead
    # of a clean line, so match on prefix rather than an exact set.
    if stripped.startswith("--More--") or stripped == "terminal length 0":
        return True
    return False


# Fallback only: matches subinterface VLANs .300-.303, .310-.313, and .502.
# This was reverse-engineered from one site's PAT subinterface numbering and
# will misclassify statistics lines on any network that numbers VLANs
# differently. Override it with --pat-vlan-pattern, or pass "" to disable
# this fallback entirely and rely only on explicit NAT/PAT labels and
# Port-channel detection.
DEFAULT_PAT_VLAN_PATTERN = r"\.30[0-3]\b|\.31[0-3]\b|\.502\b"


def classify_statistics_line(line: str, pat_vlan_pattern: str = DEFAULT_PAT_VLAN_PATTERN) -> Tuple[str, str]:
    """Return (record type, cleaned details) for one statistics line."""
    explicit = re.match(r"^(NAT|PAT)\s{2,}(.*)$", line, re.IGNORECASE)
    if explicit:
        return explicit.group(1).upper(), explicit.group(2).strip()

    lower = line.lower()
    if "port block alloc fail" in lower:
        return "PAT", line

    # The sample report identifies PAT interface groups by PAT subinterfaces
    # and Port-channel NAT/PAT interfaces. This heuristic covers that format
    # when the switch output does not label the rows explicitly.
    if ("port-channel" in lower or "portchannel" in lower) and "." in line:
        return "PAT", line
    if pat_vlan_pattern and re.search(pat_vlan_pattern, line):
        return "PAT", line

    return "NAT", line


def parse_statistics(
    device: str, output: str, pat_vlan_pattern: str = DEFAULT_PAT_VLAN_PATTERN
) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    for raw_line in output.splitlines():
        line = clean_line(raw_line)
        if is_noise(line, STATISTICS_COMMAND):
            continue
        record_type, details = classify_statistics_line(line, pat_vlan_pattern)
        rows.append(make_row(device, record_type, STATISTICS_COMMAND, details))
    return rows


def parse_nat_config(output: str) -> Dict[str, object]:
    """Parse "show running-config nat" into its component statements.

    Returns a dict with:
      statics:        [(local, global, line), ...]
      pools:          {pool_name: (start, end, line)}
      list_pool:      [(acl, pool_name, overload_bool, line), ...]
      list_interface: [(acl, interface, overload_bool, line), ...]
    """
    statics: List[Tuple[str, str, str]] = []
    pools: Dict[str, Tuple[str, str, str]] = {}
    list_pool: List[Tuple[str, str, bool, str]] = []
    list_interface: List[Tuple[str, str, bool, str]] = []

    for raw_line in output.splitlines():
        line = clean_line(raw_line)
        if not line or line.startswith("!"):
            continue

        match = STATIC_NAT_RE.match(line)
        if match:
            statics.append((match.group("local"), match.group("global"), line))
            continue

        match = POOL_DEF_RE.match(line)
        if match:
            pools[match.group("name")] = (
                match.group("start"),
                match.group("end"),
                line,
            )
            continue

        match = LIST_POOL_RE.match(line)
        if match:
            list_pool.append(
                (
                    match.group("acl"),
                    match.group("pool"),
                    bool(match.group("overload")),
                    line,
                )
            )
            continue

        match = LIST_INTERFACE_RE.match(line)
        if match:
            list_interface.append(
                (
                    match.group("acl"),
                    match.group("intf"),
                    bool(match.group("overload")),
                    line,
                )
            )
            continue

    return {
        "statics": statics,
        "pools": pools,
        "list_pool": list_pool,
        "list_interface": list_interface,
    }


def referenced_acls_and_interfaces(
    parsed: Dict[str, object]
) -> Tuple[List[str], List[str]]:
    """Return the ACL names and interface names a parsed NAT config refers to."""
    acls = sorted(
        {acl for acl, _pool, _o, _line in parsed["list_pool"]}
        | {acl for acl, _intf, _o, _line in parsed["list_interface"]}
    )
    interfaces = sorted({intf for _acl, intf, _o, _line in parsed["list_interface"]})
    return acls, interfaces


def wildcard_to_cidr(network: str, wildcard: str) -> str:
    """Convert an IOS-style network + inverse (wildcard) mask to CIDR.

    Falls back to "network wildcard mask" if the wildcard isn't a clean
    contiguous mask (rare, but possible with discontiguous wildcards).
    """
    try:
        octets = [int(part) for part in wildcard.split(".")]
        if len(octets) != 4 or any(o < 0 or o > 255 for o in octets):
            raise ValueError
        inverse = [255 - o for o in octets]
        bits = "".join(f"{o:08b}" for o in inverse)
        if "01" in bits:  # not a contiguous run of 1s from the left
            raise ValueError
        prefix_len = bits.count("1")
        return f"{network}/{prefix_len}"
    except ValueError:
        return f"{network} wildcard {wildcard}"


def parse_acl_sources(output: str) -> List[Tuple[str, str]]:
    """Parse "show ip access-lists <acl>" (or IOS-style) into (action, source).

    Only the source field of "ip" entries is captured, since NAT list
    statements match on source address.
    """
    entries: List[Tuple[str, str]] = []
    for raw_line in output.splitlines():
        line = clean_line(raw_line)

        match = ACL_ENTRY_OBJGRP_RE.match(line)
        if match:
            entries.append((match.group("action").lower(), f"object-group:{match.group('name')}"))
            continue

        match = ACL_ENTRY_NXOS_RE.match(line)
        if match:
            src = match.group("src")
            if src.lower().startswith("host "):
                src = src.split(None, 1)[1]
            entries.append((match.group("action").lower(), src))
            continue

        match = ACL_ENTRY_IOS_RE.match(line)
        if match:
            if match.group("any"):
                src = "any"
            elif match.group("host"):
                src = match.group("host")
            else:
                src = wildcard_to_cidr(match.group("net"), match.group("wildcard"))
            entries.append((match.group("action").lower(), src))
            continue

    return entries


def netmask_to_cidr(network: str, netmask: str) -> str:
    """Convert a network + normal (not inverse) subnet mask to CIDR."""
    try:
        octets = [int(part) for part in netmask.split(".")]
        if len(octets) != 4 or any(o < 0 or o > 255 for o in octets):
            raise ValueError
        bits = "".join(f"{o:08b}" for o in octets)
        if "01" in bits:  # not a contiguous run of 1s from the left
            raise ValueError
        prefix_len = bits.count("1")
        return f"{network}/{prefix_len}"
    except ValueError:
        return f"{network} mask {netmask}"


def referenced_object_groups(acl_sources: Sequence[Tuple[str, str]]) -> List[str]:
    """Return the object-group names referenced by an ACL's source entries."""
    names = []
    for _action, src in acl_sources:
        if src.startswith("object-group:"):
            names.append(src.split(":", 1)[1])
    return sorted(set(names))


def parse_object_group_hosts(
    name: str,
    object_group_outputs: Dict[str, str],
    _seen: Optional[set] = None,
) -> List[str]:
    """Resolve "show object-group name <name>" output into a flat list of
    hosts/networks/FQDNs, following any nested "group-object <name>"
    references found in object_group_outputs. Returns
    ["(unresolved: <name>)"] if that group's output wasn't provided, and
    ["(circular reference: <name>)"] if a group refers back to itself.
    """
    _seen = _seen or set()
    if name in _seen:
        return [f"(circular reference: {name})"]
    _seen.add(name)

    output = object_group_outputs.get(name)
    if output is None:
        return [f"(unresolved: {name})"]

    members: List[str] = []
    for raw_line in output.splitlines():
        line = clean_line(raw_line)
        if not line or line.lower().startswith("object-group"):
            continue

        match = OBJGRP_NESTED_RE.match(line)
        if match:
            members.extend(
                parse_object_group_hosts(match.group("name"), object_group_outputs, _seen)
            )
            continue

        match = OBJGRP_HOST_RE.match(line)
        if match:
            members.append(match.group("ip"))
            continue

        match = OBJGRP_NET_RE.match(line)
        if match:
            members.append(netmask_to_cidr(match.group("net"), match.group("mask")))
            continue

        match = OBJGRP_FQDN_RE.match(line)
        if match:
            members.append(match.group("fqdn"))
            continue

    return members



def build_nat_config_rows(
    device: str,
    nat_config_output: str,
    acl_outputs: Optional[Dict[str, str]] = None,
    interface_outputs: Optional[Dict[str, str]] = None,
    object_group_outputs: Optional[Dict[str, str]] = None,
) -> List[Dict[str, str]]:
    """Turn configured NAT statements into Source -> NAT rows.

    Inside_Local holds the source (an address, network, or "any"; an ACL
    name prefixed with "ACL:" if it could not be resolved) and Inside_Global
    holds the NAT'd address, address range, or interface. Record_Type is
    "NAT_CONFIG" to distinguish these rows from the live translation table.
    """
    acl_outputs = acl_outputs or {}
    interface_outputs = interface_outputs or {}
    object_group_outputs = object_group_outputs or {}
    parsed = parse_nat_config(nat_config_output)
    rows: List[Dict[str, str]] = []

    def object_group_hosts_for(src: str) -> str:
        if not src.startswith("object-group:"):
            return ""
        name = src.split(":", 1)[1]
        return ";".join(parse_object_group_hosts(name, object_group_outputs))

    for local, global_, line in parsed["statics"]:
        rows.append(
            make_row(
                device,
                "NAT_CONFIG",
                NAT_CONFIG_COMMAND,
                line,
                inside_local=local,
                inside_global=global_,
            )
        )

    def pool_target(pool_name: str) -> str:
        pool = parsed["pools"].get(pool_name)
        if not pool:
            return f"pool:{pool_name} (unresolved)"
        start, end, _line = pool
        return start if start == end else f"{start}-{end}"

    def expand_acl(acl: str) -> List[str]:
        return [
            src for action, src in parse_acl_sources(acl_outputs.get(acl, ""))
            if action == "permit"
        ]

    # Track, per ACL, which NAT statement(s) use it and what they resolve to,
    # so the ACL-entry rows below can say what each entry does/doesn't create.
    acl_usage: Dict[str, List[str]] = {}

    for acl, pool_name, overload, line in parsed["list_pool"]:
        nat_target = pool_target(pool_name)
        suffix = " (overload/PAT)" if overload else ""
        acl_usage.setdefault(acl, []).append(f"NAT {nat_target}{suffix} via {line}")
        sources = expand_acl(acl)
        if not sources:
            rows.append(
                make_row(
                    device,
                    "NAT_CONFIG",
                    NAT_CONFIG_COMMAND,
                    f"{line} | ACL {acl} not resolved (no matching ACL output provided)",
                    inside_local=f"ACL:{acl}",
                    inside_global=nat_target,
                )
            )
            continue
        for src in sources:
            rows.append(
                make_row(
                    device,
                    "NAT_CONFIG",
                    NAT_CONFIG_COMMAND,
                    f"{line} | ACL {acl}: permit {src}{suffix}",
                    inside_local=src,
                    inside_global=nat_target,
                    object_group_hosts=object_group_hosts_for(src),
                )
            )

    for acl, intf, overload, line in parsed["list_interface"]:
        intf_match = INTERFACE_IP_RE.search(interface_outputs.get(intf, ""))
        nat_target = intf_match.group("ip") if intf_match else f"interface:{intf} (unresolved)"
        suffix = " (overload/PAT via interface)" if overload else " (via interface)"
        acl_usage.setdefault(acl, []).append(f"NAT {nat_target}{suffix} via {line}")
        sources = expand_acl(acl)
        if not sources:
            rows.append(
                make_row(
                    device,
                    "NAT_CONFIG",
                    NAT_CONFIG_COMMAND,
                    f"{line} | ACL {acl} not resolved (no matching ACL output provided)",
                    inside_local=f"ACL:{acl}",
                    inside_global=nat_target,
                )
            )
            continue
        for src in sources:
            rows.append(
                make_row(
                    device,
                    "NAT_CONFIG",
                    NAT_CONFIG_COMMAND,
                    f"{line} | ACL {acl}: permit {src}{suffix}",
                    inside_local=src,
                    inside_global=nat_target,
                    object_group_hosts=object_group_hosts_for(src),
                )
            )

    # Also list every entry of every referenced ACL on its own (Record_Type
    # "ACL"), including deny lines and permit lines whose ACL output wasn't
    # provided. This shows exactly what's in the ACL creating (or excluded
    # from) the NAT, not just the resolved Source -> NAT mapping above.
    for acl in sorted(acl_usage):
        acl_output = acl_outputs.get(acl, "")
        usage_summary = "; ".join(acl_usage[acl])
        if not acl_output:
            rows.append(
                make_row(
                    device,
                    "ACL",
                    ACCESS_LIST_COMMAND_TEMPLATE.format(acl=acl),
                    f"ACL {acl} not resolved (no matching ACL output provided) | feeds: {usage_summary}",
                    inside_local=f"ACL:{acl}",
                )
            )
            continue
        for action, src in parse_acl_sources(acl_output):
            if action == "permit":
                details = f"ACL {acl}: permit {src} | creates {usage_summary}"
            else:
                details = f"ACL {acl}: deny {src} | excluded from NAT (deny entry)"
            rows.append(
                make_row(
                    device,
                    "ACL",
                    ACCESS_LIST_COMMAND_TEMPLATE.format(acl=acl),
                    details,
                    inside_local=src,
                    object_group_hosts=object_group_hosts_for(src),
                )
            )

    return rows



def parse_device_outputs(
    device: str,
    statistics_output: str,
    pat_vlan_pattern: str = DEFAULT_PAT_VLAN_PATTERN,
    nat_config_output: Optional[str] = None,
    acl_outputs: Optional[Dict[str, str]] = None,
    interface_outputs: Optional[Dict[str, str]] = None,
    object_group_outputs: Optional[Dict[str, str]] = None,
) -> List[Dict[str, str]]:
    rows = parse_statistics(device, statistics_output, pat_vlan_pattern)
    if nat_config_output is not None:
        rows += build_nat_config_rows(
            device, nat_config_output, acl_outputs, interface_outputs, object_group_outputs
        )
    return rows


def prompt_live_inventory() -> List[InventoryRow]:
    """Prompt for credentials and comma-delimited device hostnames."""
    devices_text = input("Devices/IPs (comma-delimited): ").strip()
    devices = [device.strip() for device in devices_text.split(",") if device.strip()]
    if not devices:
        raise ValueError("At least one device hostname or IP address is required.")

    username = input("User ID: ").strip()
    if not username:
        raise ValueError("A user ID is required.")
    password = getpass.getpass("Password: ")
    if not password:
        raise ValueError("A password is required.")

    # Store credentials in memory only; they are not written to the report.
    return [
        {
            "Device": device,
            "Host": device,
            "Username": username,
            "Password": password,
            "Port": "22",
            "Device_Type": "cisco_nxos",
        }
        for device in devices
    ]


def read_inventory(path: Path) -> List[InventoryRow]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"Inventory is empty: {path}")

    required = {"Device", "Host"}
    missing = required - set(rows[0])
    if missing:
        raise ValueError(
            f"Inventory must contain columns {sorted(required)}; missing {sorted(missing)}"
        )

    result: List[InventoryRow] = []
    for index, row in enumerate(rows, start=2):
        device = (row.get("Device") or "").strip()
        host = (row.get("Host") or "").strip()
        if not device or not host:
            raise ValueError(f"Inventory row {index} must have Device and Host")
        result.append({key: (value or "").strip() for key, value in row.items()})
    return result


def load_credentials(
    inventory: Sequence[InventoryRow], password_env: str, prompt_password: bool
) -> Tuple[str, str]:
    username = next((r.get("Username", "") for r in inventory if r.get("Username")), "")
    password = next((r.get("Password", "") for r in inventory if r.get("Password")), "")
    username = username or os.getenv("NETMIKO_USERNAME", "")
    password = password or os.getenv(password_env, "")

    if not username:
        username = input("Username: ").strip()
    if not password and prompt_password:
        password = getpass.getpass("Password: ")
    if not username or not password:
        raise ValueError(
            "Credentials are missing. Set NETMIKO_USERNAME and "
            f"{password_env}, add them to inventory, or use interactive prompts."
        )
    return username, password


def collect_one(
    inventory_row: InventoryRow,
    username: str,
    password: str,
    timeout: int,
    pat_vlan_pattern: str = DEFAULT_PAT_VLAN_PATTERN,
    retries: int = 0,
    retry_delay: float = 5.0,
    include_nat_config: bool = False,
) -> Tuple[str, List[Dict[str, str]]]:
    # Lazy import keeps offline parsing usable without Netmiko installed.
    try:
        from netmiko import ConnectHandler
    except ImportError as exc:
        raise RuntimeError(
            "Live collection requires Netmiko. Install it with: pip install netmiko"
        ) from exc

    # Import paths for these exceptions moved between Netmiko versions; fall
    # back to a class that never matches rather than failing to import.
    try:
        from netmiko.exceptions import (
            NetmikoAuthenticationException,
            NetmikoTimeoutException,
        )
    except ImportError:
        try:
            from netmiko.ssh_exception import (
                NetmikoAuthenticationException,
                NetmikoTimeoutException,
            )
        except ImportError:  # pragma: no cover - unexpected Netmiko layout

            class NetmikoAuthenticationException(Exception):
                pass

            class NetmikoTimeoutException(Exception):
                pass

    device = inventory_row["Device"]
    row_timeout_raw = (inventory_row.get("Timeout") or "").strip()
    device_timeout = timeout
    if row_timeout_raw:
        try:
            device_timeout = int(row_timeout_raw)
            if device_timeout <= 0:
                raise ValueError
        except ValueError:
            print(
                f"Warning: ignoring invalid Timeout {row_timeout_raw!r} for "
                f"{device}; using {timeout}s default.",
                file=sys.stderr,
            )
            device_timeout = timeout

    params = {
        "device_type": inventory_row.get("Device_Type") or "cisco_nxos",
        "host": inventory_row["Host"],
        "username": inventory_row.get("Username") or username,
        "password": inventory_row.get("Password") or password,
        "port": int(inventory_row.get("Port") or 22),
        "conn_timeout": device_timeout,
        "auth_timeout": device_timeout,
        "banner_timeout": device_timeout,
        "fast_cli": False,
    }

    attempt = 0
    while True:
        attempt += 1
        connection = None
        try:
            connection = ConnectHandler(**params)
            statistics = connection.send_command(
                STATISTICS_COMMAND,
                read_timeout=device_timeout,
                strip_prompt=False,
                strip_command=False,
            )

            nat_config: Optional[str] = None
            acl_outputs: Dict[str, str] = {}
            interface_outputs: Dict[str, str] = {}
            object_group_outputs: Dict[str, str] = {}
            if include_nat_config:
                nat_config = connection.send_command(
                    NAT_CONFIG_COMMAND,
                    read_timeout=device_timeout,
                    strip_prompt=False,
                    strip_command=False,
                )
                acls, interfaces = referenced_acls_and_interfaces(parse_nat_config(nat_config))
                for acl in acls:
                    acl_outputs[acl] = connection.send_command(
                        ACCESS_LIST_COMMAND_TEMPLATE.format(acl=acl),
                        read_timeout=device_timeout,
                        strip_prompt=False,
                        strip_command=False,
                    )
                for intf in interfaces:
                    interface_outputs[intf] = connection.send_command(
                        INTERFACE_COMMAND_TEMPLATE.format(intf=intf),
                        read_timeout=device_timeout,
                        strip_prompt=False,
                        strip_command=False,
                    )

                pending = set()
                for acl_output in acl_outputs.values():
                    pending.update(referenced_object_groups(parse_acl_sources(acl_output)))
                # Nested "group-object" references can chain further groups,
                # so keep resolving until nothing new turns up (capped, so a
                # misconfigured cycle can't loop forever).
                for _ in range(10):
                    pending -= set(object_group_outputs)
                    if not pending:
                        break
                    for name in list(pending):
                        object_group_outputs[name] = connection.send_command(
                            OBJECT_GROUP_COMMAND_TEMPLATE.format(name=name),
                            read_timeout=device_timeout,
                            strip_prompt=False,
                            strip_command=False,
                        )
                    pending = set()
                    for output in object_group_outputs.values():
                        for raw_line in output.splitlines():
                            nested = OBJGRP_NESTED_RE.match(clean_line(raw_line))
                            if nested:
                                pending.add(nested.group("name"))

            return device, parse_device_outputs(
                device,
                statistics,
                pat_vlan_pattern,
                nat_config_output=nat_config,
                acl_outputs=acl_outputs,
                interface_outputs=interface_outputs,
                object_group_outputs=object_group_outputs,
            )
        except NetmikoAuthenticationException:
            # Retrying with the same credentials won't succeed and can
            # trigger account lockout on TACACS+/RADIUS-backed devices.
            raise
        except Exception as exc:
            if attempt > retries:
                raise
            wait = retry_delay * attempt
            print(
                f"Warning: {device} attempt {attempt}/{retries + 1} failed "
                f"({exc}); retrying in {wait:.0f}s",
                file=sys.stderr,
            )
            time.sleep(wait)
        finally:
            if connection:
                connection.disconnect()


def collect_live(
    inventory: Sequence[InventoryRow],
    username: str,
    password: str,
    timeout: int,
    workers: int,
    pat_vlan_pattern: str = DEFAULT_PAT_VLAN_PATTERN,
    retries: int = 0,
    retry_delay: float = 5.0,
    include_nat_config: bool = False,
) -> List[Dict[str, str]]:
    collected: Dict[str, List[Dict[str, str]]] = {}
    with ThreadPoolExecutor(max_workers=max(1, workers)) as executor:
        futures = {
            executor.submit(
                collect_one,
                row,
                username,
                password,
                timeout,
                pat_vlan_pattern,
                retries,
                retry_delay,
                include_nat_config,
            ): row
            for row in inventory
        }
        for future in as_completed(futures):
            row = futures[future]
            device = row["Device"]
            try:
                name, records = future.result()
                collected[name] = records
                print(f"Collected {len(records)} records from {name}")
            except Exception as exc:
                print(f"Error: {device} failed: {exc}", file=sys.stderr)

    # Keep output deterministic and match the inventory order.
    output: List[Dict[str, str]] = []
    for row in inventory:
        output.extend(collected.get(row["Device"], []))
    return output


def raw_file_candidates(raw_dir: Path, device: str, command: str) -> Iterable[Path]:
    safe_device = re.sub(r"[^A-Za-z0-9_.-]+", "_", device)
    safe_command = command.replace(" ", "_")
    yield raw_dir / f"{safe_device}__{safe_command}.txt"
    yield raw_dir / f"{device}__{safe_command}.txt"


def read_raw_output(raw_dir: Path, device: str, command: str) -> str:
    for candidate in raw_file_candidates(raw_dir, device, command):
        if candidate.exists():
            return candidate.read_text(encoding="utf-8", errors="replace")
    expected = next(raw_file_candidates(raw_dir, device, command))
    raise FileNotFoundError(f"Missing raw command output: {expected}")


def read_raw_output_optional(raw_dir: Path, device: str, command: str) -> Optional[str]:
    """Like read_raw_output, but returns None instead of raising when the
    file is missing. Used for ACL/interface files that only exist for the
    subset of ACLs/interfaces a device's NAT config actually references."""
    for candidate in raw_file_candidates(raw_dir, device, command):
        if candidate.exists():
            return candidate.read_text(encoding="utf-8", errors="replace")
    return None


def parse_raw_directory(
    inventory: Sequence[InventoryRow],
    raw_dir: Path,
    pat_vlan_pattern: str = DEFAULT_PAT_VLAN_PATTERN,
    include_nat_config: bool = False,
) -> List[Dict[str, str]]:
    output: List[Dict[str, str]] = []
    for row in inventory:
        device = row["Device"]
        statistics = read_raw_output(raw_dir, device, STATISTICS_COMMAND)

        nat_config: Optional[str] = None
        acl_outputs: Dict[str, str] = {}
        interface_outputs: Dict[str, str] = {}
        object_group_outputs: Dict[str, str] = {}
        if include_nat_config:
            nat_config = read_raw_output_optional(raw_dir, device, NAT_CONFIG_COMMAND) or ""
            acls, interfaces = referenced_acls_and_interfaces(parse_nat_config(nat_config))
            for acl in acls:
                text = read_raw_output_optional(
                    raw_dir, device, ACCESS_LIST_COMMAND_TEMPLATE.format(acl=acl)
                )
                if text is not None:
                    acl_outputs[acl] = text
                else:
                    expected = ACCESS_LIST_COMMAND_TEMPLATE.format(acl=acl).replace(" ", "_")
                    print(
                        f"Warning: {device}: no raw file found for ACL {acl!r} "
                        f"(expected {expected}); its NAT entries will be "
                        "reported unresolved.",
                        file=sys.stderr,
                    )
            for intf in interfaces:
                text = read_raw_output_optional(
                    raw_dir, device, INTERFACE_COMMAND_TEMPLATE.format(intf=intf)
                )
                if text is not None:
                    interface_outputs[intf] = text
                else:
                    print(
                        f"Warning: {device}: no raw file found for interface "
                        f"{intf!r}; its NAT entries will be reported unresolved.",
                        file=sys.stderr,
                    )

            pending = set()
            for acl_output in acl_outputs.values():
                pending.update(referenced_object_groups(parse_acl_sources(acl_output)))
            for _ in range(10):
                pending -= set(object_group_outputs)
                if not pending:
                    break
                for name in list(pending):
                    text = read_raw_output_optional(
                        raw_dir, device, OBJECT_GROUP_COMMAND_TEMPLATE.format(name=name)
                    )
                    if text is not None:
                        object_group_outputs[name] = text
                    else:
                        print(
                            f"Warning: {device}: no raw file found for object-group "
                            f"{name!r}; its hosts will be reported unresolved.",
                            file=sys.stderr,
                        )
                pending = set()
                for output_text in object_group_outputs.values():
                    for raw_line in output_text.splitlines():
                        nested = OBJGRP_NESTED_RE.match(clean_line(raw_line))
                        if nested:
                            pending.add(nested.group("name"))

        output.extend(
            parse_device_outputs(
                device,
                statistics,
                pat_vlan_pattern,
                nat_config_output=nat_config,
                acl_outputs=acl_outputs,
                interface_outputs=interface_outputs,
                object_group_outputs=object_group_outputs,
            )
        )
    return output


def write_report(rows: Sequence[Dict[str, str]], output: Path, encoding: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding=encoding, newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Collect Cisco NX-OS NAT/PAT statistics and configured NAT into CSV."
    )
    source = parser.add_mutually_exclusive_group(required=False)
    source.add_argument(
        "--inventory",
        type=Path,
        help="CSV with Device and Host columns for live Netmiko collection. If omitted, prompts for devices.",
    )
    source.add_argument(
        "--raw-dir",
        type=Path,
        help="Directory containing saved command output files for offline parsing.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("switch_nat_report.csv"),
        help="Output CSV path (default: switch_nat_report.csv).",
    )
    parser.add_argument(
        "--encoding",
        default="utf-8-sig",
        help="Output encoding (default: utf-8-sig; cp1252 matches the attached file).",
    )
    parser.add_argument("--timeout", type=int, default=30, help="Device timeout in seconds.")
    parser.add_argument("--workers", type=int, default=15, help="Parallel device sessions.")
    parser.add_argument(
        "--retries",
        type=int,
        default=0,
        help=(
            "Extra attempts for a device after a transient connection/timeout "
            "failure (default: 0, no retries). Authentication failures are "
            "never retried, since the same credentials will just fail again "
            "and repeated attempts can trigger account lockout."
        ),
    )
    parser.add_argument(
        "--retry-delay",
        type=float,
        default=5.0,
        help="Base delay in seconds between retries; scales linearly with attempt number (default: 5).",
    )
    parser.add_argument(
        "--password-env",
        default="NETMIKO_PASSWORD",
        help="Environment variable containing the shared password.",
    )
    parser.add_argument(
        "--no-password-prompt",
        action="store_true",
        help="Do not prompt if the password is missing; fail instead.",
    )
    parser.add_argument(
        "--include-nat-config",
        action="store_true",
        help=(
            "Also collect what is CONFIGURED (not just what's currently "
            "translating): static entries plus list/pool and list/interface "
            "statements, with referenced ACLs and interfaces resolved into "
            "plain Source -> NAT rows (Record_Type=NAT_CONFIG). Also resolves "
            "any object-group referenced as an ACL source into its member "
            "hosts (Object_Group_Hosts column, semicolon-separated), "
            "following nested group-object references. Live mode runs 'show "
            "running-config nat' plus 'show ip access-lists <acl>', 'show "
            "running-config interface <intf>', and 'show object-group name "
            "<name>' for anything it references. Offline mode looks for "
            "matching raw files (see --raw-dir help in the module docstring)."
        ),
    )
    parser.add_argument(
        "--pat-vlan-pattern",
        default=DEFAULT_PAT_VLAN_PATTERN,
        help=(
            "Regex used as a fallback to classify unlabeled statistics lines "
            "as PAT based on subinterface VLAN numbering. This is site-specific "
            f"(default: {DEFAULT_PAT_VLAN_PATTERN!r}); pass an empty string to "
            "disable this fallback and rely only on explicit NAT/PAT labels "
            "and Port-channel detection."
        ),
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    if args.timeout <= 0:
        print("Error: --timeout must be a positive number of seconds.", file=sys.stderr)
        return 1
    if args.workers <= 0:
        print("Error: --workers must be a positive integer.", file=sys.stderr)
        return 1
    if args.retries < 0:
        print("Error: --retries must be zero or a positive integer.", file=sys.stderr)
        return 1
    if args.retry_delay < 0:
        print("Error: --retry-delay must be zero or positive.", file=sys.stderr)
        return 1

    try:
        if args.raw_dir:
            inventory_path = args.raw_dir / "inventory.csv"
            if not inventory_path.exists():
                raise ValueError(
                    f"Offline mode expects {inventory_path} so device names can be mapped."
                )
            inventory = read_inventory(inventory_path)
            rows = parse_raw_directory(
                inventory, args.raw_dir, args.pat_vlan_pattern, args.include_nat_config
            )
        else:
            if args.inventory:
                inventory = read_inventory(args.inventory)
                if any(row.get("Password") for row in inventory):
                    print(
                        f"Warning: plaintext password found in {args.inventory}. "
                        "Prefer --password-env or interactive prompts, and keep "
                        "this file out of source control.",
                        file=sys.stderr,
                    )
                username, password = load_credentials(
                    inventory, args.password_env, not args.no_password_prompt
                )
            else:
                inventory = prompt_live_inventory()
                username = inventory[0]["Username"]
                password = inventory[0]["Password"]
            rows = collect_live(
                inventory,
                username,
                password,
                args.timeout,
                args.workers,
                args.pat_vlan_pattern,
                args.retries,
                args.retry_delay,
                args.include_nat_config,
            )

        write_report(rows, args.output, args.encoding)
        print(f"Wrote {len(rows)} records to {args.output}")
        return 0 if rows else 2
    except (OSError, ValueError, FileNotFoundError, RuntimeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3

import csv
import re
import xml.etree.ElementTree as ET
import requests
import urllib3
from netmiko import ConnectHandler

urllib3.disable_warnings()

PANORAMA_HOST = "panorama.company.com"
PANORAMA_API_KEY = "PASTE_API_KEY_HERE"

DEVICES = [
    {
        "device_type": "cisco_nxos",
        "host": "10.1.1.1",
        "username": "admin",
        "password": "password"
    }
]

INPUT_CSV = "subnets.csv"
OUTPUT_CSV = "subnet_audit_results.csv"

def panorama_api_call(xpath):
    url = (f"https://{PANORAMA_HOST}/api/?type=config&action=get&xpath={xpath}&key={PANORAMA_API_KEY}")
    r = requests.get(url, verify=False, timeout=30)
    r.raise_for_status()
    return ET.fromstring(r.text)

def search_panorama(xpath, search_text):
    refs = []
    try:
        root = panorama_api_call(xpath)
        for entry in root.findall('.//entry'):
            name = entry.get('name', 'UNKNOWN')
            xml_text = ET.tostring(entry, encoding='unicode')
            if search_text in xml_text:
                refs.append(name)
    except Exception:
        pass
    return refs

def panorama_address_refs(subnet):
    return search_panorama('/config/shared/address', subnet.split('/')[0])

def panorama_addressgroup_refs(subnet):
    return search_panorama('/config/shared/address-group', subnet.split('/')[0])

def panorama_nat_refs(subnet):
    refs=[]
    for p in ['/config/shared/pre-rulebase/nat/rules','/config/shared/post-rulebase/nat/rules']:
        refs.extend(search_panorama(p, subnet.split('/')[0]))
    return refs

def panorama_security_refs(subnet):
    refs=[]
    for p in ['/config/shared/pre-rulebase/security/rules','/config/shared/post-rulebase/security/rules']:
        refs.extend(search_panorama(p, subnet.split('/')[0]))
    return refs

if __name__ == '__main__':
    print('Subnet audit framework with Panorama integration')

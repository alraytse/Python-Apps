#!/usr/bin/env python3

import csv
import getpass
import re
from datetime import datetime
from netmiko import ConnectHandler

OUTPUT_FILE = (
    f"decom_candidates_"
    f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
)

###############################################################################
# USER INPUT
###############################################################################

def get_subnets():

    print("\nEnter subnets separated by commas")
    print("Example:")
    print("143.112.136.0/24,143.112.137.0/24")

    value = input(
        "\nSubnets: "
    ).strip()

    return [
        subnet.strip()
        for subnet in value.split(",")
        if subnet.strip()
    ]


def get_switches():

    print("\nEnter switches separated by commas")
    print("Example:")
    print("DDC1-ISP-ASW1,DDC1-ISP-ASW2")

    value = input(
        "\nSwitches: "
    ).strip()

    return [
        sw.strip()
        for sw in value.split(",")
        if sw.strip()
    ]

###############################################################################
# ROUTE FUNCTIONS
###############################################################################

def classify_route(route_output):

    route_text = route_output.lower()

    if "null0" in route_text:
        return "Null0"

    if "vlan" in route_text:
        return "Connected"

    if "static" in route_text:
        return "Static"

    if "bgp" in route_text:
        return "BGP"

    return "Unknown"


def extract_vlan(route_output):

    match = re.search(
        r"vlan(\d+)",
        route_output,
        re.IGNORECASE
    )

    if match:
        return match.group(1)

    return ""


def extract_interface(route_output):

    patterns = [

        r'Vlan\d+',
        r'Ethernet\S+',
        r'Port-channel\S+',
        r'Loopback\d+'

    ]

    for pattern in patterns:

        match = re.search(
            pattern,
            route_output,
            re.IGNORECASE
        )

        if match:
            return match.group(0)

    return ""


def extract_next_hop(route_output):

    match = re.search(
        r'via\s+(\d+\.\d+\.\d+\.\d+)',
        route_output
    )

    if match:
        return match.group(1)

    return ""

###############################################################################
# DEVICE COLLECTION
###############################################################################

def get_route(conn, subnet):

    commands = [

        f"show ip route {subnet}",
        f"show route {subnet}"

    ]

    for command in commands:

        try:

            output = conn.send_command(
                command
            )

            if output:
                return output

        except Exception:
            pass

    return ""


def get_bgp_status(conn, subnet):

    commands = [

        f"show ip bgp {subnet}",
        f"show bgp ipv4 unicast {subnet}"

    ]

    for command in commands:

        try:

            output = conn.send_command(
                command
            )

            if output and \
               "not in table" not in output.lower() and \
               "network not in table" not in output.lower():

                return True

        except Exception:
            pass

    return False


def get_arp_count(conn, vlan):

    if not vlan:
        return 0

    try:

        output = conn.send_command(
            f"show ip arp vlan {vlan}"
        )

    except Exception:

        return 0

    count = 0

    for line in output.splitlines():

        if "incomplete" in line.lower():
            continue

        if re.search(
            r'\d+\.\d+\.\d+\.\d+',
            line
        ):
            count += 1

    return count

###############################################################################
# SCORING
###############################################################################

def calculate_score(
        route_type,
        arp_count,
        bgp_present):

    score = 100

    if route_type != "Null0":
        score -= 30

    if arp_count > 0:
        score -= 40

    if bgp_present:
        score -= 30

    return max(score, 0)


def classify_candidate(
        route_type,
        arp_count,
        bgp_present):

    if (
        route_type == "Null0"
        and arp_count == 0
        and not bgp_present
    ):
        return "HIGH_CONFIDENCE_DECOM"

    if arp_count == 0:
        return "REVIEW_REQUIRED"

    return "ACTIVE"

###############################################################################
# MAIN
###############################################################################

def main():

    print(
        "\nSubnet Decommission Candidate Discovery Tool\n"
    )

    subnets = get_subnets()

    switches = get_switches()

    username = input(
        "\nUsername: "
    ).strip()

    password = getpass.getpass(
        "Password: "
    )

    results = []

    for switch in switches:

        print(
            f"\nConnecting to {switch}"
        )

        device = {

            "device_type":
                "cisco_nxos",

            "host":
                switch,

            "username":
                username,

            "password":
                password,

        }

        try:

            conn = ConnectHandler(
                **device
            )

        except Exception as e:

            print(
                f"Failed to connect "
                f"{switch}: {e}"
            )

            continue

        for subnet in subnets:

            print(
                f"Checking {subnet}"
            )

            route_output = get_route(
                conn,
                subnet
            )

            route_type = classify_route(
                route_output
            )

            vlan = extract_vlan(
                route_output
            )

            interface = extract_interface(
                route_output
            )

            next_hop = extract_next_hop(
                route_output
            )

            arp_count = get_arp_count(
                conn,
                vlan
            )

            bgp_present = get_bgp_status(
                conn,
                subnet
            )

            score = calculate_score(
                route_type,
                arp_count,
                bgp_present
            )

            status = classify_candidate(
                route_type,
                arp_count,
                bgp_present
            )

            results.append({

                "Subnet":
                    subnet,

                "Switch":
                    switch,

                "RouteType":
                    route_type,

                "Interface":
                    interface,

                "VLAN":
                    vlan,

                "NextHop":
                    next_hop,

                "ARP_Count":
                    arp_count,

                "BGP_Advertised":
                    bgp_present,

                "Score":
                    score,

                "Status":
                    status

            })

        conn.disconnect()

    if not results:

        print(
            "\nNo results collected."
        )

        return

    headers = [

        "Subnet",
        "Switch",
        "RouteType",
        "Interface",
        "VLAN",
        "NextHop",
        "ARP_Count",
        "BGP_Advertised",
        "Score",
        "Status"

    ]

    with open(
            OUTPUT_FILE,
            "w",
            newline=""
    ) as outfile:

        writer = csv.DictWriter(
            outfile,
            fieldnames=headers
        )

        writer.writeheader()

        writer.writerows(
            results
        )

    print(
        f"\nCSV Report Written To:"
    )
    print(
        OUTPUT_FILE
    )

    print(
        "\nHigh Confidence Candidates\n"
    )

    for row in results:

        if row["Status"] == \
                "HIGH_CONFIDENCE_DECOM":

            print(
                f"{row['Subnet']} "
                f"({row['Switch']})"
            )


if __name__ == "__main__":
    main()
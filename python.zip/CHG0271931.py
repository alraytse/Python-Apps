import paramiko
import difflib
import getpass
import os
from datetime import datetime, UTC

COMMANDS = [
    "copy running-config start",
    "checkpoint Before-CHG0271931",
    "terminal length 0",
    "show clock",
    "show version",
    "show running-config",
    "show ip route summary",
    "show ip route summary vrf all",
    "show ip bgp summary",
    "show interface status",
    "show ip interface brief",
    "show ip interface brief vrf all",
    "show interface description",
    "show route-map",
    "show ip prefix-list",
    "show logging last 50",
    "show ip route vrf all",
    "show ip bgp vrf all"
]

def ssh_and_capture_output(hostname, username, password, filename):
    client = None
    output_lines = []

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname,
            username=username,
            password=password,
            look_for_keys=False,
            timeout=10,
            banner_timeout=10,
            auth_timeout=10
        )

        header = (
            f"Hostname: {hostname}\n"
            f"Captured: {datetime.now(UTC)}\n"
            f"{'=' * 70}\n"
        )
        output_lines.append(header)

        for cmd in COMMANDS:
            stdin, stdout, stderr = client.exec_command(cmd)
            output = stdout.read().decode(errors="ignore")
            output_lines.append(f"\n=== {cmd} ===\n{output}")

        with open(filename, "w") as f:
            f.write("".join(output_lines))

        print(f"✅ Output written to {filename}")

    except Exception as e:
        print(f"❌ {hostname}: SSH failed → {e}")

    finally:
        if client:
            client.close()

def compare_files(before_file, after_file, diff_file):
    try:
        with open(before_file) as f1, open(after_file) as f2:
            diff = difflib.unified_diff(
                f1.readlines(),
                f2.readlines(),
                fromfile=before_file,
                tofile=after_file
            )

        diff_output = "".join(diff)

        with open(diff_file, "w") as f:
            if diff_output:
                f.write(diff_output)
            else:
                f.write("✅ No differences detected\n")

        print(f"📄 Diff written to {diff_file}")

    except FileNotFoundError as e:
        print(f"❌ Missing file: {e}")

def main():
    raw_hosts = input("Enter hostnames (comma-separated): ")
    hosts = [h.strip() for h in raw_hosts.split(",") if h.strip()]

    username = input("Enter EID: ").strip()
    password = getpass.getpass("Enter password: ")

    first_run = input("Is this the first run? (y/n): ").strip().lower()

    # ✅ Force valid Change Number
    while True:
        change_number = input("Enter Change Number (e.g. CHG0267862): ").strip()
        if change_number:
            break
        print("❌ Change Number cannot be empty. Please enter a valid Change Number.")

    os.makedirs(change_number, exist_ok=True)

    for host in hosts:
        print(f"\n--- Processing {host} ---")

        before_file = os.path.join(change_number, f"{host}.before")
        after_file = os.path.join(change_number, f"{host}.after")
        diff_file = os.path.join(change_number, f"{host}.compare")

        if first_run == "y":
            ssh_and_capture_output(host, username, password, before_file)
        else:
            ssh_and_capture_output(host, username, password, after_file)
            compare_files(before_file, after_file, diff_file)

if __name__ == "__main__":
    main()

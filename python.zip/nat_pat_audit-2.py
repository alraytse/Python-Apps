#!/usr/bin/env python3
"""
nat_pat_audit.py

Connects to one or more Cisco IOS routers over SSH and pulls back
NAT / PAT related configuration and state:

    1. Static NAT            - ip nat inside source static <local> <global>
    2. Dynamic NAT            - ip nat pool / ip nat inside source list <acl> pool <pool>
    3. PAT (NAT Overload)     - ip nat inside source list <acl> interface <intf> overload
    4. Static PAT (PF)        - ip nat inside source static tcp/udp <local> <lport> <global> <gport>
    5. Inside/Outside intf    - interface ... ip nat inside / ip nat outside
    6. Live state             - show ip nat translations / show ip nat statistics

Output: a single CSV file named nat-pat-<YYYYMMDD>-<HHMMSS>.csv containing
one row per finding, across all routers queried.

Requires: netmiko
    pip install netmiko --break-system-packages

Usage:
    python3 nat_pat_audit.py
    (You'll be prompted for hostnames, username, and password.)
"""

import csv
import getpass
import re
import sys
from datetime import datetime

try:
    from netmiko import ConnectHandler
    from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException
except ImportError:
    print("This script requires netmiko. Install it with:")
    print("    pip install netmiko --break-system-packages")
    sys.exit(1)


# --------------------------------------------------------------------------
# Prompting
# --------------------------------------------------------------------------

def prompt_for_hosts():
    raw = input("Enter router hostname(s) or IP(s) (comma-delimited): ").strip()
    hosts = [h.strip() for h in raw.split(",") if h.strip()]
    if not hosts:
        print("No hosts provided. Exiting.")
        sys.exit(1)
    return hosts


def prompt_for_credentials():
    username = input("Enter username: ").strip()
    password = getpass.getpass("Enter password: ")
    enable_secret = getpass.getpass("Enter enable/secret password (press Enter to reuse login password): ")
    if not enable_secret:
        enable_secret = password
    return username, password, enable_secret


# --------------------------------------------------------------------------
# Parsing helpers
# --------------------------------------------------------------------------

def categorize_nat_lines(running_config):
    """
    Walk the running-config text and bucket every NAT-relevant line
    into the categories described in the module docstring.
    """
    results = {
        "static_nat": [],
        "dynamic_nat_pools": [],
        "dynamic_nat_bindings": [],
        "pat_overload": [],
        "static_pat": [],
        "acls_referenced": [],
        "nat_inside_outside": [],
    }

    lines = running_config.splitlines()
    current_interface = None

    for line in lines:
        stripped = line.strip()

        # Track which interface stanza we're inside, so we can attach
        # "ip nat inside/outside" lines to their interface name.
        intf_match = re.match(r"^interface\s+(\S+)", stripped)
        if intf_match:
            current_interface = intf_match.group(1)
            continue

        if stripped.startswith("ip nat inside") and "source" not in stripped:
            results["nat_inside_outside"].append((current_interface, "inside"))
        elif stripped.startswith("ip nat outside"):
            results["nat_inside_outside"].append((current_interface, "outside"))

        # Static PAT: ip nat inside source static tcp|udp <local> <lport> <global> <gport> [extendable]
        elif re.match(r"^ip nat inside source static (tcp|udp)\s", stripped):
            results["static_pat"].append(stripped)

        # Static NAT: ip nat inside source static <local> <global>
        elif re.match(r"^ip nat inside source static\s+\S+\s+\S+", stripped):
            results["static_nat"].append(stripped)

        # PAT / NAT overload: ip nat inside source list <acl> interface <intf> overload
        elif "ip nat inside source list" in stripped and "overload" in stripped:
            results["pat_overload"].append(stripped)

        # Dynamic NAT binding: ip nat inside source list <acl> pool <pool> (no overload)
        elif "ip nat inside source list" in stripped and "pool" in stripped:
            results["dynamic_nat_bindings"].append(stripped)

        # NAT pool definition: ip nat pool <name> <start> <end> netmask <mask>
        elif stripped.startswith("ip nat pool"):
            results["dynamic_nat_pools"].append(stripped)

        # Referenced ACLs (access-list ... or ip access-list ...)
        elif re.match(r"^access-list\s+\d+\s", stripped) or stripped.startswith("ip access-list"):
            results["acls_referenced"].append(stripped)

    return results


CSV_FIELDS = ["hostname", "timestamp", "category", "detail"]

CATEGORY_LABELS = {
    "static_nat": "Static NAT",
    "dynamic_nat_pools": "Dynamic NAT Pool",
    "dynamic_nat_bindings": "Dynamic NAT Binding",
    "pat_overload": "PAT (NAT Overload)",
    "static_pat": "Static PAT (Port Forwarding)",
    "acls_referenced": "Referenced ACL",
}


def build_rows(hostname, categorized, nat_translations, nat_statistics, raw_error=None):
    """
    Convert one host's findings into a flat list of dict rows suitable
    for csv.DictWriter, using the CSV_FIELDS columns.
    """
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rows = []

    if raw_error:
        rows.append({
            "hostname": hostname,
            "timestamp": ts,
            "category": "ERROR",
            "detail": raw_error,
        })
        return rows

    # Config-derived categories
    for key, label in CATEGORY_LABELS.items():
        items = categorized.get(key, [])
        if not items:
            rows.append({"hostname": hostname, "timestamp": ts, "category": label, "detail": "(none found)"})
        else:
            for item in items:
                rows.append({"hostname": hostname, "timestamp": ts, "category": label, "detail": item})

    # Interface inside/outside role
    intf_roles = categorized.get("nat_inside_outside", [])
    if not intf_roles:
        rows.append({"hostname": hostname, "timestamp": ts, "category": "Interface NAT Role", "detail": "(none found)"})
    else:
        for intf, role in intf_roles:
            detail = f"{intf or '<unknown interface>'}: ip nat {role}"
            rows.append({"hostname": hostname, "timestamp": ts, "category": "Interface NAT Role", "detail": detail})

    # Live state - one row per line of output, so it's readable in a spreadsheet
    for line in (nat_translations or "").strip().splitlines() or ["(empty)"]:
        rows.append({"hostname": hostname, "timestamp": ts, "category": "show ip nat translations", "detail": line})

    for line in (nat_statistics or "").strip().splitlines() or ["(empty)"]:
        rows.append({"hostname": hostname, "timestamp": ts, "category": "show ip nat statistics", "detail": line})

    return rows


# --------------------------------------------------------------------------
# Main collection routine
# --------------------------------------------------------------------------

def collect_from_host(host, username, password, enable_secret):
    device = {
        "device_type": "cisco_ios",
        "host": host,
        "username": username,
        "password": password,
        "secret": enable_secret,
        "fast_cli": False,
    }

    try:
        conn = ConnectHandler(**device)
        try:
            conn.enable()
        except Exception:
            # Device may already be at privileged exec, or has no enable secret set.
            pass

        running_config = conn.send_command("show running-config", read_timeout=60)
        nat_translations = conn.send_command("show ip nat translations")
        nat_statistics = conn.send_command("show ip nat statistics")
        conn.disconnect()

        categorized = categorize_nat_lines(running_config)
        return build_rows(host, categorized, nat_translations, nat_statistics)

    except (NetmikoAuthenticationException, NetmikoTimeoutException) as e:
        return build_rows(host, {}, "", "", raw_error=str(e))
    except Exception as e:
        return build_rows(host, {}, "", "", raw_error=str(e))


def main():
    print("=== NAT / PAT Configuration Audit ===\n")
    hosts = prompt_for_hosts()
    username, password, enable_secret = prompt_for_credentials()

    all_rows = []
    for host in hosts:
        print(f"\nConnecting to {host} ...")
        rows = collect_from_host(host, username, password, enable_secret)
        for r in rows:
            print(f"  [{r['category']}] {r['detail']}")
        all_rows.extend(rows)

    # nat-pat-<date>-<time>.csv, e.g. nat-pat-20260924-153012.csv
    now = datetime.now()
    date_part = now.strftime("%Y%m%d")
    time_part = now.strftime("%H%M%S")
    out_path = f"nat-pat-{date_part}-{time_part}.csv"

    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"\nCSV report saved to: {out_path}")


if __name__ == "__main__":
    main()

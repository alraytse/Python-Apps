#!/usr/bin/env python3

"""
Infoblox Lookup Tool

Features
--------
- Prompt for Grid Manager hostname/IP
- Prompt for WAPI version
- Prompt for EID/password
- List all IPv4 networks
- Search IP address
- Search subnet (exact or partial)
- Export networks to CSV
- Detailed API error reporting

Requirements
------------
pip install requests
"""

import csv
import getpass
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from logging.handlers import RotatingFileHandler
import requests
from requests.auth import HTTPBasicAuth
from urllib3.exceptions import InsecureRequestWarning

# Tunables for the grid-wide DNS export
MAX_WORKERS = 10   # concurrent record-type fetches
PAGE_LIMIT = 100    # records requested per WAPI page

requests.packages.urllib3.disable_warnings(
    InsecureRequestWarning
)


# Record types to pull for a grid-wide DNS export, and the WAPI
# _return_fields to request for each. "allrecords" is not used here
# because it requires a specific zone and doesn't return the actual
# record data (IPs, targets, etc.) - querying each record type
# directly gives full, typed data across every zone at once.
DNS_RECORD_TYPES = {
    "record:host": "name,view,zone,comment,ttl,ipv4addrs,ipv6addrs",
    "record:a": "name,ipv4addr,zone,view,ttl,comment",
    "record:aaaa": "name,ipv6addr,zone,view,ttl,comment",
    "record:cname": "name,canonical,zone,view,ttl,comment",
    "record:mx": "name,mail_exchanger,preference,zone,view,ttl,comment",
    "record:txt": "name,text,zone,view,ttl,comment",
    "record:srv": "name,target,priority,weight,port,zone,view,ttl,comment",
    "record:ptr": "name,ptrdname,zone,view,ttl,comment",
    "record:ns": "name,nameserver,zone,view",
    "record:naptr": (
        "name,replacement,preference,order,flags,"
        "services,zone,view,ttl,comment"
    ),
}

# Field on each record type that holds the "value" (IP, target, etc.)
DNS_VALUE_FIELD = {
    "record:a": "ipv4addr",
    "record:aaaa": "ipv6addr",
    "record:cname": "canonical",
    "record:mx": "mail_exchanger",
    "record:txt": "text",
    "record:ptr": "ptrdname",
    "record:ns": "nameserver",
    "record:naptr": "replacement",
}


# Logging setup
# ------------
# Full detail (every request, status code, error body, record
# counts) goes to a rotating log file. Only warnings/errors are
# also echoed to the console, so the existing interactive prompts
# and menus stay uncluttered. Credentials are never logged.
LOG_FILE = "ipam.log"

logger = logging.getLogger("ipam")
logger.setLevel(logging.DEBUG)

_log_formatter = logging.Formatter(
    "%(asctime)s [%(levelname)s] %(message)s"
)

_file_handler = RotatingFileHandler(
    LOG_FILE,
    maxBytes=5 * 1024 * 1024,
    backupCount=3,
    encoding="utf-8"
)
_file_handler.setLevel(logging.DEBUG)
_file_handler.setFormatter(_log_formatter)
logger.addHandler(_file_handler)

_console_handler = logging.StreamHandler()
_console_handler.setLevel(logging.WARNING)
_console_handler.setFormatter(_log_formatter)
logger.addHandler(_console_handler)


def api_get(url, eid, password):

    logger.debug(f"GET {url} (eid={eid})")

    response = requests.get(
        url,
        auth=HTTPBasicAuth(eid, password),
        verify=False,
        timeout=60
    )

    logger.debug(
        f"Response {response.status_code} for {url}"
    )

    if response.status_code not in [200, 201]:

        logger.error(
            f"API ERROR {response.status_code} "
            f"for {url}\nResponse: {response.text}"
        )

        print("\n" + "=" * 80)
        print("API ERROR")
        print("=" * 80)
        print(f"URL: {url}")
        print(f"Status Code: {response.status_code}")
        print(f"Response:\n{response.text}")
        print("=" * 80)

        response.raise_for_status()

    return response.json()


_print_lock = threading.Lock()


def paginated_get(base_url, eid, password, max_results=PAGE_LIMIT):

    """
    Follow WAPI paging (_paging=1 / _return_as_object=1) until every
    page has been retrieved, returning the combined list of results.
    """

    separator = "&" if "?" in base_url else "?"

    url = (
        f"{base_url}{separator}"
        f"_max_results={max_results}"
        f"&_paging=1&_return_as_object=1"
    )

    results = []
    page_num = 1

    while True:

        data = api_get(
            url,
            eid,
            password
        )

        page_results = data.get("result", [])

        logger.debug(
            f"Page {page_num}: "
            f"{len(page_results)} record(s)"
        )

        results.extend(page_results)

        next_page_id = data.get("next_page_id")

        if not next_page_id:
            break

        page_num += 1

        url = (
            f"{base_url}{separator}"
            f"_max_results={max_results}"
            f"&_paging=1&_return_as_object=1"
            f"&_page_id={next_page_id}"
        )

    return results


def _fetch_dns_record_type(
    gridmaster,
    eid,
    password,
    wapi_version,
    record_type,
    fields
):

    url = (
        f"https://{gridmaster}"
        f"/wapi/{wapi_version}/{record_type}"
        f"?_return_fields={fields}"
    )

    with _print_lock:
        print(f"Fetching {record_type} ...")

    logger.info(f"Fetching {record_type}")

    try:

        records = paginated_get(
            url,
            eid,
            password
        )

    except requests.exceptions.HTTPError as exc:

        with _print_lock:
            print(f"  Skipped {record_type}: {exc}")

        logger.warning(f"Skipped {record_type}: {exc}")

        return []

    for record in records:
        record["_record_type"] = record_type

    with _print_lock:
        print(f"  {record_type}: {len(records)} record(s)")

    logger.info(
        f"{record_type}: {len(records)} record(s)"
    )

    return records


def get_all_dns_records(gridmaster, eid, password, wapi_version):

    """
    Pull every DNS record type across the entire grid (all zones,
    all views), fetching up to MAX_WORKERS record types concurrently
    and paging each in batches of PAGE_LIMIT.
    """

    all_records = []

    logger.info(
        f"Starting grid-wide DNS export against "
        f"{gridmaster} (max_workers={MAX_WORKERS}, "
        f"page_limit={PAGE_LIMIT})"
    )

    print(
        f"\nFetching DNS records "
        f"({MAX_WORKERS} parallel workers, "
        f"{PAGE_LIMIT} per page)...\n"
    )

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:

        futures = {
            executor.submit(
                _fetch_dns_record_type,
                gridmaster,
                eid,
                password,
                wapi_version,
                record_type,
                fields
            ): record_type
            for record_type, fields in DNS_RECORD_TYPES.items()
        }

        for future in as_completed(futures):

            record_type = futures[future]

            try:

                records = future.result()
                all_records.extend(records)

            except Exception:

                logger.exception(
                    f"Error fetching {record_type}"
                )

                with _print_lock:
                    print(
                        f"  Error fetching {record_type}, "
                        f"see {LOG_FILE} for details"
                    )

    logger.info(
        f"DNS export complete: "
        f"{len(all_records)} total record(s)"
    )

    return all_records


def _dns_record_value(record_type, record):

    if record_type == "record:host":

        ipv4s = [
            addr.get("ipv4addr", "")
            for addr in record.get("ipv4addrs", [])
        ]

        ipv6s = [
            addr.get("ipv6addr", "")
            for addr in record.get("ipv6addrs", [])
        ]

        return ";".join(
            v for v in ipv4s + ipv6s if v
        )

    if record_type == "record:srv":

        return (
            f"{record.get('target', '')}:"
            f"{record.get('port', '')} "
            f"(priority={record.get('priority', '')}, "
            f"weight={record.get('weight', '')})"
        )

    field = DNS_VALUE_FIELD.get(record_type)

    return record.get(field, "") if field else ""


def export_dns_records_csv(records):

    filename = "infoblox_dns_records.csv"

    with open(
        filename,
        "w",
        newline="",
        encoding="utf-8"
    ) as csvfile:

        writer = csv.writer(csvfile)

        writer.writerow(
            [
                "Record Type",
                "Name",
                "Zone",
                "View",
                "Value",
                "TTL",
                "Comment"
            ]
        )

        for record in records:

            record_type = record.get(
                "_record_type",
                ""
            )

            writer.writerow(
                [
                    record_type,
                    record.get("name", ""),
                    record.get("zone", ""),
                    record.get("view", ""),
                    _dns_record_value(
                        record_type,
                        record
                    ),
                    record.get("ttl", ""),
                    record.get("comment", "")
                ]
            )

    print(f"\nCSV written: {filename}")
    print(f"Total DNS Records: {len(records)}")
    logger.info(
        f"Wrote {len(records)} DNS record(s) to {filename}"
    )


def get_networks(gridmaster, eid, password, wapi_version):

    url = (
        f"https://{gridmaster}"
        f"/wapi/{wapi_version}/network"
        f"?_max_results=10000"
    )

    return api_get(
        url,
        eid,
        password
    )


def search_ip(
    gridmaster,
    eid,
    password,
    wapi_version,
    ip
):

    url = (
        f"https://{gridmaster}"
        f"/wapi/{wapi_version}/ipv4address"
        f"?ip_address={ip}"
        f"&_return_fields="
        f"ip_address,names,network,"
        f"mac_address,status"
    )

    return api_get(
        url,
        eid,
        password
    )


def search_subnet(
    gridmaster,
    eid,
    password,
    wapi_version,
    subnet
):

    subnet = subnet.strip()

    networks = get_networks(
        gridmaster,
        eid,
        password,
        wapi_version
    )

    matches = []

    for network in networks:

        network_cidr = network.get(
            "network",
            ""
        )

        if subnet.lower() in network_cidr.lower():
            matches.append(network)

    return matches


def display_networks(networks):

    if not networks:
        print("\nNo matching networks found.")
        return

    print("\n" + "=" * 140)

    print(
        f"{'Subnet':<25}"
        f"{'Network View':<25}"
        f"{'Comment':<80}"
    )

    print("=" * 140)

    for network in networks:

        subnet = network.get(
            "network",
            ""
        )

        network_view = network.get(
            "network_view",
            ""
        )

        comment = network.get(
            "comment",
            ""
        )

        print(
            f"{subnet:<25}"
            f"{network_view:<25}"
            f"{comment[:80]:<80}"
        )

    print("=" * 140)
    print(f"Total Networks: {len(networks)}")


def display_ip_results(results):

    if not results:
        print("\nNo matching IP found.")
        return

    print("\n" + "=" * 140)

    print(
        f"{'IP Address':<18}"
        f"{'Hostname':<40}"
        f"{'Network':<25}"
        f"{'MAC Address':<20}"
        f"{'Status':<15}"
    )

    print("=" * 140)

    for item in results:

        hostname = ",".join(
            item.get("names", [])
        )

        print(
            f"{item.get('ip_address',''):<18}"
            f"{hostname[:40]:<40}"
            f"{item.get('network',''):<25}"
            f"{item.get('mac_address',''):<20}"
            f"{item.get('status',''):<15}"
        )

    print("=" * 140)


def export_networks_csv(networks):

    filename = "infoblox_networks.csv"

    with open(
        filename,
        "w",
        newline="",
        encoding="utf-8"
    ) as csvfile:

        writer = csv.writer(csvfile)

        writer.writerow(
            [
                "Subnet",
                "Network View",
                "Comment"
            ]
        )

        for network in networks:

            writer.writerow(
                [
                    network.get(
                        "network",
                        ""
                    ),
                    network.get(
                        "network_view",
                        ""
                    ),
                    network.get(
                        "comment",
                        ""
                    )
                ]
            )

    print(f"\nCSV written: {filename}")
    logger.info(
        f"Wrote {len(networks)} network(s) to {filename}"
    )


def main():

    print("\nInfoblox Lookup Tool")
    print("=" * 60)

    gridmaster = input(
        "\nGrid Manager Hostname/IP: "
    ).strip()

    wapi_version = input(
        "WAPI Version [v2.13]: "
    ).strip()

    if not wapi_version:
        wapi_version = "v2.13"

    eid = input(
        "EID: "
    ).strip()

    password = getpass.getpass(
        "Password: "
    )

    logger.info(
        f"Session started: gridmaster={gridmaster}, "
        f"wapi_version={wapi_version}, eid={eid}"
    )
    print(f"\nLogging to: {LOG_FILE}")

    while True:

        print("\nOptions")
        print("-" * 60)
        print("1 - List All Networks")
        print("2 - Search IP Address")
        print("3 - Search Subnet")
        print("4 - Export All Networks to CSV")
        print("5 - Export All DNS Records (All Zones) to CSV")
        print("6 - Exit")

        choice = input(
            "\nSelect option: "
        ).strip()

        logger.info(f"Menu selection: {choice}")

        try:

            if choice == "1":

                networks = get_networks(
                    gridmaster,
                    eid,
                    password,
                    wapi_version
                )

                display_networks(
                    networks
                )

            elif choice == "2":

                ip = input(
                    "\nIP Address: "
                ).strip()

                results = search_ip(
                    gridmaster,
                    eid,
                    password,
                    wapi_version,
                    ip
                )

                display_ip_results(
                    results
                )

            elif choice == "3":

                subnet = input(
                    "\nSubnet Search: "
                ).strip()

                results = search_subnet(
                    gridmaster,
                    eid,
                    password,
                    wapi_version,
                    subnet
                )

                display_networks(
                    results
                )

            elif choice == "4":

                networks = get_networks(
                    gridmaster,
                    eid,
                    password,
                    wapi_version
                )

                export_networks_csv(
                    networks
                )

            elif choice == "5":

                records = get_all_dns_records(
                    gridmaster,
                    eid,
                    password,
                    wapi_version
                )

                export_dns_records_csv(
                    records
                )

            elif choice == "6":

                print("\nExiting.")
                logger.info("Session ended by user.")
                break

            else:

                print(
                    "\nInvalid selection."
                )

        except requests.exceptions.HTTPError as exc:

            logger.error(f"HTTP Error: {exc}")

            print(
                f"\nHTTP Error: {exc}"
            )

        except requests.exceptions.ConnectionError as exc:

            logger.error(f"Connection Error: {exc}")

            print(
                "\nConnection Error: "
                "Unable to reach Grid Manager."
            )

        except requests.exceptions.Timeout as exc:

            logger.error(f"Timeout: {exc}")

            print(
                "\nConnection timed out."
            )

        except Exception as exc:

            logger.exception("Unexpected Error")

            print(
                f"\nUnexpected Error: {exc}"
            )


if __name__ == "__main__":
    main()


#!/usr/bin/env python3
"""
Aruba switches: collect interface error statistics from multiple hosts over SSH.

Update: Now clears interface statistics before collecting.
- Executes `clear interface statistics` (AOS-CX syntax) prior to
  `show interface error-statistics` on each host.

Notes
- On some Aruba platforms, variants exist (e.g., `clear interface 1/1/1 statistics`
  or `clear statistics global`). Adjust if needed per OS/firmware.

References
- AOS-CX show/clear interface stats: see Aruba docs and community guidance on
  clearing counters (per-interface vs global)  [sources below].

Requirements
- Python 3.8+
- paramiko: `pip install paramiko`
"""

import getpass
import datetime
import socket
from typing import Tuple

def ssh_show(host: str, username: str, password: str, cmd: str,
             port: int = 22, timeout: int = 15) -> Tuple[str, str, str]:
    """Return (stdout, stderr, error_msg). error_msg is None on success."""
    try:
        import paramiko
    except Exception as e:
        return "", "", f"Paramiko not available: {e}. Install with 'pip install paramiko'."

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=host,
            username=username,
            password=password,
            port=port,
            timeout=timeout,
            look_for_keys=False,
            allow_agent=False,
        )
        stdin, stdout, stderr = client.exec_command(cmd)
        out = stdout.read().decode(errors="ignore")
        err = stderr.read().decode(errors="ignore")
        client.close()
        return out, err, None
    except (paramiko.SSHException, paramiko.AuthenticationException) as e:
        return "", "", f"SSH error: {e}"
    except socket.timeout:
        return "", "", "Connection timed out"
    except Exception as e:
        return "", "", f"Unexpected error: {e}"

def main():
    print("Aruba Switch Error-Stats Collector (with clear)")
    hosts_raw = input("Enter hostnames/IPs (comma-separated): ").strip()
    hosts = [h.strip() for h in hosts_raw.split(',') if h.strip()]
    if not hosts:
        print("No hosts provided. Exiting.")
        return

    username = input("Enter SSH username (press Enter to set per-host later): ").strip()
    password = None
    if username:
        password = getpass.getpass("Enter SSH password: ")

    # Commands
    clear_cmd = "clear interface statistics"  # AOS-CX global clear of interface counters
    show_cmd = "show interface error-statistics"

    for host in hosts:
        print(f"\n--- {host} ---")
        host_user = username
        host_pass = password
        if not host_user:
            host_user = input(f"[{host}] SSH username: ").strip()
            host_pass = getpass.getpass(f"[{host}] SSH password: ")

        # 1) Clear counters
        _, err_clear, err_msg_clear = ssh_show(host, host_user, host_pass, clear_cmd)
        # 2) Show counters
        out, err_show, err_msg_show = ssh_show(host, host_user, host_pass, show_cmd)

        ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        safe_host = host.replace(':','_').replace('/', '_')
        fname = f"{safe_host}_{ts}.txt"
        with open(fname, 'w', encoding='utf-8') as fh:
            fh.write(f"Host: {host}\n")
            fh.write(f"Timestamp: {datetime.datetime.now().isoformat(timespec='seconds')}\n")
            fh.write(f"Clear Command: {clear_cmd}\n")
            if err_msg_clear:
                fh.write(f"Clear ERROR: {err_msg_clear}\n")
            elif err_clear and err_clear.strip():
                fh.write("Clear STDERR:\n" + err_clear + "\n")
            fh.write("\n")

            fh.write(f"Show Command: {show_cmd}\n\n")
            if err_msg_show:
                fh.write(f"Show ERROR: {err_msg_show}\n")
            else:
                if err_show and err_show.strip():
                    fh.write("STDERR:\n" + err_show + "\n\n")
                fh.write("OUTPUT:\n")
                fh.write(out if out else "<no output>\n")
        print(f"Saved: {fname}")

    print("\nAll done.")

if __name__ == '__main__':
    main()

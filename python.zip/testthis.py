#!/usr/bin/env python3

import paramiko
import getpass
import ipaddress
import time
import select
import sys
from datetime import datetime

#############################################################################
# USER INPUT WITH TIMEOUT
#############################################################################

def input_with_timeout(prompt, timeout=15, default="n"):

    print(
        f"{prompt} (default={default} in {timeout}s): ",
        end="",
        flush=True
    )

    ready, _, _ = select.select(
        [sys.stdin],
        [],
        [],
        timeout
    )

    if ready:
        value = sys.stdin.readline().strip()
        return value if value else default

    print(f"\nNo input received. Using default '{default}'")
    return default


#############################################################################
# SSH
#############################################################################

def connect_router(router, username, password):

    try:

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(
            paramiko.AutoAddPolicy()
        )

        ssh.connect(
            hostname=router,
            username=username,
            password=password,
            look_for_keys=False,
            timeout=20,
            banner_timeout=30,
            auth_timeout=30
        )

        return ssh

    except Exception as e:

        print(f"Failed connecting to {router}: {e}")
        return None


def run_command(shell, command, wait=3):

    if shell.closed:
        raise RuntimeError("SSH Channel Closed")

    while shell.recv_ready():
        shell.recv(65535)

    shell.send(command + "\n")

    time.sleep(wait)

    output = ""

    end_time = time.time() + 10

    while time.time() < end_time:

        while shell.recv_ready():

            output += shell.recv(
                65535
            ).decode(
                errors="ignore"
            )

        time.sleep(0.25)

    return output


#############################################################################
# COMMAND BUILDER
#############################################################################

def build_commands(subnet, vrf_name=None):

    network = ipaddress.ip_network(
        subnet,
        strict=False
    )

    first_ip = str(
        network.network_address + 1
    )

    octets = str(
        network.network_address
    ).split(".")

    summary_network = (
        f"{octets[0]}.{octets[1]}.0.0"
    )

    commands = [

        (
            "LONGER_PREFIX",
            f"show ip route vrf * "
            f"{summary_network} "
            f"255.255.0.0 longer-prefixes"
        ),

        (
            "ROUTE_ALL_VRF_IP",
            f"show ip route vrf * {first_ip}"
        ),

        (
            "ROUTE_ALL_VRF_SUBNET",
            f"show ip route vrf * "
            f"{network.network_address}"
        )
    ]

    if vrf_name:

        commands.extend([

            (
                "ROUTE_VRF",
                f"show ip route vrf "
                f"{vrf_name} {first_ip}"
            ),

            (
                "CEF_VRF",
                f"show ip cef vrf "
                f"{vrf_name} {first_ip}"
            )

        ])

    else:

        commands.extend([

            (
                "ROUTE",
                f"show ip route {first_ip}"
            ),

            (
                "CEF",
                f"show ip cef {first_ip}"
            )

        ])

    commands.append(

        (
            "EASTWEST",
            f"show ip route {first_ip}"
        )

    )

    return commands


#############################################################################
# VALIDATION
#############################################################################

def analyze_vrf_route(output):

    lower = output.lower()

    if "% subnet not in table" in lower:
        return True, "Subnet not found"

    if "routing table:" in lower:
        return False, "Subnet found in a VRF"

    if "routing entry for" in lower:
        return False, "Route already exists"

    return True, "No route found"


def determine_region(output):

    if (
        "10.254.128.1" in output or
        "10.254.128.2" in output
    ):
        return (
            "EAST",
            "RSW Next-Hop Detected"
        )

    if "10.255.132." in output:
        return (
            "WEST",
            "ISP Next-Hop Detected"
        )

    return (
        "UNKNOWN",
        "Unable to Determine"
    )


#############################################################################
# PING
#############################################################################

def ping_ip(shell, ip, vrf_name=None):

    if vrf_name:

        cmd = (
            f"ping vrf {vrf_name} "
            f"{ip} repeat 1 timeout 1"
        )

    else:

        cmd = (
            f"ping {ip} repeat 1 timeout 1"
        )

    output = run_command(
        shell,
        cmd,
        wait=2
    )

    return (
        "Success rate is 100 percent"
        in output
    )


def ping_sweep(shell, subnet, vrf_name=None):

    network = ipaddress.ip_network(
        subnet,
        strict=False
    )

    active_hosts = []

    hosts = list(
        network.hosts()
    )

    if len(hosts) > 50:

        print(
            f"Subnet contains {len(hosts)} hosts. "
            f"Checking first 50 only."
        )

        hosts = hosts[:50]

    for host in hosts:

        ip = str(host)

        print(f"Pinging {ip}")

        if ping_ip(
            shell,
            ip,
            vrf_name
        ):
            active_hosts.append(ip)

    return active_hosts


#############################################################################
# MAIN
#############################################################################

def main():

    print("\nSubnet Validation Tool\n")

    routers_input = input(
        "Routers (comma separated): "
    ).strip()

    subnet = input(
        "Subnet (CIDR): "
    ).strip()

    vrf_name = input(
        "VRF (blank for global): "
    ).strip()

    if vrf_name == "":
        vrf_name = None

    username = input(
        "Username: "
    ).strip()

    password = getpass.getpass(
        "Password: "
    )

    run_ping = input_with_timeout(
        "\nRun Ping Sweep? (y/n)",
        timeout=15,
        default="n"
    ).lower()

    routers = [

        r.strip()

        for r in routers_input.split(",")

        if r.strip()
    ]

    commands = build_commands(
        subnet,
        vrf_name
    )

    report = []

    overall_pass = True
    available = True
    region = "UNKNOWN"
    active_hosts = []

    report.append(
        f"Subnet Validation Report"
    )

    report.append(
        f"Generated: {datetime.now()}"
    )

    report.append(
        "=" * 80
    )

    for router in routers:

        print(
            f"\nConnecting to {router}"
        )

        ssh = connect_router(
            router,
            username,
            password
        )

        if not ssh:

            overall_pass = False
            continue

        try:

            shell = ssh.invoke_shell()

            time.sleep(2)

            run_command(
                shell,
                "terminal length 0"
            )

            results = {}

            for cmd_type, cmd in commands:

                print(
                    f"Running: {cmd}"
                )

                output = run_command(
                    shell,
                    cmd
                )

                results[
                    cmd_type
                ] = output

                report.append(
                    f"\nROUTER: {router}"
                )

                report.append(
                    f"\nCOMMAND: {cmd}"
                )

                report.append(
                    output
                )

            available, reason = (
                analyze_vrf_route(
                    results.get(
                        "ROUTE_ALL_VRF_IP",
                        ""
                    )
                )
            )

            region, region_reason = (
                determine_region(
                    results.get(
                        "EASTWEST",
                        ""
                    )
                )
            )

            report.append(
                f"\nAvailability: "
                f"{'PASS' if available else 'FAIL'}"
            )

            report.append(
                f"Reason: {reason}"
            )

            report.append(
                f"Region: {region}"
            )

            report.append(
                f"Detail: {region_reason}"
            )

            if not available:
                overall_pass = False

        finally:

            ssh.close()

    ###################################################################
    # OPTIONAL PING SWEEP
    ###################################################################

    if run_ping == "y":

        print("\nStarting Ping Sweep...")

        ping_router = routers[0]

        ssh_ping = connect_router(
            ping_router,
            username,
            password
        )

        if ssh_ping:

            try:

                shell = ssh_ping.invoke_shell()

                time.sleep(2)

                run_command(
                    shell,
                    "terminal length 0"
                )

                active_hosts = ping_sweep(
                    shell,
                    subnet,
                    vrf_name
                )

                if active_hosts:
                    overall_pass = False

            finally:

                ssh_ping.close()

    else:

        report.append(
            "\nPing Sweep Skipped"
        )

    ###################################################################
    # SUMMARY
    ###################################################################

    report.append("\nFINAL SUMMARY")
    report.append("=" * 80)

    report.append(
        f"Subnet: {subnet}"
    )

    report.append(
        f"VRF: {vrf_name or 'GLOBAL'}"
    )

    report.append(
        f"Routers Checked: {len(routers)}"
    )

    report.append(
        f"Ping Sweep: "
        f"{'RUN' if run_ping == 'y' else 'SKIPPED'}"
    )

    report.append(
        f"Active Hosts: {len(active_hosts)}"
    )

    report.append(
        f"Availability: "
        f"{'AVAILABLE' if available else 'IN USE'}"
    )

    report.append(
        f"Region: {region}"
    )

    report.append(
        f"RESULT: "
        f"{'PASS' if overall_pass else 'FAIL'}"
    )

    report_file = (
        "Subnet_Report_"
        + datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )
        + ".txt"
    )

    with open(report_file, "w") as f:

        f.write(
            "\n".join(report)
        )

    print(
        f"\nReport saved: {report_file}"
    )

    print(
        f"Final Result: "
        f"{'PASS' if overall_pass else 'FAIL'}"
    )


if __name__ == "__main__":
    main()
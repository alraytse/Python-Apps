import subprocess
import platform
import logging

# ========= LOGGING =========
LOG_FILE = "ping_debug.log"

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,  # enable DEBUG
    format="%(asctime)s - %(levelname)s - %(message)s"
)

console = logging.StreamHandler()
console.setLevel(logging.INFO)
console.setFormatter(logging.Formatter("%(message)s"))
logging.getLogger().addHandler(console)

logging.debug("Ping script started")


def ping_host(host):
    system = platform.system().lower()
    logging.debug(f"Detected OS: {system}")
    logging.debug(f"Pinging host: {host}")

    if system == "windows":
        cmd = ["ping", "-n", "2", host]
    else:
        cmd = ["ping", "-c", "2", host]

    logging.debug(f"Executing command: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        logging.debug(f"Return code: {result.returncode}")
        logging.debug(f"STDOUT:\n{result.stdout}")
        logging.debug(f"STDERR:\n{result.stderr}")

        return result.returncode == 0

    except Exception as e:
        logging.error(f"Exception while pinging {host}: {e}")
        return False


def main():
    raw = input("Enter IP addresses or hostnames (comma-separated): ").strip()
    targets = [t.strip() for t in raw.split(",") if t.strip()]

    logging.info(f"Targets received: {targets}")

    if not targets:
        logging.error("No valid targets provided")
        print("No valid targets provided.")
        return

    print("\nPing results:\n")

    for host in targets:
        if ping_host(host):
            logging.info(f"{host} is reachable")
            print(f"✅ {host} is reachable")
        else:
            logging.warning(f"{host} is NOT reachable")
            print(f"❌ {host} is NOT reachable")

    logging.info("Ping script completed")


if __name__ == "__main__":
    main()

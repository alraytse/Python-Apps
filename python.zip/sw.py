import subprocess
import platform

def sweep_ping(subnet):
    # subnet example: "192.168.1"
    print(f"Starting sweep on {subnet}.0/24\n")

    # detect OS ping command
    param = "-n" if platform.system().lower() == "windows" else "-c"

    for i in range(1, 255):
        ip = f"{subnet}.{i}"
        result = subprocess.run(
            ["ping", param, "1", ip],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        if result.returncode == 0:
            print(f"[+] Host alive: {ip}")

if __name__ == "__main__":
    sweep_ping("10.80.208.3")   # change to your subnet

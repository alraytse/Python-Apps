import requests
import urllib3
import pandas as pd

urllib3.disable_warnings()

ib_host = input("Infoblox Host: ")
username = input("Username: ")
password = input("Password: ")

subnets = [
    "10.128.236.0/24",
    "10.184.234.0/23",
    "10.50.8.0/22",
    "10.128.138.0/24",
    "10.184.192.0/24",
    "10.128.74.0/24",
    "10.190.28.0/23",
    "10.153.20.0/24",
    "10.142.4.0/22",
    "10.90.2.0/24",
    "10.128.232.0/24",
    "10.46.8.0/24",
    "10.189.70.0/24",
    "10.188.96.0/22",
    "10.18.20.0/24",
    "10.148.4.0/24",
    "10.128.64.0/24",
    "10.26.1.0/24",
    "10.188.186.0/23",
    "10.188.194.0/24",
    "10.153.19.0/24",
    "10.128.241.0/24"
]

results = []

for network in subnets:
    url = f"https://{ib_host}/wapi/v2.13/network"
    params = {
        "network": network,
        "_return_fields+": "options,ranges"
    }

    r = requests.get(
        url,
        auth=(username, password),
        params=params,
        verify=False
    )

    if r.status_code != 200:
        continue

    for net in r.json():
        gateway = ""

        for option in net.get("options", []):
            if option.get("name") == "routers":
                gateway = option.get("value")

        start_ip = ""
        end_ip = ""

        ranges = net.get("ranges", [])
        if ranges:
            start_ip = ranges[0].get("start_addr", "")
            end_ip = ranges[0].get("end_addr", "")

        results.append({
            "Network": network,
            "Gateway": gateway,
            "DHCP Start": start_ip,
            "DHCP End": end_ip
        })

pd.DataFrame(results).to_csv(
    "uson_dhcp_scopes.csv",
    index=False
)

print("Output written to uson_dhcp_scopes.csv")

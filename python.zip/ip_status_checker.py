#!/usr/bin/env python3
"""
IP Status Checker
-----------------
Prompts for a user ID and password, reads a CSV file of network IPs,
checks whether each IP is active (reachable) or shutdown (unreachable),
and displays a report. Optionally verifies SSH login with the credentials.

CSV format (header row recommended):
    ip,hostname
    192.168.1.1,core-router
    192.168.1.10,web-server

If there is no "ip" column, the first column is treated as the IP.

Usage:
    python ip_status_checker.py devices.csv
    python ip_status_checker.py devices.csv --ssh      # also test SSH login
"""

import argparse
import csv
import getpass
import ipaddress
import platform
import re
import socket
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

try:
    import paramiko  # optional, only needed for --ssh
except ImportError:
    paramiko = None


# --------------------------------------------------------------------------
# Credential prompt
# --------------------------------------------------------------------------
def get_credentials():
    user_id = input("Enter User ID: ").strip()
    password = getpass.getpass("Enter Password: ")  # input is hidden
    if not user_id or not password:
        print("User ID and password are required.")
        sys.exit(1)
    return user_id, password


# --------------------------------------------------------------------------
# CSV reading
# --------------------------------------------------------------------------
IPV4_RE = re.compile(r"(?<![\d.])((?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3})(?![\d.])")


def _octet(cell):
    cell = cell.strip()
    return cell.isdigit() and 0 <= int(cell) <= 255


def _find_ip(row, raw_line):
    """Return (ip, index_of_ip_cell) found anywhere in the row."""
    # 1) A cell containing an IPv4 address (also handles '10.0.0.1/24', 'host 10.0.0.1')
    for i, cell in enumerate(row):
        m = IPV4_RE.search(cell)
        if m:
            return m.group(1), i
    # 2) IP split across 4 cells, e.g. a line like 192,168,1,1,router
    for i in range(len(row) - 3):
        if all(_octet(c) for c in row[i:i + 4]):
            return ".".join(c.strip() for c in row[i:i + 4]), i
    # 3) Last resort: search the raw text line
    m = IPV4_RE.search(raw_line)
    if m:
        return m.group(1), None
    return None, None


def read_ips(csv_path):
    text = None
    # Excel often saves CSVs as Windows-1252, not UTF-8, so try several encodings
    for enc in ("utf-8-sig", "utf-16", "cp1252", "latin-1"):
        try:
            with open(csv_path, encoding=enc, newline="") as f:
                text = f.read()
            if "\x00" in text:          # wrong guess for a UTF-16 file
                continue
            break
        except FileNotFoundError:
            print(f"Error: file not found: {csv_path}")
            sys.exit(1)
        except UnicodeError:
            continue

    if not text or not text.strip():
        print("Error: CSV file is empty.")
        sys.exit(1)

    # Detect the delimiter (comma, semicolon, tab or pipe) - never '.'
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","

    lines = text.splitlines()
    rows = list(csv.reader(lines, delimiter=delimiter))

    # Find a name/hostname column if there is a header row
    header = [h.strip().lower() for h in rows[0]] if rows else []
    name_idx = next((i for i, h in enumerate(header)
                     if h in ("hostname", "host", "name", "device", "device name")), None)

    devices, seen, skipped = [], set(), []
    for line, row in zip(lines, rows):
        if not row or not any(c.strip() for c in row):
            continue
        ip, ip_idx = _find_ip(row, line)
        if not ip:
            skipped.append(line.strip())
            continue
        if ip in seen:
            continue
        seen.add(ip)
        if name_idx is not None and name_idx < len(row) and name_idx != ip_idx:
            name = row[name_idx].strip()
        else:  # use the first non-IP, non-empty cell as a label
            name = next((c.strip() for i, c in enumerate(row)
                         if i != ip_idx and c.strip() and not IPV4_RE.search(c)
                         and not _octet(c)), "")
        devices.append({"ip": ip, "name": name[:20]})

    # Ignore a header line silently; report anything else that had no IP
    if skipped and header and not IPV4_RE.search(lines[0]):
        skipped = [s for s in skipped if s != lines[0].strip()]
    if skipped:
        print(f"Skipped {len(skipped)} line(s) with no IP address, e.g.:")
        for s in skipped[:3]:
            print(f"   {s[:80]}")
    print(f"Found {len(devices)} unique IP(s) using delimiter {delimiter!r}")
    return devices


# --------------------------------------------------------------------------
# Status checks
# --------------------------------------------------------------------------
def ping(ip, timeout=2):
    """Return True if the host replies to ping."""
    if platform.system().lower() == "windows":
        cmd = ["ping", "-n", "1", "-w", str(timeout * 1000), ip]
    else:
        cmd = ["ping", "-c", "1", "-W", str(timeout), ip]
    try:
        result = subprocess.run(cmd, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, timeout=timeout + 2)
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def port_open(ip, ports=(22, 80, 443), timeout=2):
    """Fallback check: True if any common TCP port accepts a connection."""
    for port in ports:
        try:
            with socket.create_connection((ip, port), timeout=timeout):
                return True
        except OSError:
            continue
    return False


def ssh_login(ip, user_id, password, timeout=5):
    """Try an SSH login with the supplied credentials."""
    if paramiko is None:
        return "paramiko not installed"
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(ip, username=user_id, password=password, timeout=timeout,
                       allow_agent=False, look_for_keys=False)
        return "Login OK"
    except paramiko.AuthenticationException:
        return "Auth failed"
    except Exception:
        return "SSH unavailable"
    finally:
        client.close()


def check_device(device, user_id, password, use_ssh):
    ip = device["ip"]
    active = ping(ip) or port_open(ip)
    device["status"] = "ACTIVE" if active else "SHUTDOWN"
    device["ssh"] = ssh_login(ip, user_id, password) if (use_ssh and active) else "-"
    return device


# --------------------------------------------------------------------------
# Report
# --------------------------------------------------------------------------
def print_report(results, use_ssh):
    active = [r for r in results if r["status"] == "ACTIVE"]
    inactive = [r for r in results if r["status"] == "SHUTDOWN"]

    line = "=" * (70 if use_ssh else 50)
    print(f"\n{line}")
    print(f" NETWORK IP STATUS REPORT  -  {datetime.now():%Y-%m-%d %H:%M:%S}")
    print(line)

    def section(title, items):
        print(f"\n{title} ({len(items)})")
        print("-" * len(line))
        if not items:
            print("  None")
            return
        for r in items:
            row = f"  {r['ip']:<18}{r['name']:<22}{r['status']:<10}"
            if use_ssh:
                row += r["ssh"]
            print(row)

    section("ACTIVE IPs", active)
    section("INACTIVE / SHUTDOWN IPs", inactive)

    print(f"\n{line}")
    print(f" Total: {len(results)}   Active: {len(active)}   Inactive: {len(inactive)}")
    print(line)


def save_report(results, path):
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["ip", "name", "status", "ssh"])
        writer.writeheader()
        writer.writerows(results)
    print(f"\nReport saved to: {path}")


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Check if network IPs are active or shutdown.")
    parser.add_argument("csv_file", nargs="?", help="CSV file containing IPs")
    parser.add_argument("--ssh", action="store_true", help="Also verify SSH login with credentials")
    parser.add_argument("--workers", type=int, default=10, help="Parallel checks (default 10)")
    args = parser.parse_args()

    user_id, password = get_credentials()
    print(f"\nWelcome, {user_id}.")

    csv_file = args.csv_file or input("Enter CSV file path: ").strip()
    devices = read_ips(csv_file)
    if not devices:
        print("No valid IPs found in the CSV file.")
        sys.exit(1)

    print(f"Checking {len(devices)} IP(s), please wait...")
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(lambda d: check_device(d, user_id, password, args.ssh), devices))

    print_report(results, args.ssh)
    save_report(results, f"ip_status_report_{datetime.now():%Y%m%d_%H%M%S}.csv")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nCancelled by user.")

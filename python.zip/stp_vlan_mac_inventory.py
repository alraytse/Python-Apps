#!/usr/bin/env python3
import csv
import getpass
import re
from netmiko import ConnectHandler

CSV_FILE = "stp_vlan_report.csv"
MAC_CSV_FILE = "vlan_mac_details.csv"


def parse_vlans(output):
    vlans = []
    for line in output.splitlines():
        match = re.match(r"^(\d+)\s+([^\s]+)", line.strip())
        if match:
            vlans.append({"vlan": match.group(1), "name": match.group(2)})
    return vlans


def check_root(connection, vlan):
    try:
        output = connection.send_command(f"show spanning-tree vlan {vlan}", read_timeout=30)
        return "This bridge is the root" in output
    except Exception:
        return False


def get_svi_info(connection, vlan):
    try:
        output = connection.send_command(f"show run interface vlan {vlan}", read_timeout=30)
        description = ""
        ip_address = ""
        for line in output.splitlines():
            line = line.strip()
            if line.startswith("description "):
                description = line.replace("description ", "")
            elif line.startswith("ip address "):
                ip_address = line.replace("ip address ", "")
        return description, ip_address
    except Exception:
        return "", ""


def get_dynamic_macs(connection, vlan):
    try:
        output = connection.send_command(f"show mac address-table vlan {vlan}", read_timeout=60)
        macs = []
        for line in output.splitlines():
            if "dynamic" not in line.lower():
                continue
            match = re.search(r"([0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4})", line)
            if match:
                macs.append(match.group(1))
        macs = sorted(list(set(macs)))
        return len(macs), macs
    except Exception:
        return 0, []


def get_arp_count(connection, vlan):
    for cmd in [f"show ip arp vlan {vlan}", f"show arp vlan {vlan}"]:
        try:
            output = connection.send_command(cmd, read_timeout=60)
            count = 0
            for line in output.splitlines():
                if re.match(r"^\d+\.\d+\.\d+\.\d+", line.strip()):
                    count += 1
            return count
        except Exception:
            pass
    return 0


def get_hostname(connection):
    return connection.find_prompt().replace('#','').replace('>','')


def process_switch(device):
    results = []
    conn = ConnectHandler(**device)
    hostname = get_hostname(conn)
    vlans = parse_vlans(conn.send_command('show vlan brief', read_timeout=60))

    for vlan_info in vlans:
        vlan_id = vlan_info['vlan']
        mac_count, macs = get_dynamic_macs(conn, vlan_id)
        svi_desc, svi_ip = get_svi_info(conn, vlan_id)
        results.append({
            'Device': hostname,
            'VLAN': vlan_id,
            'VLAN_Name': vlan_info['name'],
            'SVI_IP': svi_ip,
            'SVI_Description': svi_desc,
            'Dynamic_MACs': mac_count,
            'MAC_Addresses': macs,
            'ARP_Count': get_arp_count(conn, vlan_id),
            'Root_Bridge': 'YES' if check_root(conn, vlan_id) else 'NO'
        })
    conn.disconnect()
    return results


def write_csv(results):
    fields = ['Device','VLAN','VLAN_Name','SVI_IP','SVI_Description','Dynamic_MACs','ARP_Count','Root_Bridge']
    with open(CSV_FILE,'w',newline='',encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in results:
            out = {k: row[k] for k in fields}
            w.writerow(out)


def write_mac_csv(results):
    with open(MAC_CSV_FILE,'w',newline='',encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['Device','VLAN','VLAN_Name','MAC_Address'])
        for row in results:
            for mac in row['MAC_Addresses']:
                w.writerow([row['Device'],row['VLAN'],row['VLAN_Name'],mac])


if __name__ == '__main__':
    hosts = [h.strip() for h in input('Hosts: ').split(',') if h.strip()]
    platform = input('Platform (nxos/iosxe): ').strip().lower()
    device_type = 'cisco_ios' if platform == 'iosxe' else 'cisco_nxos'
    username = input('Username: ')
    password = getpass.getpass('Password: ')

    results = []
    for host in hosts:
        results.extend(process_switch({
            'device_type': device_type,
            'host': host,
            'username': username,
            'password': password,
            'fast_cli': False
        }))

    write_csv(results)
    write_mac_csv(results)
    print(f'Saved {CSV_FILE} and {MAC_CSV_FILE}')

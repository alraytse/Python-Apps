#!/usr/bin/env python3
"""
nat_acl_extractor.py

Prompts for a comma-delimited list of host names, a username, and a
password. Connects to each host, runs 'show running-config', and
auto-discovers every object-group network block in the config, e.g.:

    object-group network Aruba_SDWAN_MPLS_IP
     host 10.1.1.5
     10.2.0.0 255.255.0.0
     group-object SomeNestedGroup

No group name needs to be known in advance -- every 'object-group
network <name>' block found in the running-config is extracted. All
host/network IP entries belonging to a given group are joined into a
single semicolon-separated cell in that group's row.

Member-line syntax varies slightly by platform:
  - IOS-XE:      host 10.1.1.5           /  10.2.0.0 255.255.0.0
  - ASA/PIX:     network-object host X   /  network-object X mask
The parser accepts both (the 'network-object' keyword is optional),
so no platform mode flag is needed for parsing. Netmiko's device_type
still needs to match your platform for connection handling -- see
DEVICE_TYPE below.

Requires: netmiko   ->   pip install netmiko
Falls back to a basic paramiko SSH session if netmiko isn't installed,
but netmiko is strongly recommended for clean command output.
"""

import re
import csv
import time
import getpass
import json
from datetime import datetime

MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 5

# Netmiko device_type for your platform. Common values:
#   "cisco_ios" / "cisco_xe"  -> IOS, IOS-XE routers and switches
#   "cisco_asa"               -> ASA / Firepower
DEVICE_TYPE = "cisco_xe"

RUNNING_CONFIG_CMD = "show running-config"

try:
    from netmiko import ConnectHandler
    HAVE_NETMIKO = True
except ImportError:
    HAVE_NETMIKO = False
    import paramiko


def get_running_config_netmiko(host, username, password):
    device = {
        "device_type": DEVICE_TYPE,
        "host": host,
        "username": username,
        "password": password,
    }
    conn = ConnectHandler(**device)
    output = conn.send_command(RUNNING_CONFIG_CMD, read_timeout=60)
    conn.disconnect()
    return output


def get_running_config_paramiko(host, username, password):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=username, password=password, timeout=20)
    shell = client.invoke_shell()
    time.sleep(1)
    if shell.recv_ready():
        shell.recv(65535)  # clear banner/prompt
    shell.send("terminal pager 0\n")
    time.sleep(1)
    if shell.recv_ready():
        shell.recv(65535)
    shell.send(RUNNING_CONFIG_CMD + "\n")
    time.sleep(3)
    output = ""
    while shell.recv_ready():
        output += shell.recv(65535).decode(errors="ignore")
        time.sleep(0.5)
    client.close()
    return output


def get_running_config(host, username, password):
    last_exception = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            if HAVE_NETMIKO:
                return get_running_config_netmiko(host, username, password)
            return get_running_config_paramiko(host, username, password)
        except Exception as exc:
            last_exception = exc
            print(f"    [!] Attempt {attempt}/{MAX_RETRIES} failed for {host}: {exc}")
            if attempt < MAX_RETRIES:
                print(f"    [i] Retrying in {RETRY_DELAY_SECONDS}s ...")
                time.sleep(RETRY_DELAY_SECONDS)
    raise last_exception


def find_all_object_groups(config_text):
    """
    Finds every 'object-group network <name>' block in the running
    config and returns a list of (group_name, block_text) tuples.
    block_text is everything indented under the header line, up to
    (not including) the next non-indented line.
    """
    pattern = re.compile(
        r"^object-group network (\S+)\s*\n((?:^[ \t]+.*\n?)*)",
        re.MULTILINE,
    )
    return pattern.findall(config_text)


def extract_group_members(block_text):
    """
    Returns a dict: {"ips": [...], "nested_groups": [...]}
    for a single object-group's block text.

    Accepts both IOS-XE syntax (host X / X mask) and ASA syntax
    (network-object host X / network-object X mask) since the
    'network-object' keyword is treated as optional.
    """
    ips = []
    nested_groups = []

    host_pattern = re.compile(
        r"^\s*(?:network-object\s+)?host\s+(\S+)", re.MULTILINE
    )
    for ip in host_pattern.findall(block_text):
        ips.append(ip)

    net_pattern = re.compile(
        r"^\s*(?:network-object\s+)?"
        r"(\d{1,3}(?:\.\d{1,3}){3})\s+(\d{1,3}(?:\.\d{1,3}){3})\s*$",
        re.MULTILINE,
    )
    for net_ip, mask in net_pattern.findall(block_text):
        ips.append(f"{net_ip} {mask}")

    nested_pattern = re.compile(r"^\s*group-object\s+(\S+)", re.MULTILINE)
    nested_groups.extend(nested_pattern.findall(block_text))

    return {"ips": ips, "nested_groups": nested_groups}


def extract_all_ips(config_text):
    """
    Extracts every IPv4-looking address found anywhere in the running
    config (interfaces, ACLs, object-groups, routes, etc.), deduped
    and sorted.
    """
    ip_pattern = re.compile(r"\b(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\b")
    found = set()
    for match in ip_pattern.finditer(config_text):
        octets = match.groups()
        if all(0 <= int(o) <= 255 for o in octets):
            found.add(".".join(octets))
    return sorted(found, key=lambda ip: tuple(int(o) for o in ip.split(".")))


def write_results_to_csv(results):
    """
    Writes one row per object-group to a CSV file named
    objectgroup-extract-<date>-<time>.csv
    Columns: Host, Object_Group, Host_IPs, Nested_Groups, All_IPs_In_Config

    Host_IPs is every host/network entry belonging to that group,
    semicolon-separated in a single cell. Nested_Groups lists any
    group-object references (not expanded). All_IPs_In_Config is every
    IPv4 address found anywhere in that host's running-config,
    semicolon-separated, repeated on each row for that host.
    """
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"objectgroup-extract-{timestamp}.csv"

    with open(filename, "w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(
            ["Host", "Object_Group", "Host_IPs", "Nested_Groups", "All_IPs_In_Config"]
        )

        for host, host_data in results.items():
            if "error" in host_data:
                writer.writerow([host, "", f"ERROR: {host_data['error']}", "", ""])
                continue

            all_ips_str = ";".join(host_data.get("all_ips", []))
            groups = host_data.get("groups", [])

            if not groups:
                writer.writerow(
                    [host, "", "No object-groups found", "", all_ips_str]
                )
                continue

            for group in groups:
                writer.writerow([
                    host,
                    group["name"],
                    ";".join(group["ips"]),
                    ";".join(group["nested_groups"]),
                    all_ips_str,
                ])

    return filename


def main():
    hosts_input = input("Enter host names (comma separated): ")
    hosts = [h.strip() for h in hosts_input.split(",") if h.strip()]

    username = input("Username: ")
    password = getpass.getpass("Password: ")

    if not HAVE_NETMIKO:
        print("[!] netmiko not installed, falling back to raw paramiko SSH.")
        print("    For reliable results, run: pip install netmiko\n")

    results = {}

    for host in hosts:
        print(f"\n[+] Connecting to {host} ...")
        try:
            config_text = get_running_config(host, username, password)
        except Exception as exc:
            print(f"[!] Failed to connect to {host}: {exc}")
            results[host] = {"error": str(exc)}
            continue

        all_ips = extract_all_ips(config_text)
        raw_groups = find_all_object_groups(config_text)

        if not raw_groups:
            print(f"    No object-groups found on {host}.")
            results[host] = {"groups": [], "all_ips": all_ips}
            continue

        groups = []
        for group_name, block_text in raw_groups:
            members = extract_group_members(block_text)
            groups.append({
                "name": group_name,
                "ips": members["ips"],
                "nested_groups": members["nested_groups"],
            })

        results[host] = {"groups": groups, "all_ips": all_ips}

        print(f"    Found {len(groups)} object-group(s) on {host}:")
        for group in groups:
            print(f"      {group['name']}: {len(group['ips'])} IP entr(y/ies)"
                  + (f", {len(group['nested_groups'])} nested group(s)"
                     if group["nested_groups"] else ""))
        print(f"    Total unique IPs found in config: {len(all_ips)}")

    print("\n=== Summary (JSON) ===")
    print(json.dumps(results, indent=2))

    csv_filename = write_results_to_csv(results)
    print(f"\n[+] Results written to {csv_filename}")


if __name__ == "__main__":
    main()

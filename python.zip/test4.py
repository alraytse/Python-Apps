import csv
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

# Set via environment variables or replace locally before execution
USERNAME = os.getenv("NETBRAIN_USER", "skk30ws")
PASSWORD = os.getenv("NETBRAIN_PASS", "c@2OpW@PUDZy%aW;ROShF")

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"
OUTPUT_FILE = os.path.expanduser("~/Downloads/ddc1_network_inventory.csv")

# Concurrency & Pagination Configurations
MAX_WORKERS = 20
PAGE_LIMIT = 100
MAX_ESTIMATED_PAGES = 100

DEFAULT_VRFS = {"default", "mgmt", "management", "global", "none", "null", ""}

# Configure reusable HTTP Session
session = requests.Session()
# session.verify = "/path/to/enterprise-ca.crt"
session.verify = False  # Set to True once local CA store is configured
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


def authenticate() -> dict:
    """Authenticates to NetBrain and configures session headers."""
    login_url = f"{BASE_URL}/Session"
    login_payload = {"username": USERNAME, "password": PASSWORD}

    print("Logging into NetBrain API...")
    res = session.post(login_url, json=login_payload, timeout=15)
    if res.status_code != 200:
        raise RuntimeError(f"Auth failed ({res.status_code}): {res.text}")

    data = res.json()
    token = data.get("token")
    if not token:
        raise RuntimeError("Token missing in response payload.")

    session.headers.update(
        {
            "Token": token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
    )

    if data.get("tenantId") and data.get("domainId"):
        session.headers.update(
            {"tenantId": data.get("tenantId"), "domainId": data.get("domainId")}
        )

    return data


def fetch_device_page(skip_value: int) -> list:
    """Fetches a paginated batch of device records."""
    url = f"{BASE_URL}/CMDB/Devices"
    try:
        res = session.get(
            url, params={"skip": skip_value, "limit": PAGE_LIMIT}, timeout=30
        )
        return res.json().get("devices", []) if res.status_code == 200 else []
    except requests.RequestException:
        return []


def extract_interface_type(intf: dict) -> str:
    """Extracts interface type using comprehensive key fallbacks and nested lookups."""
    type_keys = [
        "interfaceType",
        "type",
        "intfType",
        "mediaType",
        "portType",
        "interface_type",
        "subType",
    ]

    # 1. Top-Level Key Inspection
    for key in type_keys:
        val = intf.get(key)
        if val and str(val).strip():
            return str(val).strip()

    # 2. Nested Attribute Inspection
    for parent in ["attributes", "properties", "details"]:
        sub_dict = intf.get(parent)
        if isinstance(sub_dict, dict):
            for key in type_keys:
                val = sub_dict.get(key)
                if val and str(val).strip():
                    return str(val).strip()

    return ""


def enrich_device_metadata(device_id: str, hostname: str) -> tuple:
    """Retrieves interface types, production VRFs, and routing protocols."""
    types, vrfs, protocols = set(), set(), set()
    query_params = (
        {"deviceId": device_id}
        if device_id
        else {"hostname": str(hostname).lower()}
    )
    fallback_params = {"hostname": str(hostname).lower()}

    # Interface Enrichment (Primary Endpoint)
    try:
        intf_url = f"{BASE_URL}/CMDB/Devices/Interfaces"
        res = session.get(intf_url, params=query_params, timeout=15)

        if res.status_code != 200 or not res.json().get("interfaces"):
            res = session.get(intf_url, params=fallback_params, timeout=15)

        # Fallback to secondary endpoint if primary yields nothing
        if res.status_code != 200 or not res.json().get("interfaces"):
            alt_intf_url = f"{BASE_URL}/CMDB/Interfaces"
            res = session.get(alt_intf_url, params=query_params, timeout=15)

        if res.status_code == 200:
            interfaces = res.json().get("interfaces") or res.json().get("interfaceList", [])
            for intf in interfaces:
                if_type = extract_interface_type(intf)
                if if_type:
                    types.add(if_type)

                vrf_name = (
                    intf.get("vrf")
                    or intf.get("vrfName")
                    or intf.get("vrf_name")
                )
                if (
                    vrf_name
                    and str(vrf_name).strip().lower() not in DEFAULT_VRFS
                ):
                    vrfs.add(str(vrf_name).strip())
    except requests.RequestException:
        pass

    # Routing Protocols Enrichment
    try:
        rt_url = f"{BASE_URL}/CMDB/Devices/Routing/Protocols"
        res = session.get(rt_url, params=query_params, timeout=15)
        if res.status_code != 200 or not res.json().get("protocols"):
            res = session.get(rt_url, params=fallback_params, timeout=15)

        if res.status_code == 200:
            for proto in res.json().get("protocols", []):
                p_name = (
                    proto.get("protocolName")
                    or proto.get("name")
                    or proto.get("type")
                )
                if p_name:
                    protocols.add(str(p_name).upper())
    except requests.RequestException:
        pass

    return list(types), list(vrfs), list(protocols)


def main():
    authenticate()

    all_ddc1_devices = []
    seen_hostnames = set()
    all_discovered_columns = {
        "interfaceTypes",
        "vrfNames",
        "routingProtocols",
    }
    skip_offsets = [i * PAGE_LIMIT for i in range(MAX_ESTIMATED_PAGES)]

    print(f"Fetching global CMDB devices ({MAX_WORKERS} workers)...")

    # Defined fields to filter out of the CSV export
    EXCLUDED_FIELDS = {
        "hostName",
        "hostname",
    }

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(fetch_device_page, skip): skip
            for skip in skip_offsets
        }

        for future in as_completed(futures):
            devices_batch = future.result()
            for device in devices_batch:
                hostname = (
                    device.get("hostName")
                    or device.get("hostname")
                    or device.get("name")
                )

                if hostname and hostname not in seen_hostnames:
                    searchable_fields = f"{hostname} {device.get('mgmtIP', '')} {device.get('subType', '')}".upper()

                    if "DDC1" in searchable_fields:
                        seen_hostnames.add(hostname)
                        flat_device = {
                            "_internal_id": device.get("id")
                            or device.get("deviceId")
                        }

                        for k, v in device.items():
                            if k in EXCLUDED_FIELDS or any(
                                ex in k.lower()
                                for ex in ["id", "discovery", "time"]
                            ):
                                continue
                            if k == "attributes" and isinstance(v, dict):
                                for sub_k, sub_v in v.items():
                                    if sub_k not in EXCLUDED_FIELDS and not any(
                                        ex in sub_k.lower()
                                        for ex in ["id", "discovery", "time"]
                                    ):
                                        flat_device[f"attr_{sub_k}"] = sub_v
                            else:
                                flat_device[k] = v

                        all_discovered_columns.update(
                            k
                            for k in flat_device
                            if k != "_internal_id"
                        )
                        all_ddc1_devices.append(flat_device)

    print(
        f"Found {len(all_ddc1_devices)} DDC1 assets. Enriching metadata..."
    )

    if all_ddc1_devices:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_map = {
                executor.submit(
                    enrich_device_metadata,
                    dev.get("_internal_id"),
                    dev.get("name") or dev.get("hostName") or dev.get("hostname"),
                ): dev
                for dev in all_ddc1_devices
            }

            for future in as_completed(future_map):
                dev = future_map[future]
                try:
                    types, vrfs, protos = future.result()
                    dev["interfaceTypes"] = (
                        ", ".join(sorted(types)) if types else "N/A"
                    )
                    dev["vrfNames"] = (
                        ", ".join(sorted(vrfs)) if vrfs else "None"
                    )
                    dev["routingProtocols"] = (
                        ", ".join(sorted(protos)) if protos else "None"
                    )
                except Exception:
                    dev["interfaceTypes"] = "Error"
                    dev["vrfNames"] = "Error"
                    dev["routingProtocols"] = "Error"
                finally:
                    dev.pop("_internal_id", None)

    # Output CSV Handling
    if not all_ddc1_devices:
        all_ddc1_devices.append(
            {
                "name": "No Matching DDC1 Assets Discovered",
                "mgmtIP": "N/A",
                "interfaceTypes": "N/A",
                "vrfNames": "None",
                "routingProtocols": "None",
            }
        )

    primary_headers = [
        "name",
        "mgmtIP",
        "interfaceTypes",
        "vrfNames",
        "routingProtocols",
    ]
    extra_headers = sorted(
        [col for col in all_discovered_columns if col not in primary_headers and col not in EXCLUDED_FIELDS]
    )
    ordered_headers = primary_headers + extra_headers

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(
        OUTPUT_FILE, mode="w", newline="", encoding="utf-8"
    ) as csv_file:
        writer = csv.DictWriter(
            csv_file, fieldnames=ordered_headers, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(all_ddc1_devices)

    print(f"Export successful: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
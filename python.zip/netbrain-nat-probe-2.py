"""
NetBrain NAT Data Probe
========================

One-off diagnostic script. Do NOT use this for reporting -- it exists only
to pull the NAT-policy-specific CLI output from ONE firewall so we can
design a real parser for that vendor (this is a follow-up to
netbrain-interface-report.py; the Palo Alto parser is already built and
working against "show running nat-policy").

This intentionally does NOT pull the full running config anymore -- that's
2.5MB+ and contains passwords/PSKs/SNMP strings. It only requests the one
NAT-specific command for the vendor you select below, via:
    CMDB/Devices/DeviceRawData  (dataType=2, cmd=<the command>)

The response is saved locally so you can paste it back (still worth
skimming for anything sensitive first, e.g. real internal IPs you'd rather
redact -- NAT commands are much smaller/safer than a full config, but not
guaranteed to be secret-free).

Usage:
    python netbrain-nat-probe.py
"""

import getpass
import json
import sys

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_URL = "https://netbrain.mckesson.com/ServicesAPI/API/V1"

# Add/adjust commands here as we confirm what each platform actually needs.
VENDOR_NAT_COMMANDS = {
    "1": ("Cisco ASA", "show nat detail"),
    "2": ("Fortinet FortiGate", "show firewall policy"),
    "3": ("Check Point", "fw tab -t connections -s"),  # placeholder -- CP NAT is usually pulled via SmartConsole/API, not CLI; may need adjustment
    "4": ("Other (type a custom command)", None),
}


def authenticate(session, username, password):
    res = session.post(f"{BASE_URL}/Session", json={"username": username, "password": password}, timeout=60)
    res.raise_for_status()
    data = res.json()
    token = data.get("token") or data.get("tokenID")
    if not token:
        sys.exit(f"Error: no token in login response: {data}")
    session.headers.update({"Token": token, "Content-Type": "application/json", "Accept": "application/json"})
    if "tenantId" in data and "domainId" in data:
        session.headers.update({"tenantId": str(data["tenantId"]), "domainId": str(data["domainId"])})


def get_raw_data(session, hostname, cmd):
    url = f"{BASE_URL}/CMDB/Devices/DeviceRawData"
    payload = {"hostname": hostname, "dataType": 2, "cmd": cmd}
    res = session.get(url, params=payload, timeout=60)
    print(f"\n[DeviceRawData API] cmd={cmd!r} status={res.status_code}")
    try:
        return res.json()
    except ValueError:
        return {"raw_text": res.text}


def choose_command():
    print("\nWhich firewall vendor are you probing?")
    for key, (label, _cmd) in VENDOR_NAT_COMMANDS.items():
        print(f"  {key}) {label}")
    choice = input("Enter choice [1-4]: ").strip()
    label, cmd = VENDOR_NAT_COMMANDS.get(choice, VENDOR_NAT_COMMANDS["4"])
    if cmd is None:
        cmd = input("Enter the exact CLI command to run: ").strip()
    return label, cmd


def main():
    username = input("Enter NetBrain Username: ").strip()
    password = getpass.getpass("Enter NetBrain Password: ").strip()
    hostname = input("Enter firewall hostname: ").strip()

    if not username or not password or not hostname:
        sys.exit("Username, password, and hostname are all required.")

    label, cmd = choose_command()

    session = requests.Session()
    session.verify = False
    authenticate(session, username, password)

    raw_result = get_raw_data(session, hostname, cmd)
    with open("nat_probe_rawdata.json", "w") as f:
        json.dump(raw_result, f, indent=2)

    content_preview = raw_result.get("content", "")
    print(f"\n--- {label} / {cmd!r} response preview (first 1500 chars) ---")
    print(content_preview[:1500] if isinstance(content_preview, str) else raw_result)
    print(f"\nFull response saved -> nat_probe_rawdata.json")
    print(
        "\nBefore sharing: skim the saved file for anything you'd rather "
        "redact (real internal IPs, hostnames), then paste the relevant "
        "excerpt back so a real parser can be built for this vendor."
    )


if __name__ == "__main__":
    main()


#!/usr/bin/env python3

from netmiko import ConnectHandler
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from datetime import datetime

import ipaddress
import getpass
import logging
import csv
import re

# =========================================================
# FILES
# =========================================================

TIMESTAMP = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

REPORT_FILE = (
    f"subnet_report_{TIMESTAMP}.csv"
)

AUDIT_FILE = (
    f"command_audit_{TIMESTAMP}.csv"
)

FAILED_FILE = (
    f"failed_devices_{TIMESTAMP}.csv"
)

LOG_FILE = (
    f"subnet_audit_{TIMESTAMP}.log"
)

# =========================================================
# LOGGING
# =========================================================

logging.basicConfig(
    level=logging.INFO,
    format=(
        "%(asctime)s "
        "%(levelname)s "
        "%(message)s"
    ),
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)

# =========================================================
# GLOBALS
# =========================================================

COMMAND_LOG = []
FAILED_DEVICES = []

COMMAND_LOCK = Lock()
FAILED_LOCK = Lock()

# =========================================================
# DEVICE TYPE
# =========================================================

def detect_device_type(
        host,
        username,
        password):

    device_types = [

        "cisco_nxos",
        "cisco_xe",
        "cisco_ios",
        "arista_eos"

    ]

    for device_type in device_types:

        try:

            conn = ConnectHandler(
                device_type=device_type,
                host=host,
                username=username,
                password=password,
                fast_cli=False
            )

            conn.disconnect()

            return device_type

        except Exception:

            continue

    raise Exception(
        f"Unable to identify device type"
    )

# =========================================================
# COMMAND EXECUTION
# =========================================================

def send_command(
        conn,
        host,
        command):

    with COMMAND_LOCK:

        COMMAND_LOG.append([
            host,
            command
        ])

    logging.info(
        f"{host} "
        f"Executing: {command}"
    )

    return conn.send_command(
        command,
        read_timeout=120
    )

# =========================================================
# VLAN DATABASE
# =========================================================

def build_vlan_db(output):

    vlan_db = {}

    for line in output.splitlines():

        match = re.match(
            r"^\s*(\d+)\s+(\S+)",
            line
        )

        if match:

            vlan_db[
                f"Vlan{match.group(1)}"
            ] = match.group(2)

    return vlan_db

# =========================================================
# VLAN LOOKUP
# =========================================================

def get_vlan_info(
        interface_name,
        vlan_db):

    match = re.search(
        r"Vlan(\d+)",
        interface_name,
        re.I
    )

    if not match:

        match = re.search(
            r"\.(\d+)$",
            interface_name
        )

    if not match:

        return "", ""

    vlan_id = match.group(1)

    vlan_name = vlan_db.get(
        f"Vlan{vlan_id}",
        ""
    )

    return vlan_id, vlan_name

# =========================================================
# ARP
# =========================================================

def get_arp_count(
        arp_output,
        subnet):

    network = ipaddress.ip_network(
        subnet,
        strict=False
    )

    count = 0

    for line in arp_output.splitlines():

        match = re.search(
            r"(\d+\.\d+\.\d+\.\d+)",
            line
        )

        if not match:
            continue

        try:

            ip = ipaddress.ip_address(
                match.group(1)
            )

            if ip in network:

                count += 1

        except Exception:

            pass

    return count

# =========================================================
# UTILIZATION
# =========================================================

def get_utilization(
        subnet,
        arp_count):

    network = ipaddress.ip_network(
        subnet,
        strict=False
    )

    hosts = max(
        network.num_addresses - 2,
        1
    )

    return round(
        (arp_count / hosts) * 100,
        2
    )

# =========================================================
# ROUTE LOOKUP
# =========================================================

def get_route_info(
        conn,
        host,
        subnet):

    network = ipaddress.ip_network(
        subnet,
        strict=False
    )

    route_ip = str(
        network.network_address
    )

    output = send_command(
        conn,
        host,
        f"show ip route {route_ip}"
    )

    route_type = "Unknown"

    lower = output.lower()

    if "bgp" in lower:
        route_type = "BGP"

    elif "ospf" in lower:
        route_type = "OSPF"

    elif "eigrp" in lower:
        route_type = "EIGRP"

    elif "isis" in lower:
        route_type = "ISIS"

    elif "static" in lower:
        route_type = "Static"

    elif "connected" in lower:
        route_type = "Connected"

    next_hop = ""

    match = re.search(
        r"via\s+(\d+\.\d+\.\d+\.\d+)",
        output,
        re.I
    )

    if match:

        next_hop = match.group(1)

    interface = ""

    match = re.search(
        r"(Vlan\d+)",
        output,
        re.I
    )

    if match:

        interface = match.group(1)

    return {
        "route_type": route_type,
        "interface": interface,
        "next_hop": next_hop
    }

# =========================================================
# PROCESS DEVICE
# =========================================================

def process_device(
        host,
        username,
        password,
        subnets):

    results = []

    try:

        logging.info(
            f"{host} Connecting"
        )

        device_type = detect_device_type(
            host,
            username,
            password
        )

        logging.info(
            f"{host} Type={device_type}"
        )

        conn = ConnectHandler(
            device_type=device_type,
            host=host,
            username=username,
            password=password,
            fast_cli=False
        )

        if device_type == "cisco_nxos":

            arp_cmd = (
                "show ip arp vrf all"
            )

        else:

            arp_cmd = (
                "show ip arp"
            )

        arp_output = send_command(
            conn,
            host,
            arp_cmd
        )

        vlan_output = send_command(
            conn,
            host,
            "show vlan brief"
        )

        vlan_db = build_vlan_db(
            vlan_output
        )

        for subnet in subnets:

            logging.info(
                f"{host} "
                f"Processing {subnet}"
            )

            route = get_route_info(
                conn,
                host,
                subnet
            )

            vlan_id, vlan_name = (
                get_vlan_info(
                    route["interface"],
                    vlan_db
                )
            )

            arp_count = (
                get_arp_count(
                    arp_output,
                    subnet
                )
            )

            utilization = (
                get_utilization(
                    subnet,
                    arp_count
                )
            )

            results.append([

                subnet,
                host,
                device_type,

                route["route_type"],
                route["interface"],

                vlan_id,
                vlan_name,

                route["next_hop"],

                arp_count,
                utilization

            ])

        conn.disconnect()

    except Exception as e:

        logging.exception(
            f"{host} Failed"
        )

        with FAILED_LOCK:

            FAILED_DEVICES.append([
                host,
                str(e)
            ])

    return results

# =========================================================
# MAIN
# =========================================================

def main():

    hosts = input(
        "Enter hosts: "
    ).split(",")

    start_subnet = input(
        "Starting subnet: "
    ).strip()

    mask = input(
        "Mask Length: "
    ).strip()

    subnet_count = int(
        input(
            "Number of Subnets: "
        )
    )

    username = input(
        "Username: "
    )

    password = getpass.getpass(
        "Password: "
    )

    base = ipaddress.ip_network(
        f"{start_subnet}/{mask}",
        strict=False
    )

    subnets = []

    current = base.network_address

    for _ in range(subnet_count):

        network = ipaddress.ip_network(
            f"{current}/{mask}",
            strict=False
        )

        subnets.append(
            str(network)
        )

        current += (
            network.num_addresses
        )

    results = []

    with ThreadPoolExecutor(
            max_workers=5) as pool:

        futures = [

            pool.submit(
                process_device,
                host.strip(),
                username,
                password,
                subnets
            )

            for host in hosts
        ]

        for future in futures:

            results.extend(
                future.result()
            )

    with open(
        REPORT_FILE,
        "w",
        newline=""
    ) as f:

        writer = csv.writer(f)

        writer.writerow([

            "IP Subnet",
            "Device",
            "Device Type",
            "Route Type",
            "Interface",
            "VLAN ID",
            "VLAN Name",
            "Next Hop",
            "# ARPs",
            "ARP Utilization %"

        ])

        writer.writerows(results)

    with open(
        AUDIT_FILE,
        "w",
        newline=""
    ) as f:

        writer = csv.writer(f)

        writer.writerow([
            "Device",
            "Command"
        ])

        writer.writerows(
            COMMAND_LOG
        )

    with open(
        FAILED_FILE,
        "w",
        newline=""
    ) as f:

        writer = csv.writer(f)

        writer.writerow([
            "Device",
            "Error"
        ])

        writer.writerows(
            FAILED_DEVICES
        )

    print("\nGenerated Files:")
    print(f"  {REPORT_FILE}")
    print(f"  {AUDIT_FILE}")
    print(f"  {FAILED_FILE}")
    print(f"  {LOG_FILE}")

    logging.info(
        f"Records Generated: "
        f"{len(results)}"
    )

if __name__ == "__main__":
    main()